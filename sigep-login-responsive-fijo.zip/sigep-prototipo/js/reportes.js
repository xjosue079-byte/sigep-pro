document.addEventListener("DOMContentLoaded", () => {
    const STORAGE = window.SIGEP_STORAGE;
    if (!STORAGE) {
        console.error("SIGEP - Storage no disponible");
        return;
    }

    const $ = id => document.getElementById(id);
    const fromInput = $("reportFrom");
    const toInput = $("reportTo");
    const reportType = $("reportType");
    const workerSelect = $("reportWorker");
    const workerFilterField = $("workerFilterField");
    const summaryBody = $("reportSummaryBody");
    const detailBody = $("reportDetailBody");
    const detailPanel = $("detailPanel");
    const reportError = $("reportError");
    const reportMessage = $("reportMessage");
    const paymentPanel = $("paymentPanel");
    const paymentBody = $("paymentPeriodsBody");

    let currentRows = [];
    let currentSummary = [];

    const pad = n => String(n).padStart(2, "0");
    const isoLocal = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    const todayISO = () => isoLocal(new Date());
    const parseISO = s => {
        const [y, m, d] = s.split("-").map(Number);
        return new Date(y, m - 1, d);
    };
    const dateLabel = s => new Intl.DateTimeFormat("es-PE", { day: "2-digit", month: "2-digit", year: "numeric" }).format(parseISO(s));
    const longDate = s => new Intl.DateTimeFormat("es-PE", { day: "numeric", month: "long", year: "numeric" }).format(parseISO(s));
    const timeToMinutes = t => {
        if (!t || !t.includes(":")) return null;
        const [h, m] = t.split(":").map(Number);
        return h * 60 + m;
    };
    const formatTime12 = t => {
        if (!t) return "—";
        const [h, m] = t.split(":").map(Number);
        return `${h % 12 || 12}:${pad(m)} ${h >= 12 ? "p. m." : "a. m."}`;
    };
    const esc = v => String(v ?? "").replace(/[&<>'"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[c]));

    function setMessage(text = "", type = "info") {
        if (!reportMessage) return;
        reportMessage.textContent = text;
        reportMessage.className = text ? `report-message active ${type}` : "report-message";
        if (text) setTimeout(() => {
            if (reportMessage.textContent === text) {
                reportMessage.textContent = "";
                reportMessage.className = "report-message";
            }
        }, 3500);
    }

    function renderTopDate() {
        const el = $("dashboardDate");
        if (el) el.textContent = new Intl.DateTimeFormat("es-PE", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date());
    }

    function scheduleText(s) {
        if (s.journey === "Completo") {
            const a = s.entry1 && s.exit1 ? `${formatTime12(s.entry1)} - ${formatTime12(s.exit1)}` : "";
            const b = s.entry2 && s.exit2 ? `${formatTime12(s.entry2)} - ${formatTime12(s.exit2)}` : "";
            return [a, b].filter(Boolean).join(" / ") || "—";
        }
        return s.entry && s.exit ? `${formatTime12(s.entry)} - ${formatTime12(s.exit)}` : "—";
    }

    function calculatedStatus(schedule, workerId, date) {
        const marks = STORAGE.getWorkerBiometricMarks(workerId, date) || [];
        const entry = marks.find(m => m.type === "Entrada");
        const exit = marks.find(m => m.type === "Salida");
        const scheduledEntry = schedule.journey === "Completo" ? schedule.entry1 : schedule.entry;
        const scheduledExit = schedule.journey === "Completo" ? (schedule.exit2 || schedule.exit1) : schedule.exit;
        let status = "Pendiente";

        if (entry && scheduledEntry) {
            const em = timeToMinutes(entry.time);
            const sm = timeToMinutes(scheduledEntry);
            const tol = Number(schedule.tolerance) || 0;
            status = em <= sm + tol ? "Presente" : "Tardanza";
        } else if (!entry) {
            if (date < todayISO()) {
                status = "Falta";
            } else if (date === todayISO() && scheduledExit) {
                const now = new Date();
                const nowMin = now.getHours() * 60 + now.getMinutes();
                const ex = timeToMinutes(scheduledExit);
                if (ex !== null && nowMin > ex) status = "Falta";
            }
        }

        const reg = typeof STORAGE.getAttendanceRegularization === "function"
            ? STORAGE.getAttendanceRegularization(workerId, date)
            : null;
        if (reg) status = reg.status;

        return { status, entry: entry?.time || null, exit: exit?.time || null, regularization: reg };
    }

    function buildRows(from, to, workerId = "") {
        const rows = [];
        const start = parseISO(from);
        const end = parseISO(to);
        for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
            const date = isoLocal(d);
            const schedules = (STORAGE.getSchedulesByDate(date) || [])
                .filter(s => s.journey !== "Libre" && !s.replacementWorkerId && (!workerId || Number(s.workerId) === Number(workerId)));
            schedules.forEach(s => {
                const w = STORAGE.getWorkerById(s.workerId);
                if (!w) return;
                const result = calculatedStatus(s, w.id, date);
                rows.push({
                    date,
                    workerId: Number(w.id),
                    workerName: STORAGE.getWorkerFullName(w),
                    workerCode: w.code || "",
                    position: STORAGE.getWorkerPositionName(w),
                    schedule: scheduleText(s),
                    ...result
                });
            });
        }
        return rows;
    }

    function summarize(rows) {
        const map = new Map();
        rows.forEach(r => {
            if (!map.has(r.workerId)) map.set(r.workerId, { workerId: r.workerId, name: r.workerName, code: r.workerCode, scheduled: 0, present: 0, late: 0, absent: 0, pending: 0 });
            const x = map.get(r.workerId);
            x.scheduled++;
            if (r.status === "Presente") x.present++;
            else if (r.status === "Tardanza") x.late++;
            else if (r.status === "Falta" || r.status === "Falta justificada") x.absent++;
            else x.pending++;
        });
        return [...map.values()]
            .map(x => ({ ...x, rate: x.scheduled ? ((x.present + x.late) / x.scheduled * 100) : 0 }))
            .sort((a, b) => a.name.localeCompare(b.name, "es"));
    }

    function statusClass(status) {
        if (status === "Presente") return "present";
        if (status === "Tardanza") return "late";
        if (status === "Falta justificada") return "justified";
        if (status === "Falta") return "absent";
        return "pending";
    }

    function initials(name) {
        return name.split(" ").filter(Boolean).slice(0, 2).map(x => x[0].toUpperCase()).join("");
    }

    function updateReportMode() {
        const individual = reportType.value === "individual";
        const payments = reportType.value === "payments";
        workerSelect.disabled = !individual;
        workerFilterField?.classList.toggle("is-disabled", !individual);
        if (!individual) workerSelect.value = "";
        detailPanel.classList.remove("active");
        paymentPanel?.classList.toggle("active", payments);
        document.querySelector(".reports-stats")?.classList.toggle("payment-mode", payments);
        document.querySelector(".report-panel:not(.payment-panel):not(.detail-panel)")?.classList.toggle("is-hidden-payment", payments);
    }

    function buildWorkedDayPaymentPeriods(to) {
        const workers = (STORAGE.getWorkers?.() || []).filter(w => w.active !== false);
        const allSchedules = (STORAGE.getDailySchedules?.() || [])
            .filter(s => s.date <= to && s.journey !== "Libre" && !s.replacementWorkerId)
            .sort((a,b) => a.date.localeCompare(b.date));
        const periods = [];

        workers.forEach(w => {
            const workerSchedules = allSchedules.filter(s => Number(s.workerId) === Number(w.id));
            const worked = [];
            let absences = 0;
            workerSchedules.forEach(s => {
                const result = calculatedStatus(s, w.id, s.date);
                if (result.status === "Presente" || result.status === "Tardanza") {
                    worked.push({ date:s.date, status:result.status });
                } else if (result.status === "Falta" || result.status === "Falta justificada") {
                    absences++;
                }
            });

            for (let i=0; i<worked.length; i+=15) {
                const chunk = worked.slice(i, i+15);
                if (!chunk.length) continue;
                const complete = chunk.length === 15;
                const from = chunk[0].date;
                const endDate = chunk[chunk.length-1].date;
                const saved = complete ? STORAGE.getPaymentPeriod?.(w.id, from, endDate) : null;
                const status = saved?.status === "Procesado" ? "Procesado" : (complete ? "Pago pendiente" : "En progreso");
                periods.push({
                    workerId:Number(w.id), name:STORAGE.getWorkerFullName(w), code:w.code || "",
                    from, to:endDate, worked:chunk.length,
                    present:chunk.filter(x=>x.status==="Presente").length,
                    late:chunk.filter(x=>x.status==="Tardanza").length,
                    remaining:Math.max(0,15-chunk.length), status, saved
                });
            }
        });
        return periods.sort((a,b)=>b.to.localeCompare(a.to)||a.name.localeCompare(b.name,"es"));
    }

    function renderPaymentPeriods(showFeedback=false) {
        const to=toInput.value;
        reportError.textContent="";
        if(!to){reportError.textContent="Selecciona una fecha de corte.";return false;}
        const periods=buildWorkedDayPaymentPeriods(to);
        const pending=periods.filter(p=>p.status==="Pago pendiente").length;
        $("paymentPendingCount").textContent=`${pending} ${pending===1?"pago pendiente":"pagos pendientes"}`;
        $("paymentPeriodText").textContent=`Control de ciclos de 15 días efectivamente trabajados hasta ${longDate(to)}.`;
        if(!periods.length){paymentBody.innerHTML='<tr><td colspan="8" class="empty-report">Aún no hay días trabajados registrados.</td></tr>';return true;}
        paymentBody.innerHTML=periods.map(p=>{
            const cls=p.status==="Procesado"?"processed":p.status==="Pago pendiente"?"pending":"progress";
            const action=p.status==="Pago pendiente"?`<button class="payment-action" data-action="process" data-worker="${p.workerId}" data-from="${p.from}" data-to="${p.to}">Marcar procesado</button>`:p.status==="Procesado"?`<button class="payment-action reopen" data-action="reopen" data-worker="${p.workerId}" data-from="${p.from}" data-to="${p.to}">Reabrir</button>`:"—";
            const meta=p.saved?.processedAt?`<span class="payment-meta">${dateLabel(p.saved.processedAt.slice(0,10))} · ${esc(p.saved.processedBy||"Administrador")}</span>`:"";
            const progress=`<div class="worked-progress"><strong>${p.worked} / 15</strong><span>${p.remaining ? `Faltan ${p.remaining} día${p.remaining===1?"":"s"}` : "15 días cumplidos"}</span></div>`;
            return `<tr><td><div class="worker-cell"><div class="worker-avatar">${initials(p.name)}</div><div><strong>${esc(p.name)}</strong><span>${esc(p.code)}</span></div></div></td><td>${dateLabel(p.from)} – ${dateLabel(p.to)}</td><td>${progress}</td><td>${p.present}</td><td>${p.late}</td><td>${p.worked}</td><td><span class="payment-status ${cls}">${esc(p.status)}</span>${meta}</td><td>${action}</td></tr>`;
        }).join("");
        if(showFeedback)setMessage(pending?`${pending} trabajador(es) completaron 15 días y están pendientes de pago.`:"Control de 15 días actualizado.",pending?"info":"success");
        return true;
    }

    function renderReport(showFeedback = false) {
        if (reportType.value === "payments") return renderPaymentPeriods(showFeedback);
        const from = fromInput.value;
        const to = toInput.value;
        reportError.textContent = "";

        if (!from || !to) {
            reportError.textContent = "Selecciona ambas fechas.";
            return false;
        }
        if (from > to) {
            reportError.textContent = "La fecha inicial no puede ser posterior a la fecha final.";
            return false;
        }
        if (reportType.value === "individual" && !workerSelect.value) {
            reportError.textContent = "Selecciona un trabajador para generar el reporte individual.";
            return false;
        }

        const workerId = reportType.value === "individual" ? workerSelect.value : "";
        currentRows = buildRows(from, to, workerId);
        currentSummary = summarize(currentRows);

        const count = states => currentRows.filter(r => states.includes(r.status)).length;
        $("reportScheduled").textContent = currentRows.length;
        $("reportPresent").textContent = count(["Presente"]);
        $("reportLate").textContent = count(["Tardanza"]);
        $("reportAbsent").textContent = count(["Falta", "Falta justificada"]);
        $("reportRangeText").textContent = `${longDate(from)} — ${longDate(to)}`;
        $("reportResultCount").textContent = `${currentSummary.length} ${currentSummary.length === 1 ? "trabajador" : "trabajadores"}`;

        if (!currentSummary.length) {
            summaryBody.innerHTML = '<tr><td colspan="7" class="empty-report">No hay jornadas programadas en el periodo seleccionado.</td></tr>';
            detailPanel.classList.remove("active");
            if (showFeedback) setMessage("No se encontraron jornadas para los filtros seleccionados.", "info");
            return true;
        }

        summaryBody.innerHTML = currentSummary.map(x => `
            <tr>
                <td><div class="worker-cell"><div class="worker-avatar">${initials(x.name)}</div><div><strong>${esc(x.name)}</strong><span>${esc(x.code)}</span></div></div></td>
                <td>${x.scheduled}</td><td>${x.present}</td><td>${x.late}</td><td>${x.absent}</td>
                <td><span class="attendance-rate">${x.rate.toFixed(1)}%</span></td>
                <td><button class="view-detail" type="button" data-worker-id="${x.workerId}" title="Ver detalle"><i class="fa-solid fa-eye"></i></button></td>
            </tr>`).join("");

        if (reportType.value === "individual" && currentSummary[0]) showDetail(currentSummary[0].workerId, false);
        else detailPanel.classList.remove("active");

        if (showFeedback) setMessage(reportType.value === "general" ? "Reporte general generado correctamente." : "Reporte individual generado correctamente.", "success");
        return true;
    }

    function showDetail(workerId, scroll = true) {
        const rows = currentRows.filter(r => r.workerId === Number(workerId)).sort((a, b) => a.date.localeCompare(b.date));
        const worker = currentSummary.find(x => x.workerId === Number(workerId));
        if (!worker) return;
        $("detailTitle").textContent = worker.name;
        $("detailSubtitle").textContent = `Detalle del periodo · ${worker.scheduled} jornadas`;
        detailPanel.classList.add("active");
        detailBody.innerHTML = rows.map(r => {
            let note = "Sin observaciones";
            if (r.regularization) note = `<span class="regularized-note">Regularizado:</span> ${esc(r.regularization.reason || "")}`;
            else if (r.status === "Tardanza") note = "Ingreso fuera de tolerancia";
            else if (r.status === "Falta") note = "Sin marcación de entrada";
            else if (r.status === "Pendiente") note = "Jornada aún pendiente";
            return `<tr><td>${dateLabel(r.date)}</td><td>${esc(r.schedule)}</td><td>${formatTime12(r.entry)}</td><td>${formatTime12(r.exit)}</td><td><span class="status-pill ${statusClass(r.status)}">${esc(r.status)}</span></td><td class="report-note">${note}</td></tr>`;
        }).join("");
        if (scroll) detailPanel.scrollIntoView({ behavior: "smooth", block: "start" });
    }

    function populateWorkers() {
        const workers = (STORAGE.getWorkers?.() || []).filter(w => w.active !== false);
        workers.sort((a, b) => STORAGE.getWorkerFullName(a).localeCompare(STORAGE.getWorkerFullName(b), "es"));
        workerSelect.innerHTML = '<option value="">Selecciona un trabajador</option>' + workers.map(w => `<option value="${w.id}">${esc(STORAGE.getWorkerFullName(w))}</option>`).join("");
    }

    function csvEscape(v) {
        const s = String(v ?? "");
        return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    }

    function exportCSV() {
        reportError.textContent = "";
        if (!renderReport(false)) return;
        if (!currentRows.length) {
            reportError.textContent = "No hay datos para exportar con los filtros seleccionados.";
            setMessage("No hay datos disponibles para exportar.", "error");
            return;
        }

        const header = ["Fecha", "Código", "Trabajador", "Cargo", "Jornada", "Entrada", "Salida", "Estado", "Regularización", "Motivo"];
        const data = currentRows.map(r => [
            r.date, r.workerCode, r.workerName, r.position, r.schedule,
            r.entry ? formatTime12(r.entry) : "", r.exit ? formatTime12(r.exit) : "",
            r.status, r.regularization ? "Sí" : "No", r.regularization?.reason || ""
        ]);
        const csv = [header, ...data].map(row => row.map(csvEscape).join(";")).join("\r\n");
        const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `reporte_${reportType.value}_${fromInput.value}_${toInput.value}.csv`;
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1500);
        setMessage("CSV generado. Revisa la carpeta de descargas de tu navegador.", "success");
    }


    // =====================================================
    // EXPORTACIÓN EXCEL (.XLSX) SIN DEPENDENCIAS EXTERNAS
    // =====================================================
    function xmlEscape(value) {
        return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"}[c]));
    }

    function columnName(index) {
        let name = "";
        for (let n = index + 1; n > 0; n = Math.floor((n - 1) / 26)) name = String.fromCharCode(65 + ((n - 1) % 26)) + name;
        return name;
    }

    function makeSheet(rows, widths = []) {
        const rowXml = rows.map((row, r) => {
            const cells = row.map((value, c) => {
                const ref = `${columnName(c)}${r + 1}`;
                const style = r === 0 ? 2 : (r === 1 ? 3 : (r === 3 ? 4 : 1));
                if (typeof value === "number" && Number.isFinite(value)) return `<c r="${ref}" s="${style}" t="n"><v>${value}</v></c>`;
                return `<c r="${ref}" s="${style}" t="inlineStr"><is><t>${xmlEscape(value)}</t></is></c>`;
            }).join("");
            return `<row r="${r + 1}"${r === 0 ? ' ht="28" customHeight="1"' : ''}>${cells}</row>`;
        }).join("");
        const cols = widths.length ? `<cols>${widths.map((w, i) => `<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`).join("")}</cols>` : "";
        const lastCol = columnName(Math.max(0, (rows[0]?.length || 1) - 1));
        return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="20"/>${cols}<sheetData>${rowXml}</sheetData><autoFilter ref="A4:${lastCol}${Math.max(4, rows.length)}"/><pageMargins left="0.3" right="0.3" top="0.5" bottom="0.5" header="0.2" footer="0.2"/></worksheet>`;
    }

    function crc32(bytes) {
        let crc = -1;
        for (const b of bytes) {
            crc ^= b;
            for (let k = 0; k < 8; k++) crc = (crc >>> 1) ^ (0xEDB88320 & -(crc & 1));
        }
        return (crc ^ -1) >>> 0;
    }

    function u16(n) { return [n & 255, (n >>> 8) & 255]; }
    function u32(n) { return [n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255]; }

    function createZip(files) {
        const enc = new TextEncoder();
        const chunks = [], central = [];
        let offset = 0;
        Object.entries(files).forEach(([name, content]) => {
            const nameBytes = enc.encode(name), data = enc.encode(content), crc = crc32(data);
            const local = new Uint8Array([
                ...u32(0x04034b50), ...u16(20), ...u16(0), ...u16(0), ...u16(0), ...u16(0),
                ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nameBytes.length), ...u16(0), ...nameBytes
            ]);
            chunks.push(local, data);
            central.push(new Uint8Array([
                ...u32(0x02014b50), ...u16(20), ...u16(20), ...u16(0), ...u16(0), ...u16(0), ...u16(0),
                ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nameBytes.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset), ...nameBytes
            ]));
            offset += local.length + data.length;
        });
        const centralOffset = offset;
        central.forEach(c => { chunks.push(c); offset += c.length; });
        const centralSize = offset - centralOffset;
        chunks.push(new Uint8Array([...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(central.length), ...u16(central.length), ...u32(centralSize), ...u32(centralOffset), ...u16(0)]));
        return new Blob(chunks, {type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
    }

    function downloadBlob(blob, filename) {
        const url = URL.createObjectURL(blob), a = document.createElement("a");
        a.href = url; a.download = filename; a.style.display = "none";
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 2000);
    }

    function exportExcel() {
        reportError.textContent = "";
        if (!renderReport(false)) return;
        const from = fromInput.value, to = toInput.value;
        const generated = new Intl.DateTimeFormat("es-PE", {dateStyle:"long", timeStyle:"short"}).format(new Date());
        const sheets = [];

        if (reportType.value === "payments") {
            const periods = buildWorkedDayPaymentPeriods(to);
            if (!periods.length) { setMessage("No hay datos disponibles para exportar.", "error"); return; }
            const rows = [
                ["SIGEP — CONTROL DE 15 DÍAS TRABAJADOS"],
                [`Fecha de corte: ${longDate(to)}`],
                [`Generado: ${generated}`],
                ["Trabajador","Código","Período","Progreso","Presentes","Tardanzas","Días trabajados","Estado"]
            ];
            periods.forEach(x => rows.push([x.name,x.code,`${dateLabel(x.from)} - ${dateLabel(x.to)}`,`${x.worked} / 15`,x.present,x.late,x.worked,x.status]));
            sheets.push({name:"Control 15 días", xml:makeSheet(rows,[28,15,24,14,12,12,16,18])});
        } else {
            if (!currentRows.length) { setMessage("No hay datos disponibles para exportar.", "error"); return; }
            const title = reportType.value === "individual" ? "REPORTE INDIVIDUAL DE ASISTENCIA" : "REPORTE GENERAL DE ASISTENCIA";
            const summary = [[`SIGEP — ${title}`],[`Período: ${longDate(from)} - ${longDate(to)}`],[`Generado: ${generated}`],["Trabajador","Código","Jornadas","Presentes","Tardanzas","Faltas","Asistencia %"]];
            currentSummary.forEach(x => summary.push([x.name,x.code,x.scheduled,x.present,x.late,x.absent,Number(x.rate.toFixed(1))]));
            sheets.push({name:"Resumen", xml:makeSheet(summary,[30,15,12,12,12,12,15])});

            const detail = [[`SIGEP — DETALLE DE ASISTENCIA`],[`Período: ${longDate(from)} - ${longDate(to)}`],[`Generado: ${generated}`],["Fecha","Código","Trabajador","Cargo","Jornada","Entrada","Salida","Estado","Regularización","Motivo"]];
            currentRows.forEach(r => detail.push([dateLabel(r.date),r.workerCode,r.workerName,r.position,r.schedule,r.entry?formatTime12(r.entry):"",r.exit?formatTime12(r.exit):"",r.status,r.regularization?"Sí":"No",r.regularization?.reason||""]));
            sheets.push({name:"Detalle", xml:makeSheet(detail,[14,14,28,20,30,14,14,18,16,35])});
        }

        const sheetEntries = sheets.map((s,i)=>`<sheet name="${xmlEscape(s.name)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join("");
        const relEntries = sheets.map((s,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join("");
        const overrides = sheets.map((s,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("");
        const files = {
            "[Content_Types].xml":`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${overrides}</Types>`,
            "_rels/.rels":`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`,
            "xl/workbook.xml":`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheetEntries}</sheets></workbook>`,
            "xl/_rels/workbook.xml.rels":`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relEntries}<Relationship Id="rId${sheets.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,
            "xl/styles.xml":`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="4"><font><sz val="11"/><name val="Aptos"/></font><font><b/><sz val="16"/><color rgb="FFFFFFFF"/><name val="Aptos Display"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Aptos"/></font><font><b/><sz val="11"/><color rgb="FF101828"/><name val="Aptos"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF2563EB"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEFF6FF"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border/><border><left style="thin"><color rgb="FFE5E7EB"/></left><right style="thin"><color rgb="FFE5E7EB"/></right><top style="thin"><color rgb="FFE5E7EB"/></top><bottom style="thin"><color rgb="FFE5E7EB"/></bottom></border></borders><cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment vertical="center"/></xf><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment vertical="center"/></xf><xf numFmtId="0" fontId="3" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment vertical="center"/></xf></cellXfs></styleSheet>`
        };
        sheets.forEach((s,i)=>files[`xl/worksheets/sheet${i+1}.xml`]=s.xml);
        const blob = createZip(files);
        downloadBlob(blob, `SIGEP_${reportType.value}_${from || "inicio"}_${to}.xlsx`);
        setMessage("Excel profesional generado correctamente.", "success");
    }

    function printReport() {
        if (!renderReport(false)) return;
        if (!currentRows.length) {
            setMessage("No hay datos para imprimir.", "error");
            return;
        }
        window.print();
    }

    // Eventos: se registran antes de la carga inicial para que los botones siempre respondan.
    $("generateReport")?.addEventListener("click", () => renderReport(true));
    reportType?.addEventListener("change", () => {
        updateReportMode();
        renderReport(false);
    });
    workerSelect?.addEventListener("change", () => {
        if (reportType.value === "individual" && workerSelect.value) renderReport(false);
    });
    summaryBody?.addEventListener("click", e => {
        const b = e.target.closest(".view-detail");
        if (b) showDetail(b.dataset.workerId);
    });
    $("closeDetail")?.addEventListener("click", () => detailPanel.classList.remove("active"));
    paymentBody?.addEventListener("click", e => {
        const b=e.target.closest(".payment-action"); if(!b)return;
        const workerId=Number(b.dataset.worker), from=b.dataset.from, to=b.dataset.to;
        if(b.dataset.action==="process"){
            STORAGE.markPaymentPeriodProcessed?.(workerId,from,to,"Henry");
            setMessage("Período marcado como procesado para pago.","success");
        }else{
            STORAGE.reopenPaymentPeriod?.(workerId,from,to);
            setMessage("Período reabierto como pendiente.","info");
        }
        renderPaymentPeriods(false);
    });

    $("exportExcel")?.addEventListener("click", exportExcel);
    $("exportCsv")?.addEventListener("click", exportCSV);
    $("printReport")?.addEventListener("click", printReport);
    $("mobileMenu")?.addEventListener("click", () => $("sidebar")?.classList.toggle("active"));
    $("logoutButton")?.addEventListener("click", () => { window.location.href = "../index.html"; });

    const now = new Date();
    fromInput.value = isoLocal(new Date(now.getFullYear(), now.getMonth(), 1));
    toInput.value = todayISO();
    populateWorkers();
    updateReportMode();
    renderTopDate();
    renderReport(false);
});
