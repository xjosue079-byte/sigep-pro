/* =========================================================
   SIGEP - MÓDULO CARGOS
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       DATOS
    ===================================================== */

    let positions = SIGEP_STORAGE.getPositions();
    let workers = SIGEP_STORAGE.getWorkers();

    // Normaliza cargos duplicados por nombre (por ejemplo, dos "Asistente").
    const keptPositionByName = new Map();
    const duplicatePositionMap = new Map();
    const dedupedPositions = positions.filter(position => {
        const key = SIGEP_STORAGE.normalizeText(position.name || "").trim();
        if (!key) return false;
        if (keptPositionByName.has(key)) {
            duplicatePositionMap.set(Number(position.id), Number(keptPositionByName.get(key).id));
            return false;
        }
        keptPositionByName.set(key, position);
        return true;
    });
    if (dedupedPositions.length !== positions.length) {
        workers = workers.map(worker => duplicatePositionMap.has(Number(worker.positionId))
            ? { ...worker, positionId: duplicatePositionMap.get(Number(worker.positionId)) }
            : worker
        );
        SIGEP_STORAGE.saveWorkers(workers);
        SIGEP_STORAGE.savePositions(dedupedPositions);
        positions = dedupedPositions;
    }

    let editingPositionId = null;
    let selectedPositionId = null;


    /* =====================================================
       ELEMENTOS
    ===================================================== */

    const sidebar =
        document.getElementById("sidebar");

    const mobileMenu =
        document.getElementById("mobileMenu");

    const logoutButton =
        document.getElementById("logoutButton");

    const dashboardDate =
        document.getElementById("dashboardDate");


    /* INDICADORES */

    const totalPositions =
        document.getElementById("totalPositions");

    const assignedWorkers =
        document.getElementById("assignedWorkers");

    const activePositions =
        document.getElementById("activePositions");


    /* TABLA */

    const positionsTableBody =
        document.getElementById("positionsTableBody");

    const positionsResultText =
        document.getElementById("positionsResultText");


    /* FILTROS */

    const positionSearch =
        document.getElementById("positionSearch");

    const positionStatusFilter =
        document.getElementById("positionStatusFilter");


    /* MODAL */

    const positionModal =
        document.getElementById("positionModal");

    const openPositionModal =
        document.getElementById("openPositionModal");

    const closePositionModal =
        document.getElementById("closePositionModal");

    const cancelPositionModal =
        document.getElementById("cancelPositionModal");

    const positionForm =
        document.getElementById("positionForm");

    const positionModalTitle =
        document.getElementById("positionModalTitle");

    const positionModalDescription =
        document.getElementById("positionModalDescription");

    const positionSubmitText =
        document.getElementById("positionSubmitText");


    /* CAMPOS */

    const positionName =
        document.getElementById("positionName");

    const positionDescription =
        document.getElementById("positionDescription");

    const positionStatus =
        document.getElementById("positionStatus");


    /* MENÚ */

    const positionActionsMenu =
        document.getElementById("positionActionsMenu");


    /* =====================================================
       FECHA
    ===================================================== */

    if (dashboardDate) {

        const today = new Date();

        const formatted =
            new Intl.DateTimeFormat(
                "es-PE",
                {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                    year: "numeric"
                }
            ).format(today);

        dashboardDate.textContent =
            formatted.charAt(0).toUpperCase() +
            formatted.slice(1);
    }


    /* =====================================================
       ACTUALIZAR DATOS
    ===================================================== */

    function refreshData() {

        positions =
            SIGEP_STORAGE.getPositions();

        workers =
            SIGEP_STORAGE.getWorkers();

    }


    /* =====================================================
       RENDER GENERAL
    ===================================================== */

    function render() {

        refreshData();

        renderPositions();

        updateStats();

    }


    /* =====================================================
       RENDER TABLA
    ===================================================== */

    function renderPositions() {

        const search =
            SIGEP_STORAGE.normalizeText(
                positionSearch.value
            );

        const status =
            positionStatusFilter.value;


        const filteredPositions =
            positions.filter(position => {

                const matchesSearch =
                    SIGEP_STORAGE
                        .normalizeText(
                            position.name
                        )
                        .includes(search)

                    ||

                    SIGEP_STORAGE
                        .normalizeText(
                            position.description
                        )
                        .includes(search);


                const matchesStatus =
                    !status ||
                    position.status === status;


                return (
                    matchesSearch &&
                    matchesStatus
                );

            });


        positionsTableBody.innerHTML = "";


        /* =================================================
           SIN RESULTADOS
        ================================================= */

        if (filteredPositions.length === 0) {

            positionsTableBody.innerHTML = `

                <tr class="position-empty-row">

                    <td colspan="4">

                        <div class="position-empty">

                            <i class="fa-solid fa-briefcase"></i>

                            <strong>
                                No se encontraron cargos
                            </strong>

                            <p>
                                Intenta cambiar los filtros o registra un nuevo cargo.
                            </p>

                        </div>

                    </td>

                </tr>

            `;

        }

        /* =================================================
           RESULTADOS
        ================================================= */

        else {

            filteredPositions.forEach(position => {

                const assigned =
                    workers.filter(
                        worker =>
                            Number(worker.positionId) ===
                            Number(position.id)
                    ).length;


                const row =
                    document.createElement("tr");


                row.innerHTML = `

                    <td>

                        <div class="position-info">

                            <div class="position-icon">

                                <i class="fa-solid fa-briefcase"></i>

                            </div>


                            <div class="position-info-text">

                                <strong>
                                    ${escapeHTML(position.name)}
                                </strong>

                                <p>
                                    ${
                                        position.description
                                            ? escapeHTML(
                                                position.description
                                            )
                                            : "Sin descripción"
                                    }
                                </p>

                            </div>

                        </div>

                    </td>


                    <td>

                        <div class="position-workers">

                            <i class="fa-solid fa-users"></i>

                            <strong>
                                ${assigned}
                            </strong>

                            <span>
                                ${
                                    assigned === 1
                                        ? "trabajador"
                                        : "trabajadores"
                                }
                            </span>

                        </div>

                    </td>


                    <td>

                        <span
                            class="
                                position-status
                                ${
                                    position.status === "Activo"
                                        ? "active"
                                        : "inactive"
                                }
                            "
                        >
                            ${escapeHTML(position.status)}
                        </span>

                    </td>


                    <td>

                        <button
                            type="button"
                            class="position-action-button"
                            data-position-id="${position.id}"
                            title="Acciones"
                        >

                            <i class="fa-solid fa-ellipsis-vertical"></i>

                        </button>

                    </td>

                `;


                positionsTableBody.appendChild(
                    row
                );

            });

        }


        /* =================================================
           TEXTO INFERIOR
        ================================================= */

        const amount =
            filteredPositions.length;


        positionsResultText.textContent =
            amount === 1
                ? "1 cargo registrado"
                : `${amount} cargos registrados`;

    }


    /* =====================================================
       INDICADORES
    ===================================================== */

    function updateStats() {

        totalPositions.textContent =
            positions.length;


        const workersWithPosition =
            workers.filter(worker => {

                const position =
                    positions.find(
                        item =>
                            Number(item.id) ===
                            Number(worker.positionId)
                    );

                return Boolean(position);

            });


        assignedWorkers.textContent =
            workersWithPosition.length;


        activePositions.textContent =
            positions.filter(
                position =>
                    position.status === "Activo"
            ).length;

    }


    /* =====================================================
       BUSCADOR
    ===================================================== */

    positionSearch.addEventListener(
        "input",
        renderPositions
    );


    /* =====================================================
       FILTRO
    ===================================================== */

    positionStatusFilter.addEventListener(
        "change",
        renderPositions
    );


    /* =====================================================
       ABRIR NUEVO CARGO
    ===================================================== */

    openPositionModal.addEventListener(
        "click",
        () => {

            editingPositionId = null;

            positionForm.reset();

            clearErrors();

            positionStatus.value =
                "Activo";


            positionModalTitle.textContent =
                "Nuevo cargo";


            positionModalDescription.textContent =
                "Registra un cargo para los trabajadores.";


            positionSubmitText.textContent =
                "Guardar cargo";


            openModal();


            setTimeout(
                () => positionName.focus(),
                100
            );

        }
    );


    /* =====================================================
       GUARDAR / EDITAR CARGO
    ===================================================== */

    positionForm.addEventListener(
        "submit",
        event => {

            event.preventDefault();

            clearErrors();


            const name =
                positionName.value.trim();


            const description =
                positionDescription.value.trim();


            const status =
                positionStatus.value;


            /* =================================================
               VALIDAR NOMBRE
            ================================================= */

            if (!name) {

                setError(
                    positionName,
                    "Ingresa el nombre del cargo."
                );

                positionName.focus();

                return;
            }


            if (name.length < 2) {

                setError(
                    positionName,
                    "El nombre del cargo es demasiado corto."
                );

                positionName.focus();

                return;
            }


            /* =================================================
               EVITAR DUPLICADOS
            ================================================= */

            const duplicate =
                SIGEP_STORAGE.positionExists(
                    name,
                    editingPositionId
                );


            if (duplicate) {

                setError(
                    positionName,
                    "Ya existe un cargo con este nombre."
                );

                positionName.focus();

                return;
            }


            /* =================================================
               NUEVO CARGO
            ================================================= */

            if (editingPositionId === null) {

                const newPosition = {

                    id:
                        SIGEP_STORAGE
                            .generatePositionId(
                                positions
                            ),

                    name:
                        name,

                    description:
                        description,

                    status:
                        status

                };


                positions.push(
                    newPosition
                );

            }

            /* =================================================
               EDITAR CARGO
            ================================================= */

            else {

                const position =
                    positions.find(
                        position =>
                            Number(position.id) ===
                            Number(editingPositionId)
                    );


                if (!position) {

                    alert(
                        "No se pudo encontrar el cargo."
                    );

                    return;
                }


                /*
                 * Si se intenta dejar inactivo
                 * desde el formulario y tiene
                 * trabajadores activos, evitamos
                 * el cambio.
                 */

                if (
                    status === "Inactivo" &&
                    position.status === "Activo"
                ) {

                    const activeAssignedWorkers =
                        getActiveWorkersByPosition(
                            position.id
                        );


                    if (
                        activeAssignedWorkers.length > 0
                    ) {

                        alert(
                            `No puedes desactivar "${position.name}" ` +
                            `porque tiene ${activeAssignedWorkers.length} ` +
                            `trabajador(es) activo(s) asignado(s).`
                        );

                        positionStatus.value =
                            "Activo";

                        return;
                    }

                }


                position.name =
                    name;

                position.description =
                    description;

                position.status =
                    status;

            }


            /* =================================================
               GUARDAR
            ================================================= */

            SIGEP_STORAGE.savePositions(
                positions
            );


            closeModal();

            render();

        }
    );


    /* =====================================================
       CLICK EN BOTÓN ⋮
    ===================================================== */

    positionsTableBody.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    ".position-action-button"
                );


            if (!button) {
                return;
            }


            event.stopPropagation();


            selectedPositionId =
                Number(
                    button.dataset.positionId
                );


            updateActionMenu();

            showActionMenu(
                button
            );

        }
    );


    /* =====================================================
       MENÚ DE ACCIONES
    ===================================================== */

    positionActionsMenu.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    "button[data-action]"
                );


            if (!button) {
                return;
            }


            const action =
                button.dataset.action;


            hideActionMenu();

            if (action === "close") return;

            if (action === "delete") {
                deletePosition();
                return;
            }

            if (action === "edit") {

                editPosition();

            }


            if (action === "toggle") {

                togglePosition();

            }

        }
    );


    /* =====================================================
       EDITAR CARGO
    ===================================================== */

    function editPosition() {

        refreshData();


        const position =
            positions.find(
                position =>
                    Number(position.id) ===
                    Number(selectedPositionId)
            );


        if (!position) {
            return;
        }


        editingPositionId =
            position.id;


        positionName.value =
            position.name;


        positionDescription.value =
            position.description || "";


        positionStatus.value =
            position.status;


        positionModalTitle.textContent =
            "Editar cargo";


        positionModalDescription.textContent =
            "Modifica la información del cargo seleccionado.";


        positionSubmitText.textContent =
            "Guardar cambios";


        clearErrors();

        openModal();


        setTimeout(
            () => positionName.focus(),
            100
        );

    }


    /* =====================================================
       ACTIVAR / DESACTIVAR
    ===================================================== */

    async function togglePosition() {

        refreshData();


        const position =
            positions.find(
                position =>
                    Number(position.id) ===
                    Number(selectedPositionId)
            );


        if (!position) {
            return;
        }


        /* =================================================
           DESACTIVAR
        ================================================= */

        if (position.status === "Activo") {

            const activeAssignedWorkers =
                getActiveWorkersByPosition(
                    position.id
                );


            /*
             * Regla importante:
             *
             * No dejamos desactivar un cargo
             * utilizado por trabajadores activos.
             */

            if (
                activeAssignedWorkers.length > 0
            ) {

                await SIGEP_CONFIRM({title:"No se puede desactivar este cargo",message:`Tiene ${activeAssignedWorkers.length} trabajador(es) activo(s) asignado(s). Reasigna primero al personal.`,name:position.name,confirmText:"Entendido",danger:false});
                return;
            }


            const confirmation = await SIGEP_CONFIRM({title:"¿Deseas desactivar este cargo?",message:"El cargo dejará de estar disponible para nuevas asignaciones.",name:position.name,confirmText:"Desactivar cargo",danger:true});


            if (!confirmation) {
                return;
            }


            position.status =
                "Inactivo";

        }

        /* =================================================
           ACTIVAR
        ================================================= */

        else {

            const confirmation = await SIGEP_CONFIRM({title:"¿Deseas activar este cargo?",message:"Volverá a estar disponible para nuevas asignaciones.",name:position.name,confirmText:"Activar cargo",danger:false});


            if (!confirmation) {
                return;
            }


            position.status =
                "Activo";

        }


        SIGEP_STORAGE.savePositions(
            positions
        );


        render();

    }


    /* =====================================================
       TRABAJADORES ACTIVOS POR CARGO
    ===================================================== */

    function getActiveWorkersByPosition(
        positionId
    ) {

        return workers.filter(
            worker =>

                Number(worker.positionId) ===
                Number(positionId)

                &&

                worker.status === "Activo"
        );

    }


    /* =====================================================
       ELIMINAR CARGO
    ===================================================== */

    async function deletePosition() {
        refreshData();
        const position = positions.find(item => Number(item.id) === Number(selectedPositionId));
        if (!position) return;

        const assigned = workers.filter(worker => Number(worker.positionId) === Number(position.id));
        if (assigned.length > 0) {
            await SIGEP_CONFIRM({title:"No se puede eliminar este cargo",message:`Tiene ${assigned.length} trabajador(es) asignado(s). Reasigna primero al personal.`,name:position.name,confirmText:"Entendido",danger:false});
            return;
        }

        if (!(await SIGEP_CONFIRM({title:"¿Eliminar permanentemente este cargo?",message:"Esta acción no se puede deshacer.",name:position.name,confirmText:"Eliminar cargo",danger:true}))) return;
        positions = positions.filter(item => Number(item.id) !== Number(position.id));
        SIGEP_STORAGE.savePositions(positions);
        selectedPositionId = null;
        render();
    }

    /* =====================================================
       ACTUALIZAR MENÚ
    ===================================================== */

    function updateActionMenu() {

        const position =
            positions.find(
                position =>
                    Number(position.id) ===
                    Number(selectedPositionId)
            );


        if (!position) {
            return;
        }


        const summary = document.getElementById("positionActionSummary");
        const assigned = workers.filter(worker => Number(worker.positionId) === Number(position.id)).length;
        if (summary) {
            summary.innerHTML = `<div class="position-actions-summary-icon"><i class="fa-solid fa-briefcase"></i></div><div><strong>${escapeHTML(position.name)}</strong><span>${escapeHTML(position.description || "Sin descripción")} · ${assigned} ${assigned === 1 ? "trabajador" : "trabajadores"}</span></div><span class="position-status ${position.status === "Activo" ? "active" : "inactive"}">${escapeHTML(position.status)}</span>`;
        }

        const toggleButton =
            positionActionsMenu.querySelector(
                '[data-action="toggle"]'
            );


        if (!toggleButton) {
            return;
        }


        if (position.status === "Activo") {

            toggleButton.innerHTML = `<i class="fa-solid fa-ban"></i><span><strong>Desactivar cargo</strong><small>Dejar de ofrecerlo para nuevas asignaciones.</small></span>`;


            toggleButton.classList.add(
                "danger-action"
            );

        } else {

            toggleButton.innerHTML = `<i class="fa-solid fa-circle-check"></i><span><strong>Activar cargo</strong><small>Volver a habilitarlo para asignaciones.</small></span>`;


            toggleButton.classList.remove(
                "danger-action"
            );

        }

    }


    /* =====================================================
       POSICIONAR MENÚ
    ===================================================== */

    function showActionMenu() {
        positionActionsMenu.classList.add("show");
        positionActionsMenu.setAttribute("aria-hidden", "false");
        document.body.style.overflow = "hidden";
    }


    /* =====================================================
       OCULTAR MENÚ
    ===================================================== */

    function hideActionMenu() {

        positionActionsMenu.classList.remove("show");
        positionActionsMenu.setAttribute("aria-hidden", "true");
        if (!positionModal.classList.contains("show")) document.body.style.overflow = "";

    }


    document.addEventListener(
        "click",
        event => {

            if (
                !event.target.closest(
                    "#positionActionsMenu"
                )
            ) {

                hideActionMenu();

            }

        }
    );


    window.addEventListener(
        "scroll",
        hideActionMenu,
        true
    );


    window.addEventListener(
        "resize",
        hideActionMenu
    );


    /* =====================================================
       MODAL
    ===================================================== */

    function openModal() {

        positionModal.classList.add(
            "show"
        );


        document.body.style.overflow =
            "hidden";

    }


    function closeModal() {

        positionModal.classList.remove(
            "show"
        );


        document.body.style.overflow =
            "";


        positionForm.reset();

        clearErrors();

        editingPositionId = null;

    }


    closePositionModal.addEventListener(
        "click",
        closeModal
    );


    cancelPositionModal.addEventListener(
        "click",
        closeModal
    );


    positionModal.addEventListener(
        "click",
        event => {

            if (
                event.target ===
                positionModal
            ) {

                closeModal();

            }

        }
    );


    /* =====================================================
       ESC
    ===================================================== */

    document.addEventListener(
        "keydown",
        event => {

            if (event.key === "Escape") {

                if (
                    positionActionsMenu
                        .classList
                        .contains("show")
                ) {

                    hideActionMenu();

                    return;
                }


                if (
                    positionModal
                        .classList
                        .contains("show")
                ) {

                    closeModal();

                }

            }

        }
    );


    /* =====================================================
       ERRORES
    ===================================================== */

    function setError(
        input,
        message
    ) {

        const group =
            input.closest(
                ".position-form-group"
            );


        if (!group) {
            return;
        }


        group.classList.add(
            "has-error"
        );


        const error =
            group.querySelector(
                ".position-form-error"
            );


        if (error) {

            error.textContent =
                message;

        }

    }


    function clearErrors() {

        document
            .querySelectorAll(
                ".position-form-group"
            )
            .forEach(group => {

                group.classList.remove(
                    "has-error"
                );

                const error =
                    group.querySelector(
                        ".position-form-error"
                    );


                if (error) {

                    error.textContent =
                        "";

                }

            });

    }


    /* =====================================================
       ESCAPAR HTML
    ===================================================== */

    function escapeHTML(value) {

        const div =
            document.createElement("div");


        div.textContent =
            value ?? "";


        return div.innerHTML;

    }


    /* =====================================================
       SIDEBAR MÓVIL
    ===================================================== */

    if (
        mobileMenu &&
        sidebar
    ) {

        mobileMenu.addEventListener(
            "click",
            event => {

                event.stopPropagation();


                sidebar.classList.toggle(
                    "open"
                );

            }
        );

    }


    /* =====================================================
       CERRAR SESIÓN
    ===================================================== */

    if (logoutButton) {

        logoutButton.addEventListener(
            "click",
            () => {

                const confirmation =
                    confirm(
                        "¿Estás seguro de que deseas cerrar sesión?"
                    );


                if (!confirmation) {
                    return;
                }


                localStorage.removeItem(
                    "sigep_session"
                );


                sessionStorage.removeItem(
                    "sigep_session"
                );


                window.location.href =
                    "../index.html";

            }
        );

    }


    /* =====================================================
       INICIAR
    ===================================================== */

    render();

});