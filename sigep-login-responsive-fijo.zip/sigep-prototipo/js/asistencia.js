document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       ELEMENTOS
    ====================================================== */

    const dashboardDate =
        document.getElementById("dashboardDate");

    const attendanceDateText =
        document.getElementById("attendanceDateText");

    const attendanceDate =
        document.getElementById("attendanceDate");

    const previousAttendanceDay =
        document.getElementById("previousAttendanceDay");

    const nextAttendanceDay =
        document.getElementById("nextAttendanceDay");

    const attendanceTodayButton =
        document.getElementById("attendanceTodayButton");

    const attendanceTableBody =
        document.getElementById("attendanceTableBody");

    const attendanceResultText =
        document.getElementById("attendanceResultText");

    const attendanceSearch =
        document.getElementById("attendanceSearch");

    const attendanceStatusFilter =
        document.getElementById("attendanceStatusFilter");

    const totalScheduled =
        document.getElementById("totalScheduled");
    const attendanceDetailModal =
    document.getElementById("attendanceDetailModal");

const closeAttendanceModal =
    document.getElementById("closeAttendanceModal");

const cancelAttendanceModal =
    document.getElementById("cancelAttendanceModal");

const attendanceModalOverlay =
    document.getElementById("attendanceModalOverlay");

const detailWorkerAvatar =
    document.getElementById("detailWorkerAvatar");

const detailWorkerName =
    document.getElementById("detailWorkerName");

const detailWorkerInfo =
    document.getElementById("detailWorkerInfo");

const detailDate =
    document.getElementById("detailDate");

const detailSchedule =
    document.getElementById("detailSchedule");

const detailTolerance =
    document.getElementById("detailTolerance");

const detailEntry =
    document.getElementById("detailEntry");

const detailExit =
    document.getElementById("detailExit");

const detailEntry2 =
    document.getElementById("detailEntry2");

const detailExit2 =
    document.getElementById("detailExit2");

const detailStatus =
    document.getElementById("detailStatus");

const detailObservation =
    document.getElementById("detailObservation");
const regularizeAttendanceButton =
    document.getElementById("regularizeAttendanceButton");

const attendanceRegularizationForm =
    document.getElementById("attendanceRegularizationForm");

const regularizationOriginalStatus =
    document.getElementById("regularizationOriginalStatus");

const regularizationStatus =
    document.getElementById("regularizationStatus");

const regularizationReason =
    document.getElementById("regularizationReason");

const regularizationError =
    document.getElementById("regularizationError");

const cancelRegularizationButton =
    document.getElementById("cancelRegularizationButton");

const saveRegularizationButton =
    document.getElementById("saveRegularizationButton");
let selectedAttendanceWorkerId = null;

    /* =====================================================
       STORAGE
    ====================================================== */

    const STORAGE =
        window.SIGEP_STORAGE;

    if (!STORAGE) {
        console.error(
            "SIGEP_STORAGE no está disponible."
        );
        return;
    }


    /* =====================================================
       FECHA ACTUAL
    ====================================================== */

    function getTodayISO() {

        const today =
            new Date();

        const year =
            today.getFullYear();

        const month =
            String(today.getMonth() + 1)
                .padStart(2, "0");

        const day =
            String(today.getDate())
                .padStart(2, "0");

        return `${year}-${month}-${day}`;
    }


    let selectedDate =
        getTodayISO();


    /* =====================================================
       CONVERTIR FECHA ISO
    ====================================================== */

    function parseISODate(dateString) {

        const [year, month, day] =
            dateString
                .split("-")
                .map(Number);

        return new Date(
            year,
            month - 1,
            day
        );
    }


    /* =====================================================
       CONVERTIR DATE A ISO
    ====================================================== */

    function dateToISO(date) {

        const year =
            date.getFullYear();

        const month =
            String(date.getMonth() + 1)
                .padStart(2, "0");

        const day =
            String(date.getDate())
                .padStart(2, "0");

        return `${year}-${month}-${day}`;
    }


    /* =====================================================
       FORMATEAR FECHA
    ====================================================== */

    function formatLongDate(dateString) {

        const date =
            parseISODate(dateString);

        const formatted =
            new Intl.DateTimeFormat(
                "es-PE",
                {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                    year: "numeric"
                }
            ).format(date);

        return (
            formatted.charAt(0).toUpperCase() +
            formatted.slice(1)
        );
    }


    /* =====================================================
       RENDERIZAR ASISTENCIA
    ====================================================== */

   function renderAttendance() {

    const schedules =
        STORAGE
            .getSchedulesByDate(selectedDate)
            .filter(
                schedule =>
                    schedule.journey !== "Libre" && !schedule.replacementWorkerId
            );

    attendanceTableBody.innerHTML = "";

    totalScheduled.textContent =
        schedules.length;
let presentCount = 0;
let lateCount = 0;
let absentCount = 0;

    attendanceResultText.textContent =
        `${schedules.length} ${
            schedules.length === 1
                ? "trabajador"
                : "trabajadores"
        }`;


    /* ================================================
       CONVERTIR HORA A MINUTOS
    ================================================= */

    function timeToMinutes(time) {

        if (!time || !time.includes(":")) {
            return null;
        }

        const [hours, minutes] =
            time.split(":").map(Number);

        return (hours * 60) + minutes;
    }


    /* ================================================
       MOSTRAR HORA EN FORMATO 12 HORAS
    ================================================= */

    function formatTime12(time) {

        if (!time || time === "—") {
            return "—";
        }

        const [hour, minute] =
            time.split(":").map(Number);

        const period =
            hour >= 12
                ? "p. m."
                : "a. m.";

        const hour12 =
            hour % 12 || 12;

        return `${hour12}:${String(minute).padStart(2, "0")} ${period}`;
    }


    /* COLUMNAS DE MARCACIÓN SEGÚN LA JORNADA DEL DÍA */
    const hasCompleteSchedule = schedules.some(schedule => schedule.journey === "Completo");
    const entry1Header = document.getElementById("attendanceEntry1Header");
    const exit1Header = document.getElementById("attendanceExit1Header");
    const entry2Header = document.getElementById("attendanceEntry2Header");
    const exit2Header = document.getElementById("attendanceExit2Header");
    if (entry1Header) entry1Header.textContent = hasCompleteSchedule ? "Entrada 1" : "Entrada";
    if (exit1Header) exit1Header.textContent = hasCompleteSchedule ? "Salida 1" : "Salida";
    if (entry2Header) entry2Header.style.display = hasCompleteSchedule ? "" : "none";
    if (exit2Header) exit2Header.style.display = hasCompleteSchedule ? "" : "none";

    /* SIN PROGRAMACIÓN */

    if (schedules.length === 0) {

        attendanceTableBody.innerHTML = `
            <tr>
                <td
                    colspan="7"
                    class="attendance-empty"
                >
                    No hay trabajadores programados
                    para este día.
                </td>
            </tr>
        `;

        return;
    }


    /* MOSTRAR TRABAJADORES */

    schedules.forEach(schedule => {

        const worker =
            STORAGE.getWorkerById(
                schedule.workerId
            );

        if (!worker) {
            return;
        }


        const workerName =
            STORAGE.getWorkerFullName(
                worker
            );


        const position =
            STORAGE.getWorkerPositionName(
                worker
            );

        const replacementSource = schedule.isReplacement && schedule.replacementForWorkerId
            ? STORAGE.getWorkerById(schedule.replacementForWorkerId)
            : null;

        const replacementSourceName = replacementSource
            ? STORAGE.getWorkerFullName(replacementSource)
            : "";


        /* ================================================
           MARCACIONES BIOMÉTRICAS
        ================================================= */

        const biometricMarks =
            STORAGE.getWorkerBiometricMarks(
                worker.id,
                selectedDate
            );


        // Para jornadas completas se admiten cuatro marcaciones.
        // También se conserva compatibilidad con las marcas antiguas Entrada/Salida.
        const entryMark = biometricMarks.find(mark =>
            mark.type === "Entrada 1" || mark.type === "Entrada"
        );

        const exitMark = biometricMarks.find(mark =>
            mark.type === "Salida 1" || mark.type === "Salida"
        );

        const entry2Mark = biometricMarks.find(mark =>
            mark.type === "Entrada 2"
        );

        const exit2Mark = biometricMarks.find(mark =>
            mark.type === "Salida 2"
        );

        const entryTime = entryMark ? entryMark.time : null;
        const exitTime = exitMark ? exitMark.time : null;
        const entry2Time = entry2Mark ? entry2Mark.time : null;
        const exit2Time = exit2Mark ? exit2Mark.time : null;


        /* ================================================
           HORARIO PROGRAMADO
        ================================================= */

        let hours = "—";

        let scheduledEntry = null;


        if (schedule.journey === "Completo") {

            scheduledEntry =
                schedule.entry1 || null;

            const first =
                schedule.entry1 &&
                schedule.exit1
                    ? `${formatTime12(schedule.entry1)} - ${formatTime12(schedule.exit1)}`
                    : "";


            const second =
                schedule.entry2 &&
                schedule.exit2
                    ? `${formatTime12(schedule.entry2)} - ${formatTime12(schedule.exit2)}`
                    : "";


            hours =
                [first, second]
                    .filter(Boolean)
                    .join("<br>") ||
                "—";

        } else {

            scheduledEntry =
                schedule.entry || null;

            if (
                schedule.entry &&
                schedule.exit
            ) {

                hours =
                    `${formatTime12(schedule.entry)} - ${formatTime12(schedule.exit)}`;
            }
        }


        /* ================================================
           CALCULAR ESTADO
        ================================================= */

        let attendanceStatus =
            "Pendiente";

        let attendanceClass =
            "pending";

if (
    entryTime &&
    scheduledEntry
) {

    const scheduledMinutes =
        timeToMinutes(scheduledEntry);

    const entryMinutes =
        timeToMinutes(entryTime);

    const tolerance =
        Number(schedule.tolerance) || 0;


    if (
        entryMinutes <=
        scheduledMinutes + tolerance
    ) {

        attendanceStatus = "Presente";
        attendanceClass = "present";

        presentCount++;

    } else {

        attendanceStatus = "Tardanza";
        attendanceClass = "late";

        lateCount++;
    }

} else if (!entryTime) {

    /* ================================================
       VERIFICAR SI YA TERMINÓ LA JORNADA
    ================================================= */

    let scheduledExit = null;

    if (schedule.journey === "Completo") {
        scheduledExit =
            schedule.exit2 ||
            schedule.exit1 ||
            null;
    } else {
        scheduledExit =
            schedule.exit || null;
    }


    /*
     * Solo calculamos una falta automáticamente
     * cuando estamos viendo el día actual.
     */

    if (
        selectedDate === getTodayISO() &&
        scheduledExit
    ) {

        const now = new Date();

        const currentMinutes =
            (now.getHours() * 60) +
            now.getMinutes();

        const exitMinutes =
            timeToMinutes(scheduledExit);


        if (
            exitMinutes !== null &&
            currentMinutes > exitMinutes
        ) {

            attendanceStatus = "Falta";
            attendanceClass = "absent";

            absentCount++;
        }
    }


    /*
     * Si estamos viendo una fecha anterior
     * y no existe entrada, ya se considera falta.
     */

    if (
        selectedDate < getTodayISO()
    ) {

        attendanceStatus = "Falta";
        attendanceClass = "absent";

        absentCount++;
    }
}


        /* ================================================
           APLICAR REGULARIZACIÓN ADMINISTRATIVA
        ================================================= */

        const regularization =
            typeof STORAGE.getAttendanceRegularization === "function"
                ? STORAGE.getAttendanceRegularization(
                    worker.id,
                    selectedDate
                )
                : null;

        if (regularization) {

            /* Quitar del contador el estado calculado originalmente */

            if (attendanceStatus === "Presente") {
                presentCount = Math.max(0, presentCount - 1);
            } else if (attendanceStatus === "Tardanza") {
                lateCount = Math.max(0, lateCount - 1);
            } else if (attendanceStatus === "Falta") {
                absentCount = Math.max(0, absentCount - 1);
            }

            /* Dar prioridad al estado regularizado */

            attendanceStatus = regularization.status;

            if (attendanceStatus === "Presente") {
                attendanceClass = "present";
                presentCount++;
            } else if (attendanceStatus === "Tardanza") {
                attendanceClass = "late";
                lateCount++;
            } else if (
                attendanceStatus === "Falta" ||
                attendanceStatus === "Falta justificada"
            ) {
                attendanceClass = "absent";
                absentCount++;
            } else {
                attendanceClass = "pending";
            }
        }


        /* ================================================
           INICIALES
        ================================================= */

        const initials =
            workerName
                .split(" ")
                .filter(Boolean)
                .slice(0, 2)
                .map(
                    word =>
                        word
                            .charAt(0)
                            .toUpperCase()
                )
                .join("");


        /* ================================================
           FILA
        ================================================= */

        const row =
            document.createElement("tr");


        row.innerHTML = `
            <td>

                <div class="attendance-worker">

                    <div class="attendance-worker-avatar">
                        ${initials}
                    </div>

                    <div class="attendance-worker-info">

                        <strong>
                            ${workerName}
                        </strong>

                        <span>
                            ${worker.code || ""}
                        </span>
                        ${replacementSourceName ? `<small class="attendance-replacement-note"><i class="fa-solid fa-arrow-right-arrow-left"></i> Reemplazo de ${replacementSourceName}</small>` : ""}

                    </div>

                </div>

            </td>


            <td>
                ${position}
            </td>


            <td class="attendance-schedule-cell">
                <strong>${hours}</strong>
                <small>Tolerancia: ${Number(schedule.tolerance) || 0} min</small>
            </td>


            <td>
                ${formatTime12(entryTime)}
            </td>


            <td>
                ${formatTime12(exitTime)}
            </td>

            <td class="attendance-second-mark" style="${hasCompleteSchedule ? "" : "display:none"}">
                ${schedule.journey === "Completo" ? formatTime12(entry2Time) : "—"}
            </td>

            <td class="attendance-second-mark" style="${hasCompleteSchedule ? "" : "display:none"}">
                ${schedule.journey === "Completo" ? formatTime12(exit2Time) : "—"}
            </td>


            <td>

                <span class="attendance-status ${attendanceClass}">
                    ${attendanceStatus}
                </span>

            </td>


            <td>

                <button
    type="button"
    class="attendance-action-button"
    title="Ver asistencia"
    data-worker-id="${worker.id}"
>
                    <i class="fa-solid fa-ellipsis"></i>
                </button>

            </td>
        `;
row.dataset.workerId = worker.id;
row.dataset.workerName = workerName;
row.dataset.workerCode = worker.code || "";
row.dataset.position = position;
row.dataset.schedule = hours;
row.dataset.tolerance = Number(schedule.tolerance) || 0;
row.dataset.entry = entryTime || "";
row.dataset.exit = exitTime || "";
row.dataset.entry2 = entry2Time || "";
row.dataset.exit2 = exit2Time || "";
row.dataset.journey = schedule.journey || "";
row.dataset.status = attendanceStatus;
row.dataset.statusClass = attendanceClass;
row.dataset.replacementSource = replacementSourceName;
    attendanceTableBody
    .appendChild(row);

});


const totalPresent =
    document.getElementById("totalPresent");

const totalLate =
    document.getElementById("totalLate");

const totalAbsent =
    document.getElementById("totalAbsent");


if (totalPresent) {
    totalPresent.textContent = presentCount;
}

if (totalLate) {
    totalLate.textContent = lateCount;
}

if (totalAbsent) {
    totalAbsent.textContent = absentCount;
}

applyAttendanceFilters();
}

function applyAttendanceFilters() {
    const query = (attendanceSearch?.value || "").trim().toLowerCase();
    const status = attendanceStatusFilter?.value || "";
    const rows = Array.from(attendanceTableBody?.querySelectorAll("tr[data-worker-id]") || []);
    let visible = 0;

    rows.forEach(row => {
        const haystack = `${row.dataset.workerName || ""} ${row.dataset.workerCode || ""} ${row.dataset.position || ""}`.toLowerCase();
        const matchesQuery = !query || haystack.includes(query);
        const matchesStatus = !status || row.dataset.status === status;
        const show = matchesQuery && matchesStatus;
        row.style.display = show ? "" : "none";
        if (show) visible++;
    });

    if (rows.length && attendanceResultText) {
        attendanceResultText.textContent = `${visible} ${visible === 1 ? "trabajador" : "trabajadores"}`;
    }
}


    /* =====================================================
       RENDERIZAR FECHA
    ====================================================== */

    function renderDate() {

        attendanceDateText.textContent =
            formatLongDate(selectedDate);

        attendanceDate.value =
            selectedDate;

        renderAttendance();
    }


    /* =====================================================
       FECHA DEL TOPBAR
    ====================================================== */

    function renderDashboardDate() {

        if (!dashboardDate) {
            return;
        }

        dashboardDate.textContent =
            formatLongDate(
                getTodayISO()
            );
    }


    /* =====================================================
       DÍA ANTERIOR
    ====================================================== */

    previousAttendanceDay
        ?.addEventListener(
            "click",
            () => {

                const date =
                    parseISODate(
                        selectedDate
                    );

                date.setDate(
                    date.getDate() - 1
                );

                selectedDate =
                    dateToISO(date);

                renderDate();
            }
        );


    /* =====================================================
       DÍA SIGUIENTE
    ====================================================== */

    nextAttendanceDay
        ?.addEventListener(
            "click",
            () => {

                const date =
                    parseISODate(
                        selectedDate
                    );

                date.setDate(
                    date.getDate() + 1
                );

                selectedDate =
                    dateToISO(date);

                renderDate();
            }
        );


    /* =====================================================
       BOTÓN HOY
    ====================================================== */

    attendanceTodayButton
        ?.addEventListener(
            "click",
            () => {

                selectedDate =
                    getTodayISO();

                renderDate();
            }
        );


    /* =====================================================
       CALENDARIO
    ====================================================== */

    attendanceDate
        ?.addEventListener(
            "change",
            () => {

                if (
                    !attendanceDate.value
                ) {
                    return;
                }

                selectedDate =
                    attendanceDate.value;

                renderDate();
            }
        );

/* =====================================================
   MODAL DETALLE DE ASISTENCIA
====================================================== */

function formatTime12ForModal(time) {

    if (!time || !time.includes(":")) {
        return "—";
    }

    const [hour, minute] =
        time.split(":").map(Number);

    const period =
        hour >= 12
            ? "p. m."
            : "a. m.";

    const hour12 =
        hour % 12 || 12;

    return `${hour12}:${String(minute).padStart(2, "0")} ${period}`;
}


function openDetailModal(row) {

    if (!attendanceDetailModal || !row) {
        return;
    }

    selectedAttendanceWorkerId =
        Number(row.dataset.workerId);

    const workerName =
        row.dataset.workerName || "Trabajador";

    const workerCode =
        row.dataset.workerCode || "";

    const position =
        row.dataset.position || "Sin cargo";

    const schedule =
        row.dataset.schedule || "—";

    const tolerance =
        Number(row.dataset.tolerance) || 0;

    const entry =
        row.dataset.entry || "";

    const exit =
        row.dataset.exit || "";

    const entry2 =
        row.dataset.entry2 || "";

    const exit2 =
        row.dataset.exit2 || "";

    const journey =
        row.dataset.journey || "";

    const status =
        row.dataset.status || "Pendiente";

    const statusClass =
        row.dataset.statusClass || "pending";

    const replacementSourceName =
        row.dataset.replacementSource || "";


    /* INICIALES */

    const initials =
        workerName
            .split(" ")
            .filter(Boolean)
            .slice(0, 2)
            .map(word =>
                word.charAt(0).toUpperCase()
            )
            .join("");


    /* TRABAJADOR */

    detailWorkerAvatar.textContent =
        initials || "--";

    detailWorkerName.textContent =
        workerName;

    detailWorkerInfo.textContent =
        workerCode
            ? `${workerCode} · ${position}`
            : position;


    /* JORNADA */

    detailDate.textContent =
        formatLongDate(selectedDate);

    detailSchedule.textContent =
        schedule;

    detailTolerance.textContent =
        `${tolerance} min`;


    /* MARCACIONES */

    detailEntry.textContent =
        entry
            ? formatTime12ForModal(entry)
            : "Sin marcación";

    detailExit.textContent =
        exit
            ? formatTime12ForModal(exit)
            : "Sin marcación";

    if (detailEntry2) {
        detailEntry2.textContent = journey === "Completo"
            ? (entry2 ? formatTime12ForModal(entry2) : "Sin marcación")
            : "No aplica";
    }

    if (detailExit2) {
        detailExit2.textContent = journey === "Completo"
            ? (exit2 ? formatTime12ForModal(exit2) : "Sin marcación")
            : "No aplica";
    }


    /* ESTADO */

    detailStatus.textContent =
        status;

    detailStatus.className =
        `attendance-status ${statusClass}`;


    /* OBSERVACIÓN */

    let observation =
        "Esperando información de asistencia.";

    if (status === "Presente") {

        observation =
            "Ingreso registrado dentro del horario y tiempo de tolerancia establecido.";

    } else if (status === "Tardanza") {

        observation =
            "El ingreso fue registrado después del tiempo de tolerancia establecido.";

    } else if (status === "Falta") {

        observation =
            "No se registró una marcación de entrada durante la jornada programada.";

    } else if (status === "Pendiente") {

        observation =
            "La jornada aún se encuentra pendiente de completar sus marcaciones.";
    }


    const savedRegularization =
        typeof STORAGE.getAttendanceRegularization === "function"
            ? STORAGE.getAttendanceRegularization(
                selectedAttendanceWorkerId,
                selectedDate
            )
            : null;

    if (savedRegularization) {
        observation =
            `Asistencia regularizada. Motivo: ${savedRegularization.reason}`;
    }

    if (replacementSourceName) {
        observation += ` Este turno corresponde a un reemplazo autorizado de ${replacementSourceName}.`;
    }

    detailObservation.textContent =
        observation;


    /* ABRIR MODAL */

    attendanceDetailModal.classList.add("active");

    document.body.style.overflow =
        "hidden";
}


function closeDetailModal() {

    if (!attendanceDetailModal) {
        return;
    }

    attendanceDetailModal.classList.remove("active");

    document.body.style.overflow =
        "";
}


/* =====================================================
   CLICK EN LOS TRES PUNTOS
====================================================== */

attendanceTableBody.addEventListener(
    "click",
    event => {

        const button =
            event.target.closest(
                ".attendance-action-button"
            );

        if (!button) {
            return;
        }

        const row =
            button.closest("tr");

        openDetailModal(row);
    }
);


/* =====================================================
   CERRAR MODAL
====================================================== */

closeAttendanceModal?.addEventListener(
    "click",
    closeDetailModal
);

cancelAttendanceModal?.addEventListener(
    "click",
    closeDetailModal
);

attendanceModalOverlay?.addEventListener(
    "click",
    closeDetailModal
);

/* =====================================================
   ABRIR REGULARIZACIÓN
====================================================== */

regularizeAttendanceButton?.addEventListener(
    "click",
    () => {

        if (!attendanceRegularizationForm) {
            console.error(
                "No se encontró el formulario de regularización."
            );
            return;
        }

        const currentStatus =
            detailStatus.textContent.trim();

        let currentClass = "pending";

        if (currentStatus === "Presente") {
            currentClass = "present";
        } else if (currentStatus === "Tardanza") {
            currentClass = "late";
        } else if (currentStatus === "Falta") {
            currentClass = "absent";
        }


        /* MOSTRAR ESTADO ORIGINAL */

        regularizationOriginalStatus.textContent =
            currentStatus;

        regularizationOriginalStatus.className =
            `attendance-status ${currentClass}`;


        /* LIMPIAR FORMULARIO */

        regularizationStatus.value = "";
        regularizationReason.value = "";

        regularizationError.textContent = "";
        regularizationError.classList.remove("active");


        /* MOSTRAR FORMULARIO */

        attendanceRegularizationForm
            .classList.add("active");


        /* OCULTAR BOTÓN */

        regularizeAttendanceButton.style.display =
            "none";
    }
);


/* =====================================================
   CANCELAR REGULARIZACIÓN
====================================================== */

cancelRegularizationButton?.addEventListener(
    "click",
    () => {

        attendanceRegularizationForm
            ?.classList.remove("active");

        regularizeAttendanceButton.style.display =
            "";

        regularizationStatus.value = "";
        regularizationReason.value = "";

        regularizationError.textContent = "";
        regularizationError.classList.remove("active");
    }
);
/* =====================================================
   GUARDAR REGULARIZACIÓN
====================================================== */

saveRegularizationButton?.addEventListener(
    "click",
    () => {

        const newStatus =
            regularizationStatus?.value || "";

        const reason =
            regularizationReason?.value.trim() || "";

        const originalStatus =
            regularizationOriginalStatus?.textContent.trim() ||
            detailStatus?.textContent.trim() ||
            "Pendiente";

        if (!selectedAttendanceWorkerId) {
            regularizationError.textContent =
                "No se pudo identificar al trabajador.";
            regularizationError.classList.add("active");
            return;
        }

        if (!newStatus) {
            regularizationError.textContent =
                "Selecciona el nuevo estado.";
            regularizationError.classList.add("active");
            return;
        }

        if (!reason) {
            regularizationError.textContent =
                "Ingresa el motivo de la regularización.";
            regularizationError.classList.add("active");
            return;
        }

        const saved =
            STORAGE.saveAttendanceRegularization({
                workerId: selectedAttendanceWorkerId,
                date: selectedDate,
                originalStatus,
                status: newStatus,
                reason
            });

        if (!saved) {
            regularizationError.textContent =
                "No se pudo guardar la regularización.";
            regularizationError.classList.add("active");
            return;
        }

        attendanceRegularizationForm
            ?.classList.remove("active");

        regularizeAttendanceButton.style.display =
            "";

        regularizationStatus.value = "";
        regularizationReason.value = "";
        regularizationError.textContent = "";
        regularizationError.classList.remove("active");

        renderAttendance();
        closeDetailModal();
    }
);

/* CERRAR CON ESC */

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key === "Escape" &&
            attendanceDetailModal?.classList.contains("active")
        ) {
            closeDetailModal();
        }
    }
);
attendanceSearch?.addEventListener("input", applyAttendanceFilters);
attendanceStatusFilter?.addEventListener("change", applyAttendanceFilters);

    /* =====================================================
       INICIALIZACIÓN
    ====================================================== */

    renderDashboardDate();

    renderDate();

});