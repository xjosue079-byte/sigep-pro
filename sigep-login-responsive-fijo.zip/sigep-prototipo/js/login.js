// ======================================================
// SIGEP - LOGIN
// Prototipo HTML / CSS / JavaScript
// ======================================================

document.addEventListener("DOMContentLoaded", () => {

    const loginForm = document.getElementById("loginForm");

    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");

    const usernameError = document.getElementById("usernameError");
    const passwordError = document.getElementById("passwordError");

    const loginError = document.getElementById("loginError");

    const togglePassword = document.getElementById("togglePassword");
    const rememberCheckbox = document.getElementById("remember");

    const loginButton = document.getElementById("loginButton");

    const currentYear = document.getElementById("currentYear");


    // ==================================================
    // CREDENCIALES TEMPORALES DEL PROTOTIPO
    // ==================================================

    const savedAdminPassword = localStorage.getItem("sigep_admin_password");

    const loginSettings = (() => {
        try { return JSON.parse(localStorage.getItem("sigep_system_settings") || "{}"); }
        catch (_) { return {}; }
    })();

    const ADMIN_USER = {
        username: "admin",
        password: savedAdminPassword || "admin123",
        name: String(loginSettings.adminName || "Henry").trim() || "Henry",
        email: "admin@sigep.pe"
    };


    // ==================================================
    // AÑO AUTOMÁTICO
    // ==================================================

    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }


    // ==================================================
    // MOSTRAR / OCULTAR CONTRASEÑA
    // ==================================================

    togglePassword.addEventListener("click", () => {

        const icon = togglePassword.querySelector("i");

        if (passwordInput.type === "password") {

            // Mostrar contraseña: ojo abierto
            passwordInput.type = "text";

            icon.classList.remove("fa-eye-slash");
            icon.classList.add("fa-eye");
            togglePassword.setAttribute("aria-label", "Ocultar contraseña");

        } else {

            // Ocultar contraseña: ojo tachado
            passwordInput.type = "password";

            icon.classList.remove("fa-eye");
            icon.classList.add("fa-eye-slash");
            togglePassword.setAttribute("aria-label", "Mostrar contraseña");
        }

    });


    // ==================================================
    // QUITAR ERRORES AL ESCRIBIR
    // ==================================================

    usernameInput.addEventListener("input", () => {

        usernameError.classList.remove("show");
        usernameError.textContent = "";

        loginError.classList.remove("show");

    });


    passwordInput.addEventListener("input", () => {

        passwordError.classList.remove("show");
        passwordError.textContent = "";

        loginError.classList.remove("show");

    });


    // ==================================================
    // VALIDACIÓN DEL FORMULARIO
    // ==================================================

    loginForm.addEventListener("submit", (event) => {

        event.preventDefault();

        clearErrors();


        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();


        let valid = true;


        // ----------------------------------------------
        // Validar usuario
        // ----------------------------------------------

        if (username === "") {

            usernameError.textContent =
                "Ingresa tu usuario.";

            usernameError.classList.add("show");

            valid = false;
        }


        // ----------------------------------------------
        // Validar contraseña
        // ----------------------------------------------

        if (password === "") {

            passwordError.textContent =
                "Ingresa tu contraseña.";

            passwordError.classList.add("show");

            valid = false;
        }


        if (!valid) {
            return;
        }


        // ----------------------------------------------
        // Verificar credenciales
        // ----------------------------------------------

        // admin123 es la credencial inicial. Si el administrador cambia
        // la contraseña desde Configuración, solo la nueva contraseña será válida.
        const validAdminPassword = password === ADMIN_USER.password;

        if (
            username === ADMIN_USER.username &&
            validAdminPassword
        ) {

            loginSuccess();

        } else {

            loginError.classList.add("show");

            passwordInput.value = "";

            passwordInput.focus();
        }

    });


    // ==================================================
    // LOGIN CORRECTO
    // ==================================================

    function loginSuccess() {

        loginButton.disabled = true;

        loginButton.innerHTML = `
            <i class="fa-solid fa-spinner fa-spin"
               style="position: static;"></i>

            <span>Ingresando...</span>
        `;


        // Información de sesión simulada

        const session = {

            username: ADMIN_USER.username,

            name: ADMIN_USER.name,

            role: "Administrador",

            loginDate: new Date().toISOString(),

            authenticated: true
        };


        // ----------------------------------------------
        // Recordar sesión
        // ----------------------------------------------

        if (rememberCheckbox.checked) {

            localStorage.setItem(
                "sigep_session",
                JSON.stringify(session)
            );

        } else {

            sessionStorage.setItem(
                "sigep_session",
                JSON.stringify(session)
            );
        }


        // ----------------------------------------------
        // Simular carga del sistema
        // ----------------------------------------------

        setTimeout(() => {

            window.location.href =
                "pages/dashboard.html";

        }, 700);

    }


    // ==================================================
    // LIMPIAR ERRORES
    // ==================================================

    function clearErrors() {

        usernameError.classList.remove("show");

        passwordError.classList.remove("show");

        loginError.classList.remove("show");


        usernameError.textContent = "";

        passwordError.textContent = "";
    }


    // ==================================================
    // RECUPERAR CONTRASEÑA (FLUJO DEMOSTRATIVO)
    // ==================================================

    const forgotPassword = document.getElementById("forgotPassword");
    const recoveryModal = document.getElementById("recoveryModal");
    const recoveryClose = document.getElementById("recoveryClose");
    const recoverySubtitle = document.getElementById("recoverySubtitle");
    const recoveryEmail = document.getElementById("recoveryEmail");
    const recoveryEmailError = document.getElementById("recoveryEmailError");
    const sendRecoveryCode = document.getElementById("sendRecoveryCode");
    const recoveryCode = document.getElementById("recoveryCode");
    const recoveryCodeError = document.getElementById("recoveryCodeError");
    const verifyRecoveryCode = document.getElementById("verifyRecoveryCode");
    const resendRecoveryCode = document.getElementById("resendRecoveryCode");
    const demoCode = document.getElementById("demoCode");
    const newPassword = document.getElementById("newPassword");
    const confirmPassword = document.getElementById("confirmPassword");
    const recoveryPasswordError = document.getElementById("recoveryPasswordError");
    const saveNewPassword = document.getElementById("saveNewPassword");
    const backToLogin = document.getElementById("backToLogin");

    let generatedRecoveryCode = "";

    function showRecoveryStep(step) {
        document.querySelectorAll(".recovery-step").forEach(item => {
            item.classList.toggle("active", item.dataset.step === step);
        });

        const subtitles = {
            email: "Ingresa el correo asociado a tu cuenta.",
            code: "Verifica tu identidad con el código de seguridad.",
            password: "Crea una contraseña nueva y segura.",
            success: "El proceso se completó correctamente."
        };
        recoverySubtitle.textContent = subtitles[step] || "";
    }

    function openRecovery() {
        recoveryModal.classList.add("active");
        recoveryModal.setAttribute("aria-hidden", "false");
        showRecoveryStep("email");
        recoveryEmail.value = "";
        recoveryCode.value = "";
        newPassword.value = "";
        confirmPassword.value = "";
        setTimeout(() => recoveryEmail.focus(), 50);
    }

    function closeRecovery() {
        recoveryModal.classList.remove("active");
        recoveryModal.setAttribute("aria-hidden", "true");
    }

    function createRecoveryCode() {
        generatedRecoveryCode = String(Math.floor(100000 + Math.random() * 900000));
        demoCode.textContent = generatedRecoveryCode;
    }

    forgotPassword?.addEventListener("click", openRecovery);
    recoveryClose?.addEventListener("click", closeRecovery);
    backToLogin?.addEventListener("click", closeRecovery);

    recoveryModal?.addEventListener("click", event => {
        if (event.target === recoveryModal) closeRecovery();
    });

    sendRecoveryCode?.addEventListener("click", () => {
        const email = recoveryEmail.value.trim().toLowerCase();
        recoveryEmailError.classList.remove("show");

        if (!email) {
            recoveryEmailError.textContent = "Ingresa tu correo electrónico.";
            recoveryEmailError.classList.add("show");
            return;
        }

        if (email !== ADMIN_USER.email) {
            recoveryEmailError.textContent = "No encontramos una cuenta asociada a ese correo.";
            recoveryEmailError.classList.add("show");
            return;
        }

        createRecoveryCode();
        showRecoveryStep("code");
        recoveryCode.focus();
    });

    resendRecoveryCode?.addEventListener("click", () => {
        createRecoveryCode();
        recoveryCode.value = "";
        recoveryCodeError.classList.remove("show");
        recoveryCode.focus();
    });

    recoveryCode?.addEventListener("input", () => {
        recoveryCode.value = recoveryCode.value.replace(/\D/g, "").slice(0, 6);
        recoveryCodeError.classList.remove("show");
    });

    verifyRecoveryCode?.addEventListener("click", () => {
        if (recoveryCode.value !== generatedRecoveryCode) {
            recoveryCodeError.textContent = "El código ingresado no es válido.";
            recoveryCodeError.classList.add("show");
            return;
        }
        showRecoveryStep("password");
        newPassword.focus();
    });

    saveNewPassword?.addEventListener("click", () => {
        const password = newPassword.value;
        const confirmation = confirmPassword.value;
        const validPassword = /^(?=.*[A-Z])(?=.*\d).{8,}$/.test(password);
        recoveryPasswordError.classList.remove("show");

        if (!validPassword) {
            recoveryPasswordError.textContent = "Usa al menos 8 caracteres, una mayúscula y un número.";
            recoveryPasswordError.classList.add("show");
            return;
        }
        if (password !== confirmation) {
            recoveryPasswordError.textContent = "Las contraseñas no coinciden.";
            recoveryPasswordError.classList.add("show");
            return;
        }

        localStorage.setItem("sigep_admin_password", password);
        ADMIN_USER.password = password;
        localStorage.removeItem("sigep_session");
        sessionStorage.removeItem("sigep_session");
        showRecoveryStep("success");
    });

    document.addEventListener("keydown", event => {
        if (event.key === "Escape" && recoveryModal?.classList.contains("active")) {
            closeRecovery();
        }
    });

    // ==================================================
    // SI YA EXISTE SESIÓN RECORDADA
    // ==================================================

    checkExistingSession();


    function checkExistingSession() {

        const savedSession =
            localStorage.getItem("sigep_session");


        if (!savedSession) {
            return;
        }


        try {

            const session =
                JSON.parse(savedSession);


            if (session.authenticated) {

                window.location.href =
                    "pages/dashboard.html";

            }

        } catch (error) {

            localStorage.removeItem(
                "sigep_session"
            );

        }

    }

});