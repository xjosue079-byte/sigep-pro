/* =========================================================
   SIGEP - STORAGE
   Gestión local de datos del prototipo
========================================================= */

const SIGEP_STORAGE = {

    /* =====================================================
       CLAVES DE LOCALSTORAGE
    ===================================================== */

 keys: {
    workers: "sigep_workers",
    positions: "sigep_positions",
    frequentSchedules: "sigep_frequent_schedules",
    dailySchedules: "sigep_daily_schedules",
    biometricMarks: "sigep_biometric_marks",
    attendanceRegularizations: "sigep_attendance_regularizations",
    paymentPeriods: "sigep_payment_periods"
},

    /* =====================================================
       MÉTODOS GENERALES
    ===================================================== */

    get(key) {

        try {

            const data = localStorage.getItem(key);

            if (!data) {
                return null;
            }

            return JSON.parse(data);

        } catch (error) {

            console.error(
                "SIGEP Storage - Error al leer:",
                key,
                error
            );

            return null;
        }
    },


    set(key, value) {

        try {

            localStorage.setItem(
                key,
                JSON.stringify(value)
            );

            return true;

        } catch (error) {

            console.error(
                "SIGEP Storage - Error al guardar:",
                key,
                error
            );

            return false;
        }
    },


    remove(key) {

        try {

            localStorage.removeItem(key);

            return true;

        } catch (error) {

            console.error(
                "SIGEP Storage - Error al eliminar:",
                key,
                error
            );

            return false;
        }
    },


    /* =====================================================
       UTILIDADES
    ===================================================== */

    normalizeText(text) {

        if (text === null || text === undefined) {
            return "";
        }

        return String(text)
            .trim()
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "");
    },


    generateId(list) {

        if (!Array.isArray(list) || list.length === 0) {
            return 1;
        }

        return Math.max(
            ...list.map(item => Number(item.id) || 0)
        ) + 1;
    },


    /* =====================================================
       CARGOS
    ===================================================== */

    initializePositions() {

        const positions = this.get(
            this.keys.positions
        );

        if (Array.isArray(positions)) {
            return;
        }


        const initialPositions = [

            {
                id: 1,
                name: "Administrador",
                description: "Gestión general del sistema",
                status: "Activo"
            },

            {
                id: 2,
                name: "Cajero",
                description: "Atención y cobro a clientes",
                status: "Activo"
            },

            {
                id: 3,
                name: "Reponedor",
                description: "Reposición y orden de productos",
                status: "Activo"
            },

            {
                id: 4,
                name: "Portero",
                description: "Control de ingreso y salida",
                status: "Activo"
            },

            {
                id: 5,
                name: "Vendedor",
                description: "Atención y apoyo en ventas",
                status: "Activo"
            }

        ];


        this.savePositions(
            initialPositions
        );
    },


    getPositions() {

        const positions = this.get(
            this.keys.positions
        );

        return Array.isArray(positions)
            ? positions
            : [];
    },


    savePositions(positions) {

        return this.set(
            this.keys.positions,
            positions
        );
    },


    getPositionById(id) {

        return this
            .getPositions()
            .find(
                position =>
                    Number(position.id) ===
                    Number(id)
            ) || null;
    },


    getPositionByName(name) {

        const normalizedName =
            this.normalizeText(name);

        return this
            .getPositions()
            .find(
                position =>
                    this.normalizeText(
                        position.name
                    ) === normalizedName
            ) || null;
    },


    getActivePositions() {

        return this
            .getPositions()
            .filter(
                position =>
                    position.status === "Activo"
            );
    },


    generatePositionId() {

        return this.generateId(
            this.getPositions()
        );
    },


    positionExists(
        name,
        ignoreId = null
    ) {

        const normalizedName =
            this.normalizeText(name);

        return this
            .getPositions()
            .some(position => {

                const sameName =
                    this.normalizeText(
                        position.name
                    ) === normalizedName;

                const differentId =
                    ignoreId === null ||
                    Number(position.id) !==
                    Number(ignoreId);

                return (
                    sameName &&
                    differentId
                );
            });
    },


    addPosition(positionData) {

        const positions =
            this.getPositions();

        const newPosition = {

            id:
                this.generateId(
                    positions
                ),

            name:
                String(
                    positionData.name || ""
                ).trim(),

            description:
                String(
                    positionData.description || ""
                ).trim(),

            status:
                positionData.status ||
                "Activo"
        };


        positions.push(
            newPosition
        );

        this.savePositions(
            positions
        );

        return newPosition;
    },


    updatePosition(
        id,
        positionData
    ) {

        const positions =
            this.getPositions();

        const index =
            positions.findIndex(
                position =>
                    Number(position.id) ===
                    Number(id)
            );

        if (index === -1) {
            return null;
        }


        positions[index] = {

            ...positions[index],

            ...positionData,

            id:
                positions[index].id
        };


        this.savePositions(
            positions
        );

        return positions[index];
    },


    deletePosition(id) {

        const workers =
            this.getWorkers();

        const positionInUse =
            workers.some(
                worker =>
                    Number(worker.positionId) ===
                    Number(id)
            );


        if (positionInUse) {

            return {
                success: false,
                reason: "POSITION_IN_USE"
            };
        }


        const positions =
            this.getPositions();

        const filtered =
            positions.filter(
                position =>
                    Number(position.id) !==
                    Number(id)
            );


        this.savePositions(
            filtered
        );


        return {
            success: true
        };
    },


    /* =====================================================
       TRABAJADORES
    ===================================================== */

    initializeWorkers() {

        const workers =
            this.get(
                this.keys.workers
            );

        if (Array.isArray(workers)) {
            return;
        }


        const initialWorkers = [

            {
                id: 2,
                code: "EMP-0002",
                documentType: "DNI",
                documentNumber: "71458963",
                firstName: "Ana",
                lastName: "Torres",
                fullName: "Ana Torres",
                phone: "",
                email: "ana.torres@empresa.com",
                positionId: 2,
                status: "Inactivo"
            },

            {
                id: 3,
                code: "EMP-0003",
                documentType: "DNI",
                documentNumber: "72584196",
                firstName: "Carlos",
                lastName: "Díaz",
                fullName: "Carlos Díaz",
                phone: "",
                email: "carlos.diaz@empresa.com",
                positionId: 3,
                status: "Activo"
            },

            {
                id: 4,
                code: "EMP-0004",
                documentType: "DNI",
                documentNumber: "73695214",
                firstName: "Luis",
                lastName: "Ramos",
                fullName: "Luis Ramos",
                phone: "",
                email: "luis.ramos@empresa.com",
                positionId: 4,
                status: "Activo"
            },

            {
                id: 5,
                code: "EMP-0005",
                documentType: "DNI",
                documentNumber: "70123658",
                firstName: "María",
                lastName: "López",
                fullName: "María López",
                phone: "",
                email: "maria.lopez@empresa.com",
                positionId: 5,
                status: "Activo"
            }

        ];


        this.saveWorkers(
            initialWorkers
        );
    },


    getWorkers() {

        const workers =
            this.get(
                this.keys.workers
            );

        return Array.isArray(workers)
            ? workers
            : [];
    },


    saveWorkers(workers) {

        return this.set(
            this.keys.workers,
            workers
        );
    },


    getWorkerById(id) {

        return this
            .getWorkers()
            .find(
                worker =>
                    Number(worker.id) ===
                    Number(id)
            ) || null;
    },
    getWorkerFullName(worker) {

    if (!worker) {
        return "Trabajador";
    }

    return (
        `${worker.names || worker.firstName || ""} ` +
        `${worker.lastNames || worker.lastName || ""}`
    ).trim() ||
    worker.fullName ||
    "Trabajador";
},


    getActiveWorkers() {
        return this.getWorkers().filter(worker => {
            const status = String(worker?.status ?? "Activo").trim().toLowerCase();
            return status === "activo" || status === "active";
        });
    },


    generateWorkerId() {

        return this.generateId(
            this.getWorkers()
        );
    },


    /* =====================================================
       CÓDIGO CORRELATIVO DEL TRABAJADOR
       Ej.: EMP-0001, EMP-0002, ...
    ===================================================== */

    generateWorkerCode(workers = null) {

        const source = Array.isArray(workers)
            ? workers
            : this.getWorkers();

        const maxNumber = source.reduce(
            (max, worker) => {
                const match = String(worker?.code || "")
                    .match(/^EMP-(\d+)$/i);

                if (!match) return max;

                return Math.max(
                    max,
                    Number(match[1]) || 0
                );
            },
            0
        );

        return `EMP-${String(maxNumber + 1).padStart(4, "0")}`;
    },


    workerDocumentExists(
        documentNumber,
        ignoreId = null
    ) {

        const document =
            String(
                documentNumber || ""
            ).trim();

        return this
            .getWorkers()
            .some(worker => {

                const sameDocument =
    String(
        worker.dni ||
        worker.documentNumber ||
        ""
    ).trim() === document;

                const differentId =
                    ignoreId === null ||
                    Number(worker.id) !==
                    Number(ignoreId);

                return (
                    sameDocument &&
                    differentId
                );
            });
    },


    addWorker(workerData) {

        const workers =
            this.getWorkers();

        const newWorker = {

            ...workerData,

            id:
                this.generateId(
                    workers
                )
        };


        if (
            !newWorker.fullName &&
            (
                newWorker.firstName ||
                newWorker.lastName
            )
        ) {

            newWorker.fullName =
                `${newWorker.firstName || ""} ${newWorker.lastName || ""}`
                    .trim();
        }


        if (!newWorker.status) {
            newWorker.status = "Activo";
        }


        workers.push(
            newWorker
        );

        this.saveWorkers(
            workers
        );

        return newWorker;
    },


    updateWorker(
        id,
        workerData
    ) {

        const workers =
            this.getWorkers();

        const index =
            workers.findIndex(
                worker =>
                    Number(worker.id) ===
                    Number(id)
            );

        if (index === -1) {
            return null;
        }


        workers[index] = {

            ...workers[index],

            ...workerData,

            id:
                workers[index].id
        };


        if (
            workerData.firstName !== undefined ||
            workerData.lastName !== undefined
        ) {

            workers[index].fullName =
                `${workers[index].firstName || ""} ${workers[index].lastName || ""}`
                    .trim();
        }


        this.saveWorkers(
            workers
        );

        return workers[index];
    },


    deleteWorker(id) {

        const workers =
            this.getWorkers();

        const filtered =
            workers.filter(
                worker =>
                    Number(worker.id) !==
                    Number(id)
            );


        this.saveWorkers(
            filtered
        );


        /*
         * También eliminamos programaciones
         * relacionadas con el trabajador.
         */

        const dailySchedules =
            this.getDailySchedules();

        const filteredSchedules =
            dailySchedules.filter(
                schedule =>
                    Number(schedule.workerId) !==
                    Number(id)
            );


        this.saveDailySchedules(
            filteredSchedules
        );


        return true;
    },


    getWorkerPositionName(worker) {

        if (!worker) {
            return "Sin cargo";
        }


        if (worker.positionId) {

            const position =
                this.getPositionById(
                    worker.positionId
                );

            if (position) {
                return position.name;
            }
        }


        /*
         * Compatibilidad con trabajadores
         * creados con versiones anteriores.
         */

        if (worker.position) {
            return worker.position;
        }


        if (worker.positionName) {
            return worker.positionName;
        }


        return "Sin cargo";
    },


    /* =====================================================
       MIGRACIÓN DE TRABAJADORES A POSITION ID
    ===================================================== */

    migrateWorkersToPositionId() {

        const workers =
            this.getWorkers();

        let changed = false;


        const migratedWorkers =
            workers.map(worker => {

                /*
                 * Si ya tiene positionId,
                 * no hacemos nada.
                 */

                if (worker.positionId) {
                    return worker;
                }


                const oldPositionName =
                    worker.position ||
                    worker.positionName ||
                    worker.cargo ||
                    null;


                if (!oldPositionName) {
                    return worker;
                }


                const position =
                    this.getPositionByName(
                        oldPositionName
                    );


                if (!position) {
                    return worker;
                }


                changed = true;


                return {

                    ...worker,

                    positionId:
                        position.id
                };

            });


        if (changed) {

            this.saveWorkers(
                migratedWorkers
            );
        }
    },


    /* =====================================================
       HORARIOS FRECUENTES
    ===================================================== */

    initializeFrequentSchedules() {

        const existingSchedules =
            this.get(
                this.keys.frequentSchedules
            );


        if (
            Array.isArray(
                existingSchedules
            )
        ) {
            return;
        }


        /*
         * Horarios frecuentes iniciales.
         *
         * IMPORTANTE:
         * Son atajos, no reglas obligatorias.
         * El administrador podrá crear horarios
         * personalizados en cada programación.
         */

        const initialSchedules = [

            {
                id: 1,

                name:
                    "Mañana 9 a 2",

                journey:
                    "Mañana",

                entry:
                    "09:00",

                exit:
                    "14:00",

                entry1:
                    null,

                exit1:
                    null,

                entry2:
                    null,

                exit2:
                    null,

                tolerance:
                    10,

                status:
                    "Activo"
            },


            {
                id: 2,

                name:
                    "Mañana 10 a 3",

                journey:
                    "Mañana",

                entry:
                    "10:00",

                exit:
                    "15:00",

                entry1:
                    null,

                exit1:
                    null,

                entry2:
                    null,

                exit2:
                    null,

                tolerance:
                    10,

                status:
                    "Activo"
            },


            {
                id: 3,

                name:
                    "Tarde 3 a 8",

                journey:
                    "Tarde",

                entry:
                    "15:00",

                exit:
                    "20:00",

                entry1:
                    null,

                exit1:
                    null,

                entry2:
                    null,

                exit2:
                    null,

                tolerance:
                    10,

                status:
                    "Activo"
            },


            {
                id: 4,

                name:
                    "Tarde 4 a 9",

                journey:
                    "Tarde",

                entry:
                    "16:00",

                exit:
                    "21:00",

                entry1:
                    null,

                exit1:
                    null,

                entry2:
                    null,

                exit2:
                    null,

                tolerance:
                    10,

                status:
                    "Activo"
            },


            {
                id: 5,

                name:
                    "Tarde 3 a 9",

                journey:
                    "Tarde",

                entry:
                    "15:00",

                exit:
                    "21:00",

                entry1:
                    null,

                exit1:
                    null,

                entry2:
                    null,

                exit2:
                    null,

                tolerance:
                    10,

                status:
                    "Activo"
            },


            {
                id: 6,

                name:
                    "Completo 9-2 / 3-8",

                journey:
                    "Completo",

                entry:
                    null,

                exit:
                    null,

                entry1:
                    "09:00",

                exit1:
                    "14:00",

                entry2:
                    "15:00",

                exit2:
                    "20:00",

                tolerance:
                    10,

                status:
                    "Activo"
            },


            {
                id: 7,

                name:
                    "Completo 10-2 / 3-9",

                journey:
                    "Completo",

                entry:
                    null,

                exit:
                    null,

                entry1:
                    "10:00",

                exit1:
                    "14:00",

                entry2:
                    "15:00",

                exit2:
                    "21:00",

                tolerance:
                    10,

                status:
                    "Activo"
            },


            {
                id: 8,

                name:
                    "Completo 10-3 / 4-9",

                journey:
                    "Completo",

                entry:
                    null,

                exit:
                    null,

                entry1:
                    "10:00",

                exit1:
                    "15:00",

                entry2:
                    "16:00",

                exit2:
                    "21:00",

                tolerance:
                    10,

                status:
                    "Activo"
            }

        ];


        this.saveFrequentSchedules(
            initialSchedules
        );
    },


    getFrequentSchedules() {

        const schedules =
            this.get(
                this.keys.frequentSchedules
            );


        return Array.isArray(schedules)
            ? schedules
            : [];
    },


    saveFrequentSchedules(
        schedules
    ) {

        return this.set(
            this.keys.frequentSchedules,
            schedules
        );
    },


    getFrequentScheduleById(id) {

        return this
            .getFrequentSchedules()
            .find(
                schedule =>
                    Number(schedule.id) ===
                    Number(id)
            ) || null;
    },


    getActiveFrequentSchedules() {

        return this
            .getFrequentSchedules()
            .filter(
                schedule =>
                    schedule.status ===
                    "Activo"
            );
    },


    generateFrequentScheduleId() {

        return this.generateId(
            this.getFrequentSchedules()
        );
    },


    frequentScheduleExists(
        name,
        ignoreId = null
    ) {

        const normalizedName =
            this.normalizeText(name);


        return this
            .getFrequentSchedules()
            .some(schedule => {

                const sameName =
                    this.normalizeText(
                        schedule.name
                    ) === normalizedName;


                const differentId =
                    ignoreId === null ||
                    Number(schedule.id) !==
                    Number(ignoreId);


                return (
                    sameName &&
                    differentId
                );
            });
    },


    addFrequentSchedule(
        scheduleData
    ) {

        const schedules =
            this.getFrequentSchedules();


        const newSchedule = {

            id:
                this.generateId(
                    schedules
                ),

            name:
                String(
                    scheduleData.name || ""
                ).trim(),

            journey:
                scheduleData.journey,

            entry:
                scheduleData.entry || null,

            exit:
                scheduleData.exit || null,

            entry1:
                scheduleData.entry1 || null,

            exit1:
                scheduleData.exit1 || null,

            entry2:
                scheduleData.entry2 || null,

            exit2:
                scheduleData.exit2 || null,

            tolerance:
                Number(
                    scheduleData.tolerance
                ) || 0,

            status:
                scheduleData.status ||
                "Activo"
        };


        schedules.push(
            newSchedule
        );


        this.saveFrequentSchedules(
            schedules
        );


        return newSchedule;
    },


    updateFrequentSchedule(
        id,
        scheduleData
    ) {

        const schedules =
            this.getFrequentSchedules();


        const index =
            schedules.findIndex(
                schedule =>
                    Number(schedule.id) ===
                    Number(id)
            );


        if (index === -1) {
            return null;
        }


        schedules[index] = {

            ...schedules[index],

            ...scheduleData,

            id:
                schedules[index].id
        };


        this.saveFrequentSchedules(
            schedules
        );


        return schedules[index];
    },


    toggleFrequentScheduleStatus(id) {

        const schedule =
            this.getFrequentScheduleById(
                id
            );


        if (!schedule) {
            return null;
        }


        const newStatus =
            schedule.status === "Activo"
                ? "Inactivo"
                : "Activo";


        return this.updateFrequentSchedule(
            id,
            {
                status:
                    newStatus
            }
        );
    },


    deleteFrequentSchedule(id) {

        const schedules =
            this.getFrequentSchedules();


        const filtered =
            schedules.filter(
                schedule =>
                    Number(schedule.id) !==
                    Number(id)
            );


        return this.saveFrequentSchedules(
            filtered
        );
    },


    /* =====================================================
       PROGRAMACIÓN DIARIA
    ===================================================== */

    initializeDailySchedules() {

        const existingSchedules =
            this.get(
                this.keys.dailySchedules
            );


        if (
            Array.isArray(
                existingSchedules
            )
        ) {
            return;
        }


        /*
         * La programación empieza vacía porque
         * corresponde a fechas reales.
         */

        this.saveDailySchedules([]);
    },


    getDailySchedules() {

        const schedules =
            this.get(
                this.keys.dailySchedules
            );


        return Array.isArray(schedules)
            ? schedules
            : [];
    },


    saveDailySchedules(
        schedules
    ) {

        return this.set(
            this.keys.dailySchedules,
            schedules
        );
    },


    generateDailyScheduleId(
        schedules = null
    ) {

        const list =
            schedules ||
            this.getDailySchedules();


        return this.generateId(
            list
        );
    },


    /* =====================================================
       PROGRAMACIÓN POR FECHA
    ===================================================== */

    getSchedulesByDate(date) {

        return this
            .getDailySchedules()
            .filter(
                schedule =>
                    schedule.date ===
                    date
            );
    },


    /* =====================================================
       PROGRAMACIÓN DE TRABAJADOR POR FECHA
    ===================================================== */

    getWorkerScheduleByDate(
        workerId,
        date
    ) {

        return this
            .getDailySchedules()
            .find(
                schedule =>
                    Number(
                        schedule.workerId
                    ) ===
                        Number(workerId) &&
                    schedule.date === date
            ) || null;
    },


    /* =====================================================
       GUARDAR O ACTUALIZAR PROGRAMACIÓN
    ===================================================== */

    saveWorkerSchedule(
        scheduleData
    ) {

        if (
            !scheduleData ||
            !scheduleData.workerId ||
            !scheduleData.date ||
            !scheduleData.journey
        ) {

            console.error(
                "SIGEP - Programación inválida",
                scheduleData
            );

            return false;
        }


        const schedules =
            this.getDailySchedules();


        const existingIndex =
            schedules.findIndex(
                schedule =>
                    Number(
                        schedule.workerId
                    ) ===
                        Number(
                            scheduleData.workerId
                        ) &&
                    schedule.date ===
                        scheduleData.date
            );


        const normalizedSchedule = {

            workerId:
                Number(
                    scheduleData.workerId
                ),

            date:
                scheduleData.date,

            journey:
                scheduleData.journey,

            frequentScheduleId:
                scheduleData.frequentScheduleId
                    ? Number(
                        scheduleData.frequentScheduleId
                    )
                    : null,

            entry:
                scheduleData.entry || null,

            exit:
                scheduleData.exit || null,

            entry1:
                scheduleData.entry1 || null,

            exit1:
                scheduleData.exit1 || null,

            entry2:
                scheduleData.entry2 || null,

            exit2:
                scheduleData.exit2 || null,

            tolerance:
                Number(
                    scheduleData.tolerance
                ) || 0,

            replacementWorkerId:
                scheduleData.replacementWorkerId ? Number(scheduleData.replacementWorkerId) : null,

            replacementForWorkerId:
                scheduleData.replacementForWorkerId ? Number(scheduleData.replacementForWorkerId) : null,

            replacementReason:
                scheduleData.replacementReason || null,

            isReplacement:
                Boolean(scheduleData.isReplacement)
        };


        if (existingIndex >= 0) {

            schedules[existingIndex] = {

                ...schedules[existingIndex],

                ...normalizedSchedule,

                id:
                    schedules[
                        existingIndex
                    ].id
            };

        } else {

            schedules.push({

                id:
                    this.generateDailyScheduleId(
                        schedules
                    ),

                ...normalizedSchedule

            });
        }


        return this.saveDailySchedules(
            schedules
        );
    },


    /* =====================================================
       ELIMINAR PROGRAMACIÓN
    ===================================================== */

    removeWorkerSchedule(
        workerId,
        date
    ) {

        const schedules =
            this.getDailySchedules();


        const filtered =
            schedules.filter(
                schedule =>
                    !(
                        Number(
                            schedule.workerId
                        ) ===
                            Number(workerId) &&
                        schedule.date ===
                            date
                    )
            );


        return this.saveDailySchedules(
            filtered
        );
    },


    /* =====================================================
       DÍA LIBRE
    ===================================================== */

    setWorkerFreeDay(
        workerId,
        date
    ) {

        return this.saveWorkerSchedule({

            workerId:
                Number(workerId),

            date:
                date,

            journey:
                "Libre",

            frequentScheduleId:
                null,

            entry:
                null,

            exit:
                null,

            entry1:
                null,

            exit1:
                null,

            entry2:
                null,

            exit2:
                null,

            tolerance:
                0
        });
    },


    /* =====================================================
       ASIGNAR MISMO HORARIO A VARIOS TRABAJADORES
    ===================================================== */

    assignScheduleToWorkers(
        workerIds,
        date,
        scheduleData
    ) {

        if (
            !Array.isArray(workerIds) ||
            workerIds.length === 0
        ) {

            return false;
        }


        workerIds.forEach(
            workerId => {

                this.saveWorkerSchedule({

                    ...scheduleData,

                    workerId:
                        Number(workerId),

                    date:
                        date
                });

            }
        );


        return true;
    },


    /* =====================================================
       COPIAR PROGRAMACIÓN DE UN DÍA
    ===================================================== */

    copyDailySchedule(
        sourceDate,
        targetDate
    ) {

        if (
            !sourceDate ||
            !targetDate ||
            sourceDate === targetDate
        ) {

            return false;
        }


        const sourceSchedules =
            this.getSchedulesByDate(
                sourceDate
            );


        if (
            sourceSchedules.length === 0
        ) {

            return false;
        }


        let schedules =
            this.getDailySchedules();


        /*
         * Eliminamos primero la programación
         * del día de destino.
         */

        schedules =
            schedules.filter(
                schedule =>
                    schedule.date !==
                    targetDate
            );


        sourceSchedules.forEach(
            sourceSchedule => {

                const copiedSchedule = {

                    ...sourceSchedule,

                    id:
                        this.generateDailyScheduleId(
                            schedules
                        ),

                    date:
                        targetDate
                };


                schedules.push(
                    copiedSchedule
                );

            }
        );


        return this.saveDailySchedules(
            schedules
        );
    },


    /* =====================================================
       REEMPLAZOS DE TURNO
    ===================================================== */

    assignShiftReplacement(originalWorkerId, replacementWorkerId, date, reason = "", replacementSchedule = null) {
        const original = this.getWorkerScheduleByDate(originalWorkerId, date);
        if (!original || original.journey === "Libre") return false;
        if (this.getWorkerScheduleByDate(replacementWorkerId, date)) return false;

        this.saveWorkerSchedule({
            ...original,
            ...(replacementSchedule || {}),
            workerId: Number(replacementWorkerId),
            date,
            replacementForWorkerId: Number(originalWorkerId),
            replacementReason: String(reason || "").trim(),
            isReplacement: true,
            replacementWorkerId: null
        });

        return this.saveWorkerSchedule({
            ...original,
            workerId: Number(originalWorkerId),
            date,
            replacementWorkerId: Number(replacementWorkerId),
            replacementReason: String(reason || "").trim(),
            replacementForWorkerId: null,
            isReplacement: false
        });
    },

    swapWorkerSchedules(workerAId, workerBId, date) {
        const a = this.getWorkerScheduleByDate(workerAId, date);
        const b = this.getWorkerScheduleByDate(workerBId, date);
        if (!a || !b || a.journey === "Libre" || b.journey === "Libre") return false;
        if (a.replacementWorkerId || a.isReplacement || b.replacementWorkerId || b.isReplacement) return false;

        const fields = ["journey","frequentScheduleId","entry","exit","entry1","exit1","entry2","exit2","tolerance"];
        const aData = {}; const bData = {};
        fields.forEach(k => { aData[k] = a[k] ?? null; bData[k] = b[k] ?? null; });

        const okA = this.saveWorkerSchedule({ ...a, ...bData, workerId:Number(workerAId), date });
        const okB = this.saveWorkerSchedule({ ...b, ...aData, workerId:Number(workerBId), date });
        return Boolean(okA && okB);
    },

    cancelShiftReplacement(originalWorkerId, date) {
        const original = this.getWorkerScheduleByDate(originalWorkerId, date);
        if (!original || !original.replacementWorkerId) return false;
        const replacementId = Number(original.replacementWorkerId);
        const schedules = this.getDailySchedules().filter(item => !(
            item.date === date && Number(item.workerId) === replacementId &&
            Number(item.replacementForWorkerId) === Number(originalWorkerId)
        ));
        const index = schedules.findIndex(item => item.date === date && Number(item.workerId) === Number(originalWorkerId));
        if (index >= 0) {
            schedules[index] = { ...schedules[index], replacementWorkerId: null, replacementReason: null };
        }
        return this.saveDailySchedules(schedules);
    },

    /* =====================================================
       ESTADÍSTICAS DE PROGRAMACIÓN
    ===================================================== */

    countScheduledWorkers(date) {

        return this
            .getSchedulesByDate(date)
            .filter(
                schedule =>
                    schedule.journey !==
                    "Libre"
            )
            .length;
    },


    countFreeDayWorkers(date) {

        return this
            .getSchedulesByDate(date)
            .filter(
                schedule =>
                    schedule.journey ===
                    "Libre"
            )
            .length;
    },


    countUnassignedWorkers(date) {

        const activeWorkers =
            this.getActiveWorkers();


        return activeWorkers
            .filter(
                worker =>
                    !this
                        .getWorkerScheduleByDate(
                            worker.id,
                            date
                        )
            )
            .length;
    },


    /* =====================================================
       UTILIDADES PARA HORARIOS
    ===================================================== */

    formatScheduleHours(schedule) {

        if (!schedule) {
            return "—";
        }


        if (
            schedule.journey ===
            "Libre"
        ) {

            return "Día libre";
        }


        if (
            schedule.journey ===
            "Completo"
        ) {

            const firstBlock =
                schedule.entry1 &&
                schedule.exit1
                    ? `${schedule.entry1} - ${schedule.exit1}`
                    : "";

            const secondBlock =
                schedule.entry2 &&
                schedule.exit2
                    ? `${schedule.entry2} - ${schedule.exit2}`
                    : "";


            if (
                firstBlock &&
                secondBlock
            ) {

                return (
                    `${firstBlock} / ${secondBlock}`
                );
            }


            return (
                firstBlock ||
                secondBlock ||
                "—"
            );
        }


        if (
            schedule.entry &&
            schedule.exit
        ) {

            return (
                `${schedule.entry} - ${schedule.exit}`
            );
        }


        return "—";
    },


    /* =====================================================
       HORAS ESPERADAS PARA BIOMÉTRICO
    ===================================================== */

    getExpectedMarks(
        workerId,
        date
    ) {

        const schedule =
            this.getWorkerScheduleByDate(
                workerId,
                date
            );


        if (
            !schedule ||
            schedule.journey ===
            "Libre"
        ) {

            return [];
        }


        /*
         * Mañana o Tarde:
         *
         * Entrada
         * Salida
         */

        if (
            schedule.journey ===
                "Mañana" ||
            schedule.journey ===
                "Tarde"
        ) {

            return [

                {
                    type:
                        "Entrada",

                    time:
                        schedule.entry
                },

                {
                    type:
                        "Salida",

                    time:
                        schedule.exit
                }

            ].filter(
                mark =>
                    Boolean(mark.time)
            );
        }


        /*
         * Jornada completa:
         *
         * Entrada 1
         * Salida 1
         * Entrada 2
         * Salida 2
         */

        if (
            schedule.journey ===
            "Completo"
        ) {

            return [

                {
                    type:
                        "Entrada 1",

                    time:
                        schedule.entry1
                },

                {
                    type:
                        "Salida 1",

                    time:
                        schedule.exit1
                },

                {
                    type:
                        "Entrada 2",

                    time:
                        schedule.entry2
                },

                {
                    type:
                        "Salida 2",

                    time:
                        schedule.exit2
                }

            ].filter(
                mark =>
                    Boolean(mark.time)
            );
        }


     return [];
    },


    /* =====================================================
       MARCACIONES BIOMÉTRICAS
    ===================================================== */

    initializeBiometricMarks() {

        const marks =
            this.get(
                this.keys.biometricMarks
            );

        if (Array.isArray(marks)) {
            return;
        }

        this.saveBiometricMarks([]);
    },


    getBiometricMarks() {

        const marks =
            this.get(
                this.keys.biometricMarks
            );

        return Array.isArray(marks)
            ? marks
            : [];
    },


    saveBiometricMarks(marks) {

        return this.set(
            this.keys.biometricMarks,
            marks
        );
    },


    getBiometricMarksByDate(date) {

        return this
            .getBiometricMarks()
            .filter(
                mark =>
                    mark.date === date
            );
    },


    getWorkerBiometricMarks(
        workerId,
        date
    ) {

        return this
            .getBiometricMarks()
            .filter(
                mark =>
                    Number(mark.workerId) ===
                        Number(workerId) &&
                    mark.date === date
            )
            .sort(
                (a, b) =>
                    String(a.time)
                        .localeCompare(
                            String(b.time)
                        )
            );
    },


addBiometricMark(markData) {

    if (
        !markData ||
        !markData.workerId ||
        !markData.date ||
        !markData.time
    ) {
        console.error(
            "SIGEP - Marcación biométrica inválida",
            markData
        );

        return null;
    }

    const marks =
        this.getBiometricMarks();

    const newMark = {

        id:
            this.generateId(marks),

        workerId:
            Number(markData.workerId),

        date:
            markData.date,

        time:
            markData.time,

        type:
            markData.type || null,

        source:
            markData.source || "Biométrico"
    };

    marks.push(newMark);

    this.saveBiometricMarks(marks);

    return newMark;
},


/* =====================================================
   REGULARIZACIONES DE ASISTENCIA
====================================================== */

getAttendanceRegularizations() {

    const regularizations =
        this.get(
            this.keys.attendanceRegularizations
        );

    return Array.isArray(regularizations)
        ? regularizations
        : [];
},


saveAttendanceRegularizations(regularizations) {

    return this.set(
        this.keys.attendanceRegularizations,
        regularizations
    );
},


getAttendanceRegularization(workerId, date) {

    return this
        .getAttendanceRegularizations()
        .find(
            item =>
                Number(item.workerId) ===
                    Number(workerId) &&
                item.date === date
        ) || null;
},


saveAttendanceRegularization(data) {

    if (
        !data ||
        !data.workerId ||
        !data.date ||
        !data.status ||
        !data.reason
    ) {
        console.error(
            "SIGEP - Regularización inválida",
            data
        );

        return null;
    }

    const regularizations =
        this.getAttendanceRegularizations();

    const existingIndex =
        regularizations.findIndex(
            item =>
                Number(item.workerId) ===
                    Number(data.workerId) &&
                item.date === data.date
        );

    const normalizedRegularization = {

        workerId:
            Number(data.workerId),

        date:
            data.date,

        originalStatus:
            data.originalStatus || null,

        status:
            data.status,

        reason:
            String(data.reason).trim(),

        updatedAt:
            new Date().toISOString()
    };


    /* SI YA EXISTE, ACTUALIZAR */

    if (existingIndex >= 0) {

        regularizations[existingIndex] = {

            ...regularizations[existingIndex],

            ...normalizedRegularization,

            id:
                regularizations[existingIndex].id
        };

        this.saveAttendanceRegularizations(
            regularizations
        );

        return regularizations[
            existingIndex
        ];
    }


    /* SI NO EXISTE, CREAR */

    const newRegularization = {

        id:
            this.generateId(
                regularizations
            ),

        ...normalizedRegularization
    };

    regularizations.push(
        newRegularization
    );

    this.saveAttendanceRegularizations(
        regularizations
    );

    return newRegularization;
}
,

    /* =====================================================
       PERIODOS DE PAGO
    ===================================================== */
    getPaymentPeriods() {
        const data = this.get(this.keys.paymentPeriods);
        return Array.isArray(data) ? data : [];
    },

    savePaymentPeriods(periods) {
        return this.set(this.keys.paymentPeriods, Array.isArray(periods) ? periods : []);
    },

    getPaymentPeriod(workerId, from, to) {
        return this.getPaymentPeriods().find(item =>
            Number(item.workerId) === Number(workerId) &&
            item.from === from && item.to === to
        ) || null;
    },

    markPaymentPeriodProcessed(workerId, from, to, processedBy = "Administrador") {
        const periods = this.getPaymentPeriods();
        const index = periods.findIndex(item =>
            Number(item.workerId) === Number(workerId) && item.from === from && item.to === to
        );
        const value = {
            workerId: Number(workerId), from, to,
            status: "Procesado",
            processedAt: new Date().toISOString(),
            processedBy: String(processedBy || "Administrador")
        };
        if (index >= 0) periods[index] = { ...periods[index], ...value };
        else periods.push({ id: this.generateId(periods), ...value });
        this.savePaymentPeriods(periods);
        return value;
    },

    reopenPaymentPeriod(workerId, from, to) {
        const periods = this.getPaymentPeriods();
        const index = periods.findIndex(item =>
            Number(item.workerId) === Number(workerId) && item.from === from && item.to === to
        );
        if (index < 0) return false;
        periods.splice(index, 1);
        this.savePaymentPeriods(periods);
        return true;
    }

};
/* =========================================================
   INICIALIZACIÓN DEL STORAGE
========================================================= */

/*
 * IMPORTANTE:
 *
 * Primero inicializamos cargos porque los trabajadores
 * utilizan positionId.
 */

/* =========================================================
   MIGRACIÓN DE DATOS DEMO V3
   Unifica instalaciones nuevas/antiguas del prototipo sin
   sobrescribir datos que el usuario ya haya personalizado.
========================================================= */
(function migrateDemoDataV3() {
    const MIGRATION_KEY = "sigep_demo_data_v3";
    if (localStorage.getItem(MIGRATION_KEY)) return;

    try {
        const workers = SIGEP_STORAGE.get(SIGEP_STORAGE.keys.workers);
        const oldDemoNames = [
            "Carlos Mendoza",
            "María Torres",
            "Luis Ramírez",
            "Andrea Flores",
            "José Castro"
        ];
        const isOldDemo = Array.isArray(workers) &&
            workers.length === oldDemoNames.length &&
            oldDemoNames.every(name => workers.some(w =>
                String(w.fullName || `${w.firstName || ""} ${w.lastName || ""}`).trim() === name
            ));

        if (isOldDemo) {
            localStorage.removeItem(SIGEP_STORAGE.keys.workers);
        }

        const settingsKey = "sigep_system_settings";
        let settings = {};
        try { settings = JSON.parse(localStorage.getItem(settingsKey) || "{}"); } catch (_) {}
        if (!settings.adminName || settings.adminName === "Administrador") {
            settings.adminName = "Henry";
            if (!settings.systemName) settings.systemName = "SIGEP";
            localStorage.setItem(settingsKey, JSON.stringify(settings));
        }
    } finally {
        localStorage.setItem(MIGRATION_KEY, "1");
    }
})();

SIGEP_STORAGE.initializePositions();


/*
 * Después inicializamos trabajadores.
 */

SIGEP_STORAGE.initializeWorkers();


/*
 * Convertimos trabajadores antiguos que todavía
 * utilizaban el nombre del cargo.
 */

SIGEP_STORAGE.migrateWorkersToPositionId();


/*
 * Inicializamos los horarios frecuentes.
 */

SIGEP_STORAGE.initializeFrequentSchedules();


/*
 * Inicializamos la programación diaria.
 */

SIGEP_STORAGE.initializeDailySchedules();
SIGEP_STORAGE.initializeBiometricMarks();
/* =====================================================
   INICIALIZAR REGULARIZACIONES DE ASISTENCIA
====================================================== */

if (
    !Array.isArray(
        SIGEP_STORAGE.get(
            SIGEP_STORAGE.keys.attendanceRegularizations
        )
    )
) {
    SIGEP_STORAGE.saveAttendanceRegularizations([]);
}

/* =========================================================
   DISPONIBILIDAD GLOBAL
========================================================= */

window.SIGEP_STORAGE =
    SIGEP_STORAGE;