document.addEventListener("DOMContentLoaded", () => {
    const STORAGE = window.SIGEP_STORAGE;
    const dashboardDate = document.getElementById("dashboardDate");
    const logoutButton = document.getElementById("logoutButton");
    const mobileMenu = document.getElementById("mobileMenu");
    const sidebar = document.getElementById("sidebar");
    const registerWorkerButton = document.getElementById("registerWorkerButton");
    const session = localStorage.getItem("sigep_session") || sessionStorage.getItem("sigep_session");
    const redirectLogin = () => { window.location.href = "../index.html"; };
    if (!session) return redirectLogin();
    try { if (!JSON.parse(session).authenticated) return redirectLogin(); }
    catch (_) { localStorage.removeItem("sigep_session"); sessionStorage.removeItem("sigep_session"); return redirectLogin(); }

    const getTodayISO = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; };
    const timeToMinutes = time => { if(!time||!String(time).includes(":")) return null; const [h,m]=String(time).split(":").map(Number); return h*60+m; };
    const formatTime = time => { if(!time) return "—"; const [h,m]=String(time).split(":").map(Number); if(Number.isNaN(h)||Number.isNaN(m)) return time; return new Intl.DateTimeFormat("es-PE",{hour:"numeric",minute:"2-digit",hour12:true}).format(new Date(2000,0,1,h,m)); };
    const initials = name => String(name||"T").split(" ").filter(Boolean).slice(0,2).map(x=>x[0].toUpperCase()).join("");
    const getScheduleEntry = s => s?.journey === "Completo" ? (s.entry1||null) : (s?.entry||null);
    const getScheduleExit = s => s?.journey === "Completo" ? (s.exit2||s.exit1||null) : (s?.exit||null);
    const scheduleLabel = s => { const e=getScheduleEntry(s), x=getScheduleExit(s); return e&&x ? `${formatTime(e)} - ${formatTime(x)}` : "—"; };

    const now=new Date(), today=getTodayISO();
    const formattedDate=new Intl.DateTimeFormat("es-PE",{weekday:"long",day:"numeric",month:"long",year:"numeric"}).format(now);
    if(dashboardDate) dashboardDate.textContent=formattedDate.charAt(0).toUpperCase()+formattedDate.slice(1);
    const hour=now.getHours();
    const greeting=hour>=19||hour<5?"Buenas noches":hour>=12?"Buenas tardes":"Buenos días";
    const welcomeTitle=document.querySelector(".welcome h3");
    const uiSettings=(()=>{try{return JSON.parse(localStorage.getItem("sigep_system_settings")||"{}")}catch{return {}}})();
    const adminDisplayName=String(uiSettings.adminName||"Henry").trim()||"Henry";
    if(welcomeTitle) welcomeTitle.textContent=`${greeting}, ${adminDisplayName}`;

    function calculateStatus(schedule){
        const workerId=Number(schedule.workerId);
        const marks=STORAGE.getWorkerBiometricMarks(workerId,today);
        const entry=marks.find(m=>m.type==="Entrada")?.time||null;
        const scheduledEntry=getScheduleEntry(schedule), scheduledExit=getScheduleExit(schedule);
        let status="Pendiente";
        if(entry&&scheduledEntry){ status=timeToMinutes(entry)<=timeToMinutes(scheduledEntry)+(Number(schedule.tolerance)||0)?"Presente":"Tardanza"; }
        else if(!entry&&scheduledExit){ const exit=timeToMinutes(scheduledExit), current=now.getHours()*60+now.getMinutes(); if(exit!==null&&current>exit) status="Falta"; }
        const reg=typeof STORAGE.getAttendanceRegularization==="function"?STORAGE.getAttendanceRegularization(workerId,today):null;
        if(reg?.status) status=reg.status;
        return {status,entry,marks,regularization:reg};
    }

    function renderDashboard(){
        if(!STORAGE){ console.error("SIGEP_STORAGE no está disponible."); return; }
        const workers=STORAGE.getWorkers(), active=STORAGE.getActiveWorkers();
        const schedules=STORAGE.getSchedulesByDate(today).filter(s=>s.journey!=="Libre" && !s.replacementWorkerId);
        const records=schedules.map(schedule=>{ const worker=STORAGE.getWorkerById(schedule.workerId); return worker?{schedule,worker,...calculateStatus(schedule)}:null; }).filter(Boolean);
        const present=records.filter(r=>r.status==="Presente").length;
        const late=records.filter(r=>r.status==="Tardanza").length;
        const absent=records.filter(r=>r.status==="Falta"||r.status==="Falta justificada").length;
        const pending=records.filter(r=>r.status==="Pendiente").length;
        const percentage=schedules.length?Math.round(((present+late)/schedules.length)*100):0;
        document.getElementById("totalWorkers").textContent=workers.length;
        document.getElementById("activeWorkersText").textContent=`${active.length} activos`;
        document.getElementById("presentWorkers").textContent=present;
        document.getElementById("presentPercentage").textContent=`${percentage}% del personal programado`;
        document.getElementById("lateWorkers").textContent=late;
        document.getElementById("absentWorkers").textContent=absent;

        const body=document.getElementById("dashboardAttendanceBody");
        const recent=[...records].sort((a,b)=>String(b.entry||"").localeCompare(String(a.entry||""))).slice(0,5);
        body.innerHTML=recent.length?recent.map(r=>{ const name=STORAGE.getWorkerFullName(r.worker), position=STORAGE.getWorkerPositionName(r.worker); const cls=r.status==="Presente"?"success":r.status==="Tardanza"?"warning":(r.status==="Falta"||r.status==="Falta justificada")?"danger":"pending"; return `<tr><td><div class="employee"><div class="employee-avatar">${initials(name)}</div><div><strong>${name}</strong><span>${position||"Sin cargo"}</span></div></div></td><td>${scheduleLabel(r.schedule)}</td><td>${formatTime(r.entry)}</td><td><span class="status ${cls}">${r.status}</span></td></tr>`; }).join(""):`<tr><td colspan="4"><div class="dashboard-empty"><i class="fa-regular fa-calendar-check"></i><span>No hay trabajadores programados para hoy.</span></div></td></tr>`;

        const marks=STORAGE.getBiometricMarksByDate(today), regs=STORAGE.getAttendanceRegularizations().filter(r=>r.date===today);
        document.getElementById("scheduledToday").textContent=`${schedules.length} programados`;
        document.getElementById("pendingToday").textContent=`${pending} pendientes de marcación`;
        document.getElementById("marksToday").textContent=marks.length;
        document.getElementById("regularizationsToday").textContent=regs.length;
        document.getElementById("coverageToday").textContent=`${percentage}%`;

        const latest=[...marks].sort((a,b)=>String(b.time).localeCompare(String(a.time))).slice(0,4);
        document.getElementById("latestMarksList").innerHTML=latest.length?latest.map(mark=>{ const worker=STORAGE.getWorkerById(mark.workerId), name=STORAGE.getWorkerFullName(worker), isExit=mark.type==="Salida"; return `<div class="marking"><div class="marking-icon ${isExit?"exit":"entry"}"><i class="fa-solid ${isExit?"fa-arrow-right-from-bracket":"fa-arrow-right-to-bracket"}"></i></div><div class="marking-person"><strong>${name}</strong><span>${isExit?"Salida":"Entrada"} registrada</span></div><time>${formatTime(mark.time)}</time></div>`; }).join(""):`<div class="dashboard-empty compact"><i class="fa-solid fa-fingerprint"></i><span>Aún no hay marcaciones registradas hoy.</span></div>`;

        const alerts=[];
        if(late) alerts.push({cls:"warning-alert",icon:"fa-regular fa-clock",title:`${late} ${late===1?"tardanza registrada":"tardanzas registradas"}`,text:"Revisa los ingresos fuera del horario establecido."});
        if(absent) alerts.push({cls:"danger-alert",icon:"fa-solid fa-user-xmark",title:`${absent} ${absent===1?"trabajador ausente":"trabajadores ausentes"}`,text:"No registraron entrada dentro de su jornada."});
        if(pending) alerts.push({cls:"info-alert",icon:"fa-regular fa-hourglass-half",title:`${pending} ${pending===1?"marcación pendiente":"marcaciones pendientes"}`,text:"La jornada aún está en curso o falta registrar la entrada."});
        document.getElementById("alertCount").textContent=alerts.length;
        document.getElementById("alertsList").innerHTML=alerts.length?alerts.map(a=>`<button type="button" class="alert-item ${a.cls}" data-go-attendance><div class="alert-icon"><i class="${a.icon}"></i></div><div><strong>${a.title}</strong><p>${a.text}</p></div><i class="fa-solid fa-chevron-right alert-chevron"></i></button>`).join(""):`<div class="dashboard-empty compact success-empty"><i class="fa-solid fa-circle-check"></i><span>Sin alertas de asistencia por el momento.</span></div>`;
    }
    renderDashboard();
    registerWorkerButton?.addEventListener("click",()=>{window.location.href="trabajadores.html?nuevo=1";});
    document.getElementById("alertsList")?.addEventListener("click",e=>{if(e.target.closest("[data-go-attendance]"))window.location.href="asistencia.html";});
    mobileMenu?.addEventListener("click",e=>{e.stopPropagation();sidebar?.classList.toggle("open");});
    document.addEventListener("click",e=>{if(window.innerWidth<=800&&sidebar?.classList.contains("open")&&!sidebar.contains(e.target)&&!mobileMenu?.contains(e.target))sidebar.classList.remove("open");});
    logoutButton?.addEventListener("click",()=>{if(!confirm("¿Estás seguro de que deseas cerrar sesión?"))return;localStorage.removeItem("sigep_session");sessionStorage.removeItem("sigep_session");redirectLogin();});
});
