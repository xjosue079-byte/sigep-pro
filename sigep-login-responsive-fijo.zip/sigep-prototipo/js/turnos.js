/* =========================================================
   SIGEP - TURNOS Y HORARIOS
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    if (!window.SIGEP_STORAGE) {
        console.error("SIGEP_STORAGE no está disponible.");
        return;
    }

    const STORAGE = window.SIGEP_STORAGE;

    /* =====================================================
       ESTADO
    ===================================================== */

    let selectedDate = getTodayISO();
    let selectedWorkerId = null;
    let selectedWorkerIds = [];
    let multipleSelectionMode = false;
    let editingFrequentScheduleId = null;

    let activeScheduleMenuWorkerId = null;
    let activeFrequentMenuId = null;


    /* =====================================================
       ELEMENTOS - GENERAL
    ===================================================== */

    const dashboardDate =
        document.getElementById("dashboardDate");

    const mobileMenu =
        document.getElementById("mobileMenu");

    const sidebar =
        document.getElementById("sidebar");

    const logoutButton =
        document.getElementById("logoutButton");


    /* =====================================================
       PESTAÑAS
    ===================================================== */

    const scheduleTabs =
        document.querySelectorAll(".schedule-tab");

    const dailyScheduleTab =
        document.getElementById("dailyScheduleTab");

    const frequentSchedulesTab =
        document.getElementById("frequentSchedulesTab");


    /* =====================================================
       FECHA
    ===================================================== */

    const previousDay =
        document.getElementById("previousDay");

    const nextDay =
        document.getElementById("nextDay");

    const todayButton =
        document.getElementById("todayButton");

    const scheduleDate =
        document.getElementById("scheduleDate");

    const selectedDateText =
        document.getElementById("selectedDateText");


    /* =====================================================
       ESTADÍSTICAS
    ===================================================== */

    const totalScheduleWorkers =
        document.getElementById("totalScheduleWorkers");

    const scheduledWorkers =
        document.getElementById("scheduledWorkers");

    const freeDayWorkers =
        document.getElementById("freeDayWorkers");

    const unassignedWorkers =
        document.getElementById("unassignedWorkers");


    /* =====================================================
       TABLA PROGRAMACIÓN
    ===================================================== */

    const scheduleSearch =
        document.getElementById("scheduleSearch");

    const schedulePositionFilter =
        document.getElementById("schedulePositionFilter");

    const scheduleStatusFilter =
        document.getElementById("scheduleStatusFilter");

    const scheduleTableBody =
        document.getElementById("scheduleTableBody");

    const scheduleResultText =
        document.getElementById("scheduleResultText");

    const selectedWorkersText =
        document.getElementById("selectedWorkersText");

    const selectAllWorkers =
        document.getElementById("selectAllWorkers");


    /* =====================================================
       HORARIOS RÁPIDOS
       Evita que el administrador tenga que escribir horas manualmente.
    ===================================================== */
    function getQuickOptions(journey) {
        if (journey === "Mañana") {
            return [
                ["09:00|14:00", "9:00 a. m. - 2:00 p. m."],
                ["10:00|15:00", "10:00 a. m. - 3:00 p. m."]
            ];
        }
        if (journey === "Tarde") {
            return [
                ["15:00|20:00", "3:00 p. m. - 8:00 p. m."],
                ["16:00|21:00", "4:00 p. m. - 9:00 p. m."]
            ];
        }
        if (journey === "Completo") {
            return [
                ["10:00|14:00|15:00|21:00", "10:00 a. m. - 2:00 p. m. / 3:00 p. m. - 9:00 p. m."],
                ["09:00|14:00|15:00|20:00", "9:00 a. m. - 2:00 p. m. / 3:00 p. m. - 8:00 p. m."]
            ];
        }
        return [];
    }

    function ensureQuickSelector(id, journeySelect, fields, onApply) {
        let group = document.getElementById(id + "Group");
        let select = document.getElementById(id);
        if (!group) {
            group = document.createElement("div");
            group.id = id + "Group";
            group.className = "schedule-form-group quick-schedule-group";
            group.innerHTML = `<label>Horario rápido <span>*</span></label><select id="${id}"></select><small>Elige un horario listo. Usa “Personalizado” solo si necesitas otro.</small>`;
            fields.parentNode.insertBefore(group, fields);
            select = group.querySelector("select");
        }
        const journey = journeySelect.value;
        const options = getQuickOptions(journey);
        group.style.display = options.length ? "" : "none";
        if (!options.length) return null;
        const previous = select.value;
        select.innerHTML = options.map(([value,label]) => `<option value="${value}">${label}</option>`).join("") + `<option value="custom">Otro horario...</option>`;
        if (options.some(([v]) => v === previous)) select.value = previous;
        fields.style.display = select.value === "custom" ? "" : "none";
        const apply = () => {
            fields.style.display = select.value === "custom" ? "" : "none";
            if (select.value !== "custom") onApply(select.value);
        };
        select.onchange = apply;
        apply();
        return select;
    }

    function setSingleQuickTime(value) {
        const parts = value.split("|");
        if (parts.length === 4) {
            scheduleEntry1.value = parts[0];
            scheduleExit1.value = parts[1];
            scheduleEntry2.value = parts[2];
            scheduleExit2.value = parts[3];
            refreshSplit12h();
            return;
        }
        const [entry, exit] = parts;
        const e = convertFrom24Hour(entry);
        const x = convertFrom24Hour(exit);
        scheduleEntryHour.value = e.hour;
        scheduleEntryPeriod.value = e.period;
        scheduleExitHour.value = x.hour;
        scheduleExitPeriod.value = x.period;
    }

    function refreshSingleQuickSelector() {
        if (!continuousScheduleFields) return;
        const targetFields = scheduleJourney.value === "Completo" ? splitScheduleFields : continuousScheduleFields;
        ensureQuickSelector("singleQuickSchedule", scheduleJourney, targetFields, setSingleQuickTime);
    }

    function refreshMultipleQuickSelector() {
        if (!multipleContinuousFields) return;
        const targetFields = multipleJourney.value === "Completo" ? multipleSplitFields : multipleContinuousFields;
        ensureQuickSelector("multipleQuickSchedule", multipleJourney, targetFields, value => {
            const parts = value.split("|");
            if (parts.length === 4) {
                multipleEntry1.value = parts[0];
                multipleExit1.value = parts[1];
                multipleEntry2.value = parts[2];
                multipleExit2.value = parts[3];
                return;
            }
            multipleEntry.value = parts[0];
            multipleExit.value = parts[1];
        });
    }

    function enhanceSplitTime12h(input){
        if(!input || input.dataset.enhanced12h) return;
        input.dataset.enhanced12h="1"; input.style.display="none";
        const wrap=document.createElement("div"); wrap.className="schedule-time-12h split-time-12h";
        const hour=document.createElement("select"); hour.innerHTML='<option value="">Hora</option>'+Array.from({length:12},(_,i)=>`<option value="${i+1}">${i+1}:00</option>`).join('');
        const period=document.createElement("select"); period.innerHTML='<option value="AM">a. m.</option><option value="PM">p. m.</option>';
        wrap.append(hour,period); input.after(wrap);
        const syncHidden=()=>{ if(!hour.value){input.value="";return;} input.value=convertTo24Hour(hour.value,period.value)||""; };
        const syncVisible=()=>{ if(!input.value){hour.value="";return;} const v=convertFrom24Hour(input.value); hour.value=v.hour; period.value=v.period; };
        hour.onchange=syncHidden; period.onchange=syncHidden; input._sync12h=syncVisible; syncVisible();
    }
    function refreshSplit12h(){[scheduleEntry1,scheduleExit1,scheduleEntry2,scheduleExit2,multipleEntry1,multipleExit1,multipleEntry2,multipleExit2].forEach(enhanceSplitTime12h); [scheduleEntry1,scheduleExit1,scheduleEntry2,scheduleExit2,multipleEntry1,multipleExit1,multipleEntry2,multipleExit2].forEach(i=>i?._sync12h?.());}

    /* =====================================================
       MODAL INDIVIDUAL
    ===================================================== */

    const scheduleModal =
        document.getElementById("scheduleModal");

    const scheduleForm =
        document.getElementById("scheduleForm");

    const closeScheduleModal =
        document.getElementById("closeScheduleModal");

    const cancelScheduleModal =
        document.getElementById("cancelScheduleModal");

    const selectedWorkerAvatar =
        document.getElementById("selectedWorkerAvatar");

    const selectedWorkerName =
        document.getElementById("selectedWorkerName");

    const selectedWorkerPosition =
        document.getElementById("selectedWorkerPosition");

    const modalScheduleDate =
        document.getElementById("modalScheduleDate");

    const scheduleJourney =
        document.getElementById("scheduleJourney");

    const frequentScheduleGroup =
        document.getElementById("frequentScheduleGroup");

    const frequentScheduleSelect =
        document.getElementById("frequentScheduleSelect");

    const continuousScheduleFields =
        document.getElementById("continuousScheduleFields");

    const splitScheduleFields =
        document.getElementById("splitScheduleFields");

    const scheduleEntryHour =
    document.getElementById("scheduleEntryHour");

const scheduleEntryPeriod =
    document.getElementById("scheduleEntryPeriod");

const scheduleExitHour =
    document.getElementById("scheduleExitHour");

const scheduleExitPeriod =
    document.getElementById("scheduleExitPeriod");

    const scheduleEntry1 =
        document.getElementById("scheduleEntry1");

    const scheduleExit1 =
        document.getElementById("scheduleExit1");

    const scheduleEntry2 =
        document.getElementById("scheduleEntry2");

    const scheduleExit2 =
        document.getElementById("scheduleExit2");

    const toleranceGroup =
        document.getElementById("toleranceGroup");

    const scheduleTolerance =
        document.getElementById("scheduleTolerance");


    /* =====================================================
       ASIGNACIÓN MÚLTIPLE
    ===================================================== */

    const openMultipleAssignModal =
        document.getElementById("openMultipleAssignModal");

    const multipleAssignModal =
        document.getElementById("multipleAssignModal");

    const closeMultipleAssignModal =
        document.getElementById("closeMultipleAssignModal");

    const cancelMultipleAssignModal =
        document.getElementById("cancelMultipleAssignModal");

    const multipleAssignForm =
        document.getElementById("multipleAssignForm");

    const multipleSelectedCount =
        document.getElementById("multipleSelectedCount");

    const multipleJourney =
        document.getElementById("multipleJourney");

    const multipleFrequentGroup =
        document.getElementById("multipleFrequentGroup");

    const multipleFrequentSchedule =
        document.getElementById("multipleFrequentSchedule");

    const multipleContinuousFields =
        document.getElementById("multipleContinuousFields");

    const multipleSplitFields =
        document.getElementById("multipleSplitFields");

    const multipleEntry =
        document.getElementById("multipleEntry");

    const multipleExit =
        document.getElementById("multipleExit");

    const multipleEntry1 =
        document.getElementById("multipleEntry1");

    const multipleExit1 =
        document.getElementById("multipleExit1");

    const multipleEntry2 =
        document.getElementById("multipleEntry2");

    const multipleExit2 =
        document.getElementById("multipleExit2");

    const multipleTolerance =
        document.getElementById("multipleTolerance");


    /* =====================================================
       COPIAR DÍA
    ===================================================== */

    const openCopyDayModal =
        document.getElementById("openCopyDayModal");

    const shareScheduleButton = document.getElementById("shareScheduleButton");
    const finalizeScheduleButton = document.getElementById("finalizeScheduleButton");

    const copyDayModal =
        document.getElementById("copyDayModal");

    const closeCopyDayModal =
        document.getElementById("closeCopyDayModal");

    const cancelCopyDayModal =
        document.getElementById("cancelCopyDayModal");

    const copyDayForm =
        document.getElementById("copyDayForm");

    const copySourceDate =
        document.getElementById("copySourceDate");

    const copyTargetDate =
        document.getElementById("copyTargetDate");


    /* =====================================================
       HORARIOS FRECUENTES
    ===================================================== */

    const openFrequentModal =
        document.getElementById("openFrequentModal");

    const frequentModal =
        document.getElementById("frequentModal");

    const closeFrequentModal =
        document.getElementById("closeFrequentModal");

    const cancelFrequentModal =
        document.getElementById("cancelFrequentModal");

    const frequentForm =
        document.getElementById("frequentForm");

    const frequentModalTitle =
        document.getElementById("frequentModalTitle");

    const frequentSubmitText =
        document.getElementById("frequentSubmitText");

    const frequentName =
        document.getElementById("frequentName");

    const frequentJourney =
        document.getElementById("frequentJourney");

    const frequentContinuousFields =
        document.getElementById("frequentContinuousFields");

    const frequentSplitFields =
        document.getElementById("frequentSplitFields");

    const frequentEntry =
        document.getElementById("frequentEntry");

    const frequentExit =
        document.getElementById("frequentExit");

    const frequentEntry1 =
        document.getElementById("frequentEntry1");

    const frequentExit1 =
        document.getElementById("frequentExit1");

    const frequentEntry2 =
        document.getElementById("frequentEntry2");

    const frequentExit2 =
        document.getElementById("frequentExit2");

    const frequentTolerance =
        document.getElementById("frequentTolerance");

    const frequentStatus =
        document.getElementById("frequentStatus");

    const frequentSearch =
        document.getElementById("frequentSearch");

    const frequentTypeFilter =
        document.getElementById("frequentTypeFilter");

    const frequentTableBody =
        document.getElementById("frequentTableBody");

    const frequentResultText =
        document.getElementById("frequentResultText");


    /* =====================================================
   MODAL ACCIONES DEL TRABAJADOR
===================================================== */

const scheduleActionsModal =
    document.getElementById("scheduleActionsModal");

const closeScheduleActionsModal =
    document.getElementById("closeScheduleActionsModal");

const cancelScheduleActionsModal =
    document.getElementById("cancelScheduleActionsModal");

const actionWorkerAvatar =
    document.getElementById("actionWorkerAvatar");

const actionWorkerName =
    document.getElementById("actionWorkerName");

const actionWorkerPosition =
    document.getElementById("actionWorkerPosition");

const actionWorkerDate =
    document.getElementById("actionWorkerDate");

const scheduleReadonlyNotice =
    document.getElementById("scheduleReadonlyNotice");

const workerScheduleActions =
    document.getElementById("workerScheduleActions");

const frequentActionsMenu =
    document.getElementById("frequentActionsMenu");

    /* =====================================================
       UTILIDADES
    ===================================================== */

    function getTodayISO() {

        const date = new Date();

        const year = date.getFullYear();

        const month =
            String(date.getMonth() + 1)
                .padStart(2, "0");

        const day =
            String(date.getDate())
                .padStart(2, "0");

        return `${year}-${month}-${day}`;
    }


    /* =====================================================
       CONTROL DE FECHAS PASADAS
    ===================================================== */

    function isPastDate(dateValue = selectedDate) {

        return dateValue < getTodayISO();
    }


    function blockPastDateAction() {

        if (!isPastDate(selectedDate)) {
            return false;
        }

        showMessage(
            "Este día ya pasó. La programación se encuentra en modo solo lectura."
        );

        return true;
    }


    function updatePastDateMode() {

        const past =
            isPastDate(selectedDate);

        if (past) {
            selectedWorkerIds = [];
        }

        if (openMultipleAssignModal) {

            openMultipleAssignModal.disabled =
                past;

            openMultipleAssignModal.classList.toggle(
                "disabled",
                past
            );

            openMultipleAssignModal.title =
                past
                    ? "No se puede modificar un día pasado"
                    : "Asignar horario a varios trabajadores";
        }

        if (openCopyDayModal) {

            openCopyDayModal.disabled =
                past;

            openCopyDayModal.classList.toggle(
                "disabled",
                past
            );

            openCopyDayModal.title =
                past
                    ? "No se puede copiar una programación hacia un día pasado"
                    : "Copiar programación de otro día";
        }

        if (selectAllWorkers) {

            selectAllWorkers.disabled =
                past;

            if (past) {
                selectAllWorkers.checked = false;
                selectAllWorkers.indeterminate = false;
            }
        }

        document
            .querySelectorAll(
                ".schedule-worker-checkbox"
            )
            .forEach(checkbox => {

                checkbox.disabled =
                    past;

                if (past) {
                    checkbox.checked = false;
                }
            });

        document
            .querySelectorAll(
                ".schedule-action-button"
            )
            .forEach(button => {

                button.disabled =
                    past;

                button.title =
                    past
                        ? "Día pasado · Solo lectura"
                        : "Acciones";
            });

        if (past && scheduleActionsModal) {
            scheduleActionsModal.classList.remove(
                "show"
            );
        }

        updateSelectedWorkersUI();
    }


    function parseISODate(value) {

        if (!value) {
            return new Date();
        }

        const [year, month, day] =
            value.split("-").map(Number);

        return new Date(
            year,
            month - 1,
            day
        );
    }


    function formatLongDate(value) {

        const date =
            parseISODate(value);

        return date.toLocaleDateString(
            "es-PE",
            {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        );
    }


    function capitalize(text) {

        if (!text) {
            return "";
        }

        return (
            text.charAt(0).toUpperCase() +
            text.slice(1)
        );
    }


    function escapeHTML(value) {

        return String(value ?? "")
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }

   function getInitials(worker) {

    const firstName =
        String(worker.names || "")
            .trim()
            .charAt(0);

    const firstLastName =
        String(worker.lastNames || "")
            .trim()
            .charAt(0);

    return (
        `${firstName}${firstLastName}`
    ).toUpperCase() || "TR";
}

function getWorkerName(worker) {

    return STORAGE.getWorkerFullName(worker);
}

    function changeDate(days) {

        const date =
            parseISODate(selectedDate);

        date.setDate(
            date.getDate() + days
        );

        const year =
            date.getFullYear();

        const month =
            String(date.getMonth() + 1)
                .padStart(2, "0");

        const day =
            String(date.getDate())
                .padStart(2, "0");

        selectedDate =
            `${year}-${month}-${day}`;

        refreshDailySchedule();
    }


    function openModal(modal) {

        if (!modal) {
            return;
        }

        modal.classList.add("show");

        document.body.style.overflow =
            "hidden";
    }


    function closeModal(modal) {

        if (!modal) {
            return;
        }

        modal.classList.remove("show");

        if (
            !document.querySelector(
                ".schedule-modal-overlay.show"
            )
        ) {

            document.body.style.overflow =
                "";
        }
    }


    function showMessage(message, title = "Aviso") {
        let modal = document.getElementById("sigepNoticeModal");
        if (!modal) {
            modal = document.createElement("div");
            modal.id = "sigepNoticeModal";
            modal.className = "schedule-modal-overlay sigep-notice-modal";
            modal.innerHTML = `<div class="schedule-modal sigep-notice-box"><header class="schedule-modal-header"><div class="schedule-modal-title"><div class="schedule-modal-icon"><i class="fa-solid fa-circle-info"></i></div><div><h2 id="sigepNoticeTitle">Aviso</h2><p>Gestión de turnos y horarios</p></div></div><button class="schedule-modal-close" id="sigepNoticeClose" type="button"><i class="fa-solid fa-xmark"></i></button></header><div class="schedule-modal-body"><p id="sigepNoticeText" class="sigep-notice-text"></p></div><footer class="schedule-modal-footer"><button class="save-schedule-button" id="sigepNoticeAccept" type="button">Entendido</button></footer></div>`;
            document.body.appendChild(modal);
            const dismiss = () => closeModal(modal);
            modal.querySelector("#sigepNoticeClose").addEventListener("click", dismiss);
            modal.querySelector("#sigepNoticeAccept").addEventListener("click", dismiss);
            modal.addEventListener("click", e => { if (e.target === modal) dismiss(); });
        }
        modal.querySelector("#sigepNoticeTitle").textContent = title;
        modal.querySelector("#sigepNoticeText").textContent = message;
        openModal(modal);
    }
    /* =====================================================
   VALIDACIÓN DE HORAS
===================================================== */
function convertTo24Hour(hour, period) {

    const numericHour = Number(hour);

    if (
        !numericHour ||
        numericHour < 1 ||
        numericHour > 12
    ) {
        return "";
    }

    let hour24 = numericHour;

    if (period === "AM") {

        if (hour24 === 12) {
            hour24 = 0;
        }

    } else if (period === "PM") {

        if (hour24 !== 12) {
            hour24 += 12;
        }

    } else {
        return "";
    }

    return `${String(hour24).padStart(2, "0")}:00`;
}


function convertFrom24Hour(time) {

    if (!time) {
        return {
            hour: "",
            period: "AM"
        };
    }

    const [hourText] =
        time.split(":");

    const hour24 =
        Number(hourText);

    const period =
        hour24 >= 12
            ? "PM"
            : "AM";

    const hour12 =
        hour24 % 12 || 12;

    return {
        hour: String(hour12),
        period
    };
}
function timeToMinutes(time) {

    if (!time) {
        return null;
    }

    const [hours, minutes] =
        time.split(":").map(Number);

    return (
        hours * 60 +
        minutes
    );
}


function validateContinuousSchedule(
    journey,
    entry,
    exit
) {

    const entryMinutes =
        timeToMinutes(entry);

    const exitMinutes =
        timeToMinutes(exit);


    /* La salida debe ser posterior a la entrada */

    if (
        exitMinutes <= entryMinutes
    ) {

        showMessage(
            "La hora de salida debe ser posterior a la hora de entrada."
        );

        return false;
    }


    /* TURNO MAÑANA */

    if (
        journey === "Mañana" &&
        entryMinutes >= 12 * 60
    ) {

        showMessage(
            "El turno mañana debe iniciar antes de las 12:00."
        );

        return false;
    }


    /* TURNO TARDE */

    if (
        journey === "Tarde" &&
        entryMinutes < 12 * 60
    ) {

        showMessage(
            "El turno tarde debe iniciar desde las 12:00 en adelante."
        );

        return false;
    }


    return true;
}


    /* =====================================================
       HORARIOS FRECUENTES - SELECT
    ===================================================== */
        function loadFrequentScheduleSelects() {

        const schedules =
            STORAGE.getActiveFrequentSchedules();

        const selects = [
            frequentScheduleSelect,
            multipleFrequentSchedule
        ];

        selects.forEach(select => {

            if (!select) return;

            select.innerHTML =
                `<option value="">Personalizar horario</option>`;

            schedules.forEach(schedule => {

                const option =
                    document.createElement("option");

                option.value =
                    schedule.id;

                option.textContent =
                    `${schedule.name} · ${STORAGE.formatScheduleHours(schedule)}`;

                select.appendChild(option);
            });
        });
    }


    function getFrequentScheduleById(id) {

        if (!id) {
            return null;
        }

        return STORAGE
            .getFrequentSchedules()
            .find(schedule =>
                String(schedule.id) === String(id)
            ) || null;
    }


    function applyFrequentScheduleToForm(
        schedule,
        prefix = "single"
    ) {

        if (!schedule) {
            return;
        }

        if (prefix === "single") {

            scheduleJourney.value =
                schedule.journey || "continuous";

            updateSingleJourneyFields();

            if (
                schedule.journey === "split"
            ) {

                scheduleEntry1.value =
                    schedule.entry1 || "";

                scheduleExit1.value =
                    schedule.exit1 || "";

                scheduleEntry2.value =
                    schedule.entry2 || "";

                scheduleExit2.value =
                    schedule.exit2 || "";

            } else {

       const entry12 =
    convertFrom24Hour(
        schedule.entry
    );
const exit12 =
    convertFrom24Hour(
        schedule.exit
    );

scheduleEntryHour.value =
    entry12.hour;

scheduleEntryPeriod.value =
    entry12.period;

scheduleExitHour.value =
    exit12.hour;

scheduleExitPeriod.value =
    exit12.period;
            }

            scheduleTolerance.value =
                schedule.tolerance ?? 10;
        }


        if (prefix === "multiple") {

            multipleJourney.value =
                schedule.journey || "continuous";

            updateMultipleJourneyFields();

            if (
                schedule.journey === "split"
            ) {

                multipleEntry1.value =
                    schedule.entry1 || "";

                multipleExit1.value =
                    schedule.exit1 || "";

                multipleEntry2.value =
                    schedule.entry2 || "";

                multipleExit2.value =
                    schedule.exit2 || "";

            } else {

                multipleEntry.value =
                    schedule.entry || "";

                multipleExit.value =
                    schedule.exit || "";
            }

            multipleTolerance.value =
                schedule.tolerance ?? 10;
        }
    }


    /* =====================================================
       HORARIOS RÁPIDOS
       Evita que el administrador tenga que escribir horas manualmente.
    ===================================================== */
    function getQuickOptions(journey) {
        if (journey === "Mañana") {
            return [
                ["09:00|14:00", "9:00 a. m. - 2:00 p. m."],
                ["10:00|15:00", "10:00 a. m. - 3:00 p. m."]
            ];
        }
        if (journey === "Tarde") {
            return [
                ["15:00|20:00", "3:00 p. m. - 8:00 p. m."],
                ["16:00|21:00", "4:00 p. m. - 9:00 p. m."]
            ];
        }
        if (journey === "Completo") {
            return [
                ["10:00|14:00|15:00|21:00", "10:00 a. m. - 2:00 p. m. / 3:00 p. m. - 9:00 p. m."],
                ["09:00|14:00|15:00|20:00", "9:00 a. m. - 2:00 p. m. / 3:00 p. m. - 8:00 p. m."]
            ];
        }
        return [];
    }

    function ensureQuickSelector(id, journeySelect, fields, onApply) {
        let group = document.getElementById(id + "Group");
        let select = document.getElementById(id);
        if (!group) {
            group = document.createElement("div");
            group.id = id + "Group";
            group.className = "schedule-form-group quick-schedule-group";
            group.innerHTML = `<label>Horario rápido <span>*</span></label><select id="${id}"></select><small>Elige un horario listo. Usa “Personalizado” solo si necesitas otro.</small>`;
            fields.parentNode.insertBefore(group, fields);
            select = group.querySelector("select");
        }
        const journey = journeySelect.value;
        const options = getQuickOptions(journey);
        group.style.display = options.length ? "" : "none";
        if (!options.length) return null;
        const previous = select.value;
        select.innerHTML = options.map(([value,label]) => `<option value="${value}">${label}</option>`).join("") + `<option value="custom">Otro horario...</option>`;
        if (options.some(([v]) => v === previous)) select.value = previous;
        fields.style.display = select.value === "custom" ? "" : "none";
        const apply = () => {
            fields.style.display = select.value === "custom" ? "" : "none";
            if (select.value !== "custom") onApply(select.value);
        };
        select.onchange = apply;
        apply();
        return select;
    }

    function setSingleQuickTime(value) {
        const parts = value.split("|");
        if (parts.length === 4) {
            scheduleEntry1.value = parts[0];
            scheduleExit1.value = parts[1];
            scheduleEntry2.value = parts[2];
            scheduleExit2.value = parts[3];
            refreshSplit12h();
            return;
        }
        const [entry, exit] = parts;
        const e = convertFrom24Hour(entry);
        const x = convertFrom24Hour(exit);
        scheduleEntryHour.value = e.hour;
        scheduleEntryPeriod.value = e.period;
        scheduleExitHour.value = x.hour;
        scheduleExitPeriod.value = x.period;
    }

    function refreshSingleQuickSelector() {
        if (!continuousScheduleFields) return;
        const targetFields = scheduleJourney.value === "Completo" ? splitScheduleFields : continuousScheduleFields;
        ensureQuickSelector("singleQuickSchedule", scheduleJourney, targetFields, setSingleQuickTime);
    }

    function refreshMultipleQuickSelector() {
        if (!multipleContinuousFields) return;
        const targetFields = multipleJourney.value === "Completo" ? multipleSplitFields : multipleContinuousFields;
        ensureQuickSelector("multipleQuickSchedule", multipleJourney, targetFields, value => {
            const parts = value.split("|");
            if (parts.length === 4) {
                multipleEntry1.value = parts[0];
                multipleExit1.value = parts[1];
                multipleEntry2.value = parts[2];
                multipleExit2.value = parts[3];
                return;
            }
            multipleEntry.value = parts[0];
            multipleExit.value = parts[1];
        });
    }

    function enhanceSplitTime12h(input){
        if(!input || input.dataset.enhanced12h) return;
        input.dataset.enhanced12h="1"; input.style.display="none";
        const wrap=document.createElement("div"); wrap.className="schedule-time-12h split-time-12h";
        const hour=document.createElement("select"); hour.innerHTML='<option value="">Hora</option>'+Array.from({length:12},(_,i)=>`<option value="${i+1}">${i+1}:00</option>`).join('');
        const period=document.createElement("select"); period.innerHTML='<option value="AM">a. m.</option><option value="PM">p. m.</option>';
        wrap.append(hour,period); input.after(wrap);
        const syncHidden=()=>{ if(!hour.value){input.value="";return;} input.value=convertTo24Hour(hour.value,period.value)||""; };
        const syncVisible=()=>{ if(!input.value){hour.value="";return;} const v=convertFrom24Hour(input.value); hour.value=v.hour; period.value=v.period; };
        hour.onchange=syncHidden; period.onchange=syncHidden; input._sync12h=syncVisible; syncVisible();
    }
    function refreshSplit12h(){[scheduleEntry1,scheduleExit1,scheduleEntry2,scheduleExit2,multipleEntry1,multipleExit1,multipleEntry2,multipleExit2].forEach(enhanceSplitTime12h); [scheduleEntry1,scheduleExit1,scheduleEntry2,scheduleExit2,multipleEntry1,multipleExit1,multipleEntry2,multipleExit2].forEach(i=>i?._sync12h?.());}

    /* =====================================================
       MODAL INDIVIDUAL
    ===================================================== */

 function updateSingleJourneyFields() {

    const journey =
        scheduleJourney.value;

    const showContinuous =
        journey === "Mañana" ||
        journey === "Tarde";

    const showSplit =
        journey === "Completo";

    if (continuousScheduleFields) {
        continuousScheduleFields.style.display =
            showContinuous ? "" : "none";
    }

    if (splitScheduleFields) {
        splitScheduleFields.style.display =
            showSplit ? "" : "none";
    }

    if (toleranceGroup) {
        toleranceGroup.style.display =
            journey && journey !== "Libre"
                ? ""
                : "none";
    }

    refreshSingleQuickSelector();
}


    function resetScheduleForm() {

        scheduleForm.reset();

        scheduleJourney.value =
    "";

        scheduleTolerance.value =
            "10";

        updateSingleJourneyFields();
    }


    function openWorkerScheduleModal(
        workerId,
        existingSchedule = null
    ) {

        if (blockPastDateAction()) {
            return;
        }

        const worker =
            STORAGE.getWorkerById(workerId);

        if (!worker) {
            showMessage(
                "No se encontró al trabajador."
            );
            return;
        }

        selectedWorkerId =
            workerId;

        resetScheduleForm();

        selectedWorkerAvatar.textContent =
            getInitials(worker);

        selectedWorkerName.textContent =
            getWorkerName(worker);

        selectedWorkerPosition.textContent =
            STORAGE.getWorkerPositionName(worker);

        modalScheduleDate.textContent =
            capitalize(
                formatLongDate(selectedDate)
            );


        if (existingSchedule) {

            scheduleJourney.value =
                existingSchedule.journey ||
                "continuous";

            scheduleTolerance.value =
                existingSchedule.tolerance ??
                10;

            if (
                existingSchedule.frequentScheduleId
            ) {

                frequentScheduleSelect.value =
                    existingSchedule.frequentScheduleId;
            }


            if (
                existingSchedule.journey === "Completo" ||
                existingSchedule.journey === "split"
            ) {

                scheduleEntry1.value =
                    existingSchedule.entry1 || "";

                scheduleExit1.value =
                    existingSchedule.exit1 || "";

                scheduleEntry2.value =
                    existingSchedule.entry2 || "";

                scheduleExit2.value =
                    existingSchedule.exit2 || "";

            } else {

    const entry12 =
        convertFrom24Hour(
            existingSchedule.entry
        );

    const exit12 =
        convertFrom24Hour(
            existingSchedule.exit
        );

    scheduleEntryHour.value =
        entry12.hour;

    scheduleEntryPeriod.value =
        entry12.period;

    scheduleExitHour.value =
        exit12.hour;

    scheduleExitPeriod.value =
        exit12.period;
}

            updateSingleJourneyFields();
        }

        openModal(scheduleModal);
    }


 scheduleJourney?.addEventListener(
    "change",
    () => {
        updateSingleJourneyFields();
    }
);


    frequentScheduleSelect?.addEventListener(
        "change",
        () => {

            const schedule =
                getFrequentScheduleById(
                    frequentScheduleSelect.value
                );

            if (!schedule) {
                return;
            }

            applyFrequentScheduleToForm(
                schedule,
                "single"
            );
        }
    );


    closeScheduleModal?.addEventListener(
        "click",
        () => {

            closeModal(scheduleModal);
        }
    );


    cancelScheduleModal?.addEventListener(
        "click",
        () => {

            closeModal(scheduleModal);
        }
    );

    closeScheduleActionsModal?.addEventListener("click", () => closeModal(scheduleActionsModal));
    cancelScheduleActionsModal?.addEventListener("click", () => closeModal(scheduleActionsModal));



    function isScheduleStartAlreadyPast(data){
        const now=new Date();
        const todayKey=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}-${String(now.getDate()).padStart(2,"0")}`;
        if(selectedDate!==todayKey) return false;
        const start=data.journey==="Completo"?data.entry1:data.entry;
        if(!start) return false;
        const [hh,mm]=start.split(":").map(Number);
        if(hh*60+mm <= now.getHours()*60+now.getMinutes()){
            showMessage(`Ese turno empieza a ${formatTime12h(start)} y ya pasó. Para hoy solo puedes programar horarios que aún no hayan comenzado.`);
            return true;
        }
        return false;
    }

    scheduleForm?.addEventListener(
        "submit",
        event => {

            event.preventDefault();

            if (blockPastDateAction()) {

                closeModal(scheduleModal);

                return;
            }

            if (!selectedWorkerId) {

                showMessage(
                    "Selecciona un trabajador."
                );

                return;
            }

            const journey =
                scheduleJourney.value;

            if (!journey) {
                showMessage("Selecciona una jornada.");
                return;
            }

            if (journey === "Libre") {
                STORAGE.setWorkerFreeDay(
                    selectedWorkerId,
                    selectedDate
                );

                closeModal(scheduleModal);
                selectedWorkerId = null;
                refreshDailySchedule();
                showMessage("Descanso asignado correctamente.");
                return;
            }

            const scheduleData = {

    workerId:
        selectedWorkerId,

    date:
        selectedDate,

    journey,

    tolerance:
        Number(
            scheduleTolerance.value || 0
        ),

    freeDay:
        false
};


                if (journey === "Completo") {
                if (
                    !scheduleEntry1.value ||
                    !scheduleExit1.value ||
                    !scheduleEntry2.value ||
                    !scheduleExit2.value
                ) {

                    showMessage(
                        "Completa todos los horarios de la jornada."
                    );

                    return;
                }

                scheduleData.entry1 =
                    scheduleEntry1.value;

                scheduleData.exit1 =
                    scheduleExit1.value;

                scheduleData.entry2 =
                    scheduleEntry2.value;

                scheduleData.exit2 =
                    scheduleExit2.value;

                scheduleData.entry =
                    "";

                scheduleData.exit =
                    "";
} else {

    if (
        !scheduleEntryHour.value ||
        !scheduleExitHour.value
    ) {

        showMessage(
            "Completa la hora de entrada y salida."
        );

        return;
    }

    const entry24 =
        convertTo24Hour(
            scheduleEntryHour.value,
            scheduleEntryPeriod.value
        );

    const exit24 =
        convertTo24Hour(
            scheduleExitHour.value,
            scheduleExitPeriod.value
        );

    if (
        !entry24 ||
        !exit24
    ) {

        showMessage(
            "Las horas ingresadas no son válidas."
        );

        return;
    }

    if (
        !validateContinuousSchedule(
            journey,
            entry24,
            exit24
        )
    ) {
        return;
    }

    scheduleData.entry =
        entry24;

    scheduleData.exit =
        exit24;

    scheduleData.entry1 = "";
    scheduleData.exit1 = "";
    scheduleData.entry2 = "";
    scheduleData.exit2 = "";
}

            if (isScheduleStartAlreadyPast(scheduleData)) return;

            STORAGE.saveWorkerSchedule(
                scheduleData
            );

            closeModal(scheduleModal);

            selectedWorkerId =
                null;

            refreshDailySchedule();

            showMessage(
                "Horario guardado correctamente."
            );
        }
    );


    /* =====================================================
       ASIGNACIÓN MÚLTIPLE
    ===================================================== */
function updateMultipleJourneyFields() {

    const journey =
        multipleJourney.value;

    const showContinuous =
        journey === "Mañana" ||
        journey === "Tarde";

    const showSplit =
        journey === "Completo";

    if (multipleContinuousFields) {
        multipleContinuousFields.style.display =
            showContinuous ? "" : "none";
    }

    if (multipleSplitFields) {
        multipleSplitFields.style.display =
            showSplit ? "" : "none";
    }

    refreshMultipleQuickSelector();
}

function resetMultipleAssignForm() {

    multipleAssignForm.reset();

    multipleJourney.value = "";

    multipleTolerance.value = "10";

    updateMultipleJourneyFields();
}


    openMultipleAssignModal?.addEventListener(
        "click",
        () => {

            if (blockPastDateAction()) return;

            if (!multipleSelectionMode) {
                multipleSelectionMode = true;
                selectedWorkerIds = [];
                openMultipleAssignModal.innerHTML = '<i class="fa-solid fa-check"></i> Asignar seleccionados';
                openMultipleAssignModal.classList.add("selection-active");
                document.querySelector(".schedule-card")?.classList.add("selection-mode");
                renderScheduleTable();
                return;
            }

            if (selectedWorkerIds.length === 0) {
                multipleSelectionMode = false;
                openMultipleAssignModal.innerHTML = '<i class="fa-solid fa-users"></i> Asignación múltiple';
                openMultipleAssignModal.classList.remove("selection-active");
                document.querySelector(".schedule-card")?.classList.remove("selection-mode");
                renderScheduleTable();
                return;
            }

            resetMultipleAssignForm();

            multipleSelectedCount.textContent =
                `${selectedWorkerIds.length} trabajador${
                    selectedWorkerIds.length === 1
                        ? ""
                        : "es"
                } seleccionado${
                    selectedWorkerIds.length === 1
                        ? ""
                        : "s"
                }`;

            openModal(
                multipleAssignModal
            );
        }
    );


    closeMultipleAssignModal?.addEventListener(
        "click",
        () => {

            closeModal(
                multipleAssignModal
            );
        }
    );


    cancelMultipleAssignModal?.addEventListener(
        "click",
        () => {

            closeModal(
                multipleAssignModal
            );
        }
    );


   multipleJourney?.addEventListener(
    "change",
    () => {
        updateMultipleJourneyFields();
    }
);


    multipleFrequentSchedule?.addEventListener(
        "change",
        () => {

            const schedule =
                getFrequentScheduleById(
                    multipleFrequentSchedule.value
                );

            if (!schedule) {
                return;
            }

            applyFrequentScheduleToForm(
                schedule,
                "multiple"
            );
        }
    );
        multipleAssignForm?.addEventListener(
        "submit",
        event => {

            event.preventDefault();

            if (blockPastDateAction()) {
                closeModal(multipleAssignModal);
                return;
            }

            if (selectedWorkerIds.length === 0) {

                showMessage(
                    "No hay trabajadores seleccionados."
                );

                return;
            }

            const journey =
                multipleJourney.value;

                if (journey === "Libre") {
                selectedWorkerIds.forEach(workerId => {

                    STORAGE.setWorkerFreeDay(
                        workerId,
                        selectedDate
                    );
                });

                closeModal(
                    multipleAssignModal
                );
                selectedWorkerIds = []; multipleSelectionMode = false;
                if (openMultipleAssignModal) {
                    openMultipleAssignModal.innerHTML = '<i class="fa-solid fa-users"></i> Asignación múltiple';
                    openMultipleAssignModal.classList.remove("selection-active");
                    document.querySelector(".schedule-card")?.classList.remove("selection-mode");
                }

                refreshDailySchedule();

                showMessage(
                    "Descanso asignado correctamente."
                );

                return;
            }

            if (!journey) {
                showMessage("Selecciona una jornada.");
                return;
            }

            const scheduleData = {

                journey,

                tolerance:
                    Number(
                        multipleTolerance.value || 0
                    ),
                freeDay:
                    false
            };


                if (journey === "Completo") {
                if (
                    !multipleEntry1.value ||
                    !multipleExit1.value ||
                    !multipleEntry2.value ||
                    !multipleExit2.value
                ) {

                    showMessage(
                        "Completa todos los horarios."
                    );

                    return;
                }

                scheduleData.entry1 =
                    multipleEntry1.value;

                scheduleData.exit1 =
                    multipleExit1.value;

                scheduleData.entry2 =
                    multipleEntry2.value;

                scheduleData.exit2 =
                    multipleExit2.value;

                scheduleData.entry =
                    "";

                scheduleData.exit =
                    "";

            } else {

                if (
                    !multipleEntry.value ||
                    !multipleExit.value
                ) {

                    showMessage(
                        "Completa la hora de entrada y salida."
                    );

                    return;
                }

                if (!validateContinuousSchedule(
                    journey,
                    multipleEntry.value,
                    multipleExit.value
                )) {
                    return;
                }

                scheduleData.entry =
                    multipleEntry.value;

                scheduleData.exit =
                    multipleExit.value;

                scheduleData.entry1 =
                    "";

                scheduleData.exit1 =
                    "";

                scheduleData.entry2 =
                    "";

                scheduleData.exit2 =
                    "";
            }


            STORAGE.assignScheduleToWorkers(
                selectedWorkerIds,
                selectedDate,
                scheduleData
            );

            closeModal(
                multipleAssignModal
            );

            refreshDailySchedule();

            showMessage(
                "Horarios asignados correctamente."
            );
        }
    );


    /* =====================================================
       COPIAR PROGRAMACIÓN DE OTRO DÍA
    ===================================================== */

    openCopyDayModal?.addEventListener(
        "click",
        () => {

            if (blockPastDateAction()) {
                return;
            }

            const source =
                parseISODate(selectedDate);

            source.setDate(
                source.getDate() - 1
            );

            const year =
                source.getFullYear();

            const month =
                String(source.getMonth() + 1)
                    .padStart(2, "0");

            const day =
                String(source.getDate())
                    .padStart(2, "0");

            copySourceDate.value = `${year}-${month}-${day}`;

            copyTargetDate.value = selectedDate;

            openModal(
                copyDayModal
            );
        }
    );


    closeCopyDayModal?.addEventListener(
        "click",
        () => {

            closeModal(
                copyDayModal
            );
        }
    );


    cancelCopyDayModal?.addEventListener(
        "click",
        () => {

            closeModal(
                copyDayModal
            );
        }
    );


    copyDayForm?.addEventListener(
        "submit",
        event => {

            event.preventDefault();

            /*
             * La fecha seleccionada es siempre
             * el destino de la copia.
             *
             * Nunca permitimos escribir sobre
             * una fecha pasada.
             */

            /* El origen puede ser pasado; el destino se valida después. */

            const sourceDate =
                copySourceDate.value;

            const targetDate =
                copyTargetDate.value;

            if (!sourceDate || !targetDate) {

                showMessage(
                    "Selecciona el día de origen y el día de destino."
                );

                return;
            }

            if (isPastDate(targetDate)) {
                showMessage(
                    "El día de destino no puede ser una fecha pasada."
                );
                return;
            }

            if (
                sourceDate === targetDate
            ) {

                showMessage(
                    "El día de origen y el día de destino no pueden ser iguales."
                );

                return;
            }


            /*
             * IMPORTANTE:
             * El origen SÍ puede ser una fecha pasada.
             *
             * Ejemplo:
             * lunes pasado -> mañana
             */

            const sourceSchedules =
                STORAGE.getSchedulesByDate(
                    sourceDate
                );

            if (
                !sourceSchedules ||
                sourceSchedules.length === 0
            ) {

                showMessage(
                    "El día seleccionado no tiene programación para copiar."
                );

                return;
            }


            const currentTargetSchedules =
                STORAGE.getSchedulesByDate(
                    targetDate
                );


            if (
                currentTargetSchedules &&
                currentTargetSchedules.length > 0
            ) {

                const confirmReplace =
                    confirm(
                        "El día de destino ya tiene trabajadores programados. ¿Deseas reemplazar la programación?"
                    );

                if (!confirmReplace) {
                    return;
                }
            }


            STORAGE.copyDailySchedule(
                sourceDate,
                targetDate
            );

            closeModal(
                copyDayModal
            );

            refreshDailySchedule();

            showMessage(
                "Programación copiada correctamente."
            );
        }
    );


    /* =====================================================
       FECHA SUPERIOR
    ===================================================== */

    function renderTopDate() {

        if (!dashboardDate) {
            return;
        }

        const today =
            new Date();

        dashboardDate.textContent =
            capitalize(
                today.toLocaleDateString(
                    "es-PE",
                    {
                        weekday: "long",
                        day: "numeric",
                        month: "long",
                        year: "numeric"
                    }
                )
            );
    }


    /* =====================================================
       FECHA DE PROGRAMACIÓN
    ===================================================== */

    function renderSelectedDate() {

        const formattedDate =
            capitalize(
                formatLongDate(
                    selectedDate
                )
            );

        if (selectedDateText) {

            selectedDateText.textContent =
                formattedDate;
        }

        if (scheduleDate) {

            scheduleDate.value =
                selectedDate;
        }

        if (modalScheduleDate) {

            modalScheduleDate.textContent =
                formattedDate;
        }

        if (copyTargetDate) {

            copyTargetDate.value =
                selectedDate;
        }
    }


    previousDay?.addEventListener(
        "click",
        () => {

            changeDate(-1);
        }
    );


    nextDay?.addEventListener(
        "click",
        () => {

            changeDate(1);
        }
    );


    todayButton?.addEventListener(
        "click",
        () => {

            selectedDate =
                getTodayISO();

            refreshDailySchedule();
        }
    );


    const datePickerButton =
        document.querySelector(".date-picker-button");

    datePickerButton?.addEventListener(
        "click",
        (event) => {
            event.preventDefault();
            if (!scheduleDate) return;
            if (typeof scheduleDate.showPicker === "function") {
                try { scheduleDate.showPicker(); return; } catch (_) {}
            }
            scheduleDate.focus();
            scheduleDate.click();
        }
    );


    scheduleDate?.addEventListener(
        "change",
        () => {

            if (!scheduleDate.value) {
                return;
            }

            selectedDate =
                scheduleDate.value;

            refreshDailySchedule();
        }
    );


    /* =====================================================
       ESTADÍSTICAS DEL DÍA
    ===================================================== */

    function getActiveWorkers() {

        return STORAGE
            .getWorkers()
            .filter(worker => {

                const status =
                    String(
                        worker.status || "active"
                    ).toLowerCase();

                return (
                    status === "active" ||
                    status === "activo"
                );
            });
    }


    function renderStats() {

        const workers =
            getActiveWorkers();

        const total =
            workers.length;

        let programmed =
            0;

        let free =
            0;

        let unassigned =
            0;


        workers.forEach(worker => {

            const schedule =
                STORAGE.getWorkerScheduleByDate(
                    worker.id,
                    selectedDate
                );

            if (!schedule) {

                unassigned++;

                return;
            }

            if (schedule.freeDay) {

                free++;

                return;
            }

            programmed++;
        });


        if (totalScheduleWorkers) {

            totalScheduleWorkers.textContent =
                total;
        }

        if (scheduledWorkers) {

            scheduledWorkers.textContent =
                programmed;
        }

        if (freeDayWorkers) {

            freeDayWorkers.textContent =
                free;
        }

        if (unassignedWorkers) {

            unassignedWorkers.textContent =
                unassigned;
        }
    }


    /* =====================================================
       FILTRO DE CARGOS
    ===================================================== */

    function loadPositionFilter() {

        if (!schedulePositionFilter) {
            return;
        }

        const currentValue =
            schedulePositionFilter.value;

        schedulePositionFilter.innerHTML =
            `<option value="">Todos los cargos</option>`;

        const positions =
            STORAGE
                .getPositions()
                .filter(position => {

                    const status =
                        String(
                            position.status || "active"
                        ).toLowerCase();

                    return (
                        status === "active" ||
                        status === "activo"
                    );
                });


        positions.forEach(position => {

            const option =
                document.createElement(
                    "option"
                );

            option.value =
                position.id;

            option.textContent =
                position.name;

            schedulePositionFilter.appendChild(
                option
            );
        });


        if (
            [...schedulePositionFilter.options]
                .some(
                    option =>
                        option.value ===
                        currentValue
                )
        ) {

            schedulePositionFilter.value =
                currentValue;
        }
    }


    /* =====================================================
       ESTADO DE PROGRAMACIÓN
    ===================================================== */
function getScheduleStatus(schedule) {

    if (!schedule) {
        return {
            text: "Sin asignar",
            className: "unassigned"
        };
    }

    if (schedule.journey === "Libre") {
        return { text: "Descanso", className: "free" };
    }
    if (schedule.replacementWorkerId) return { text: "Reemplazado", className: "replacement" };
    if (schedule.isReplacement) return { text: "Reemplazo", className: "replacement" };

    return {
        text: "Programado",
        className: "programmed"
    };
}


function getJourneyClass(journey) {

    switch (journey) {

        case "Mañana":
            return "morning";

        case "Tarde":
            return "afternoon";

        case "Completo":
            return "full";

        case "Libre":
            return "free";

        default:
            return "";
    }
}


function formatTime12(time) {
    if (!time || time === "—") {
        return "—";
    }

    const [hour, minute] = time.split(":").map(Number);

    const period = hour >= 12 ? "p. m." : "a. m.";
    const hour12 = hour % 12 || 12;

    return `${hour12}:${String(minute).padStart(2, "0")} ${period}`;
}


function renderScheduleTime(schedule) {

    if (!schedule) {
        return `
            <span class="schedule-empty">
                —
            </span>
        `;
    }

    if (schedule.journey === "Libre") {
        return `
            <span class="schedule-empty">
                No trabaja
            </span>
        `;
    }

    if (schedule.journey === "Completo") {
        return `
            <div class="schedule-time-display">

                <strong>
                    ${escapeHTML(formatTime12(schedule.entry1))}
                    -
                    ${escapeHTML(formatTime12(schedule.exit1))}
                </strong>

                <strong>
                    ${escapeHTML(formatTime12(schedule.entry2))}
                    -
                    ${escapeHTML(formatTime12(schedule.exit2))}
                </strong>

                <span class="schedule-tolerance-text">
                    Tolerancia: ${Number(schedule.tolerance) || 0} min
                </span>

            </div>
        `;
    }

    return `
        <div class="schedule-time-display">

            <strong>
                ${escapeHTML(formatTime12(schedule.entry))}
                -
                ${escapeHTML(formatTime12(schedule.exit))}
            </strong>

            <span>
                Tolerancia:
                ${Number(schedule.tolerance) || 0} min
            </span>

        </div>
    `;
}


/* =====================================================
   FILTRADO DE TRABAJADORES
===================================================== */

function getFilteredWorkers() {

    const workers =
        STORAGE.getActiveWorkers();

    const search =
        STORAGE.normalizeText(
            scheduleSearch.value
        );

    const positionId =
        schedulePositionFilter.value;

    const statusFilter =
        scheduleStatusFilter.value;


    return workers.filter(worker => {

        const workerName =
            STORAGE.normalizeText(
                getWorkerName(worker)
            );

        const documentNumber =
            STORAGE.normalizeText(
                worker.dni || worker.documentNumber || ""
            );

        const matchesSearch =
            !search ||
            workerName.includes(search) ||
            documentNumber.includes(search);

        const matchesPosition =
            !positionId ||
            Number(worker.positionId) ===
                Number(positionId);

        const schedule =
            STORAGE.getWorkerScheduleByDate(
                worker.id,
                selectedDate
            );

        let status =
            "Sin asignar";

        if (schedule) {
            status =
                schedule.journey === "Libre"
                    ? "Libre"
                    : "Programado";
        }

        const matchesStatus =
            !statusFilter ||
            status === statusFilter;

        return (
            matchesSearch &&
            matchesPosition &&
            matchesStatus
        );
    });
}


/* =====================================================
   TABLA PROGRAMACIÓN
===================================================== */

function renderScheduleTable() {

    const workers =
        getFilteredWorkers();


    if (workers.length === 0) {

        scheduleTableBody.innerHTML = `
            <tr class="schedule-empty-row">

                <td colspan="6">

                    <div class="schedule-empty-state">

                        <i class="fa-regular fa-calendar-xmark"></i>

                        <strong>
                            No se encontraron trabajadores
                        </strong>

                        <p>
                            Cambia los filtros o registra trabajadores activos.
                        </p>

                    </div>

                </td>

            </tr>
        `;

        scheduleResultText.textContent =
            "0 trabajadores";

        updateSelectedWorkersUI();

        return;
    }


    scheduleTableBody.innerHTML =
        workers.map(worker => {

            const schedule =
                STORAGE.getWorkerScheduleByDate(
                    worker.id,
                    selectedDate
                );

            const position =
                STORAGE.getWorkerPositionName(
                    worker
                );

            const status =
                getScheduleStatus(
                    schedule
                );

            const checked =
                selectedWorkerIds.includes(
                    Number(worker.id)
                );


            return `
                <tr>

                    <td class="selection-column ${multipleSelectionMode ? "selection-visible" : ""}">

                        <input
                            type="checkbox"
                            class="schedule-worker-checkbox"
                            data-worker-id="${worker.id}"
                            ${checked ? "checked" : ""}
                            ${isPastDate(selectedDate) ? "disabled" : ""}
                        >

                    </td>


                    <td>

                        <div class="schedule-worker">

                            <div class="schedule-worker-avatar">
                                ${escapeHTML(getInitials(worker))}
                            </div>

                            <div class="schedule-worker-info">

                                <strong>
                                    ${escapeHTML(getWorkerName(worker))}
                                </strong>

                                <span>
                                    ${escapeHTML(worker.dni || worker.documentNumber || "Sin documento")}
                                </span>
                                ${schedule?.replacementWorkerId ? `<span class="replacement-note">↪ Reemplazado por ${escapeHTML(getWorkerName(STORAGE.getWorkerById(schedule.replacementWorkerId)))}</span>` : ""}
                                ${schedule?.isReplacement ? `<span class="replacement-note">↪ Reemplazo de ${escapeHTML(getWorkerName(STORAGE.getWorkerById(schedule.replacementForWorkerId)))}</span>` : ""}

                            </div>

                        </div>

                    </td>


                    <td>
                        ${escapeHTML(position)}
                    </td>


                    <td class="programming-cell">

                        ${
                            schedule
                                ? `
                                    <div class="programming-summary">
                                        <span class="journey-badge ${getJourneyClass(schedule.journey)}">
                                            ${escapeHTML(
                                                schedule.journey === "Libre"
                                                    ? "Descanso"
                                                    : schedule.journey
                                            )}
                                        </span>
                                        <div class="programming-time">${renderScheduleTime(schedule)}</div>
                                    </div>
                                `
                                : `
                                    <button type="button" class="quick-assign-row" data-quick-assign="${worker.id}">
                                        <i class="fa-solid fa-plus"></i> Asignar
                                    </button>
                                `
                        }

                    </td>


                    <td>

                        <span class="schedule-status ${status.className}">
                            ${status.text}
                        </span>

                    </td>


                    <td>

                        <button
                            type="button"
                            class="schedule-action-button"
                            data-worker-id="${worker.id}"
                            title="${
                                isPastDate(selectedDate)
                                    ? "Día pasado · Solo lectura"
                                    : "Acciones"
                            }"
                        >
                            <i class="fa-solid fa-ellipsis-vertical"></i>
                        </button>

                    </td>

                </tr>
            `;

        }).join("");


    scheduleResultText.textContent =
        `${workers.length} ${
            workers.length === 1
                ? "trabajador"
                : "trabajadores"
        }`;


    bindScheduleTableEvents();

    updateSelectedWorkersUI();
}


function bindScheduleTableEvents() {

    document
        .querySelectorAll(
            ".schedule-worker-checkbox"
        )
        .forEach(checkbox => {

            checkbox.addEventListener(
                "change",
                event => {

                    if (isPastDate(selectedDate)) {
                        event.target.checked = false;
                        return;
                    }

                    const workerId =
                        Number(
                            event.target.dataset.workerId
                        );

                    if (event.target.checked) {

                        if (
                            !selectedWorkerIds.includes(
                                workerId
                            )
                        ) {

                            selectedWorkerIds.push(
                                workerId
                            );
                        }

                    } else {

                        selectedWorkerIds =
                            selectedWorkerIds.filter(
                                id =>
                                    id !== workerId
                            );
                    }

                    updateSelectedWorkersUI();
                }
            );
        });


    document.querySelectorAll("[data-quick-assign]").forEach(button => {
        button.addEventListener("click", event => {
            event.stopPropagation();
            if (blockPastDateAction()) return;
            openWorkerScheduleModal(Number(button.dataset.quickAssign), null);
        });
    });

    document
        .querySelectorAll(
            ".schedule-action-button"
        )
        .forEach(button => {

            button.addEventListener(
                "click",
                event => {

                    event.stopPropagation();

                    activeScheduleMenuWorkerId =
                        Number(
                            button.dataset.workerId
                        );

   openWorkerActionsModal(
    activeScheduleMenuWorkerId
);
                }
            );
        });
}


    /* =====================================================
       FILTROS TABLA
    ===================================================== */

    scheduleSearch?.addEventListener(
        "input",
        () => {

            renderScheduleTable();
        }
    );


    schedulePositionFilter?.addEventListener(
        "change",
        () => {

            renderScheduleTable();
        }
    );


    scheduleStatusFilter?.addEventListener(
        "change",
        () => {

            renderScheduleTable();
        }
    );


    /* =====================================================
       MENÚ DE ACCIONES - PROGRAMACIÓN
    ===================================================== */

 function openWorkerActionsModal(workerId) {

    if (!scheduleActionsModal) {
        return;
    }

    const worker =
        STORAGE.getWorkerById(workerId);

    if (!worker) {
        showMessage("No se encontró al trabajador.");
        return;
    }

    activeScheduleMenuWorkerId = workerId;

    const schedule =
        STORAGE.getWorkerScheduleByDate(
            workerId,
            selectedDate
        );

    const isFreeDay =
        Boolean(
            schedule &&
            (
                schedule.freeDay ||
                schedule.journey === "Libre"
            )
        );

    /* DATOS DEL TRABAJADOR */

    if (actionWorkerAvatar) {
        actionWorkerAvatar.textContent =
            getInitials(worker);
    }

    if (actionWorkerName) {
        actionWorkerName.textContent =
            getWorkerName(worker);
    }

    if (actionWorkerPosition) {
        actionWorkerPosition.textContent =
            STORAGE.getWorkerPositionName(worker);
    }

    if (actionWorkerDate) {
        actionWorkerDate.textContent =
            capitalize(
                formatLongDate(selectedDate)
            );
    }

    /* FECHA PASADA */

    const past =
        isPastDate(selectedDate);

    if (scheduleReadonlyNotice) {
        scheduleReadonlyNotice.hidden = !past;
    }

    if (workerScheduleActions) {
        workerScheduleActions.style.display =
            past ? "none" : "";
    }

    /* ACCIONES DISPONIBLES */

    const assignButton =
        workerScheduleActions?.querySelector(
            '[data-action="assign"]'
        );

    const editButton =
        workerScheduleActions?.querySelector(
            '[data-action="edit"]'
        );

    const freeButton =
        workerScheduleActions?.querySelector(
            '[data-action="free"]'
        );

    const replacementButton = workerScheduleActions?.querySelector('[data-action="replacement"]');
    const swapButton = workerScheduleActions?.querySelector('[data-action="swap"]');
    const cancelReplacementButton = workerScheduleActions?.querySelector('[data-action="cancel-replacement"]');

    const removeButton =
        workerScheduleActions?.querySelector(
            '[data-action="remove"]'
        );

    if (replacementButton) replacementButton.style.display = "none";
    if (swapButton) swapButton.style.display = "none";
    if (cancelReplacementButton) cancelReplacementButton.style.display = "none";

    if (!past) {

        /*
         * SIN ASIGNAR
         * Asignar horario + Descanso
         */

        if (!schedule) {

            if (assignButton)
                assignButton.style.display = "";

            if (editButton)
                editButton.style.display = "none";

            if (freeButton)
                freeButton.style.display = "";

            if (removeButton)
                removeButton.style.display = "none";
        }

        /*
         * DÍA LIBRE
         * Asignar horario + Quitar programación
         */

        else if (isFreeDay) {

            if (assignButton)
                assignButton.style.display = "";

            if (editButton)
                editButton.style.display = "none";

            if (freeButton)
                freeButton.style.display = "none";

            if (removeButton)
                removeButton.style.display = "";
        }

        /*
         * PROGRAMADO
         * Editar + Descanso + Quitar
         */

        else {

            if (assignButton)
                assignButton.style.display = "none";

            if (editButton)
                editButton.style.display = "";

            if (freeButton)
                freeButton.style.display = "";

            if (removeButton)
                removeButton.style.display = "";

            if (!schedule.replacementWorkerId && !schedule.isReplacement && swapButton) swapButton.style.display = "";

            if (schedule.replacementWorkerId) {
                if (cancelReplacementButton) cancelReplacementButton.style.display = "";
            } else if (!schedule.isReplacement) {
                if (replacementButton) replacementButton.style.display = "";
            }
        }
    }

    openModal(scheduleActionsModal);
}

    workerScheduleActions?.addEventListener(
    "click",
    event => {

        const button =
            event.target.closest(
                "[data-action]"
            );

        if (!button) {
            return;
        }

        const action =
            button.dataset.action;

        /* PROTECCIÓN PARA FECHAS PASADAS */

        if (
            isPastDate(selectedDate) &&
            [
                "assign",
                "edit",
                "free",
                "remove",
                "replacement",
                "cancel-replacement",
                "swap"
            ].includes(action)
        ) {

            showMessage(
                "No puedes modificar la programación de un día pasado."
            );

            return;
        }

        const workerId =
            activeScheduleMenuWorkerId;

        if (!workerId) {
            return;
        }

        const existingSchedule =
            STORAGE.getWorkerScheduleByDate(
                workerId,
                selectedDate
            );


        /* =========================
           ASIGNAR HORARIO
        ========================= */

        if (action === "assign") {

            closeModal(
                scheduleActionsModal
            );

            openWorkerScheduleModal(
                workerId,
                null
            );

            return;
        }


        /* =========================
           EDITAR HORARIO
        ========================= */

        if (action === "edit") {

            closeModal(
                scheduleActionsModal
            );

            openWorkerScheduleModal(
                workerId,
                existingSchedule
            );

            return;
        }


        /* =========================
           INTERCAMBIAR HORARIO
        ========================= */
        if (action === "swap") {
            if (!existingSchedule || existingSchedule.journey === "Libre") return;
            const currentWorker = STORAGE.getWorkerById(workerId);
            const candidates = STORAGE.getActiveWorkers().filter(w => {
                if (Number(w.id) === Number(workerId)) return false;
                const sc = STORAGE.getWorkerScheduleByDate(w.id, selectedDate);
                return sc && sc.journey !== "Libre" && !sc.replacementWorkerId && !sc.isReplacement;
            });
            if (!candidates.length) { showMessage("No hay otro trabajador programado con quien intercambiar horario."); return; }
            const options = candidates.map(w => {
                const sc = STORAGE.getWorkerScheduleByDate(w.id, selectedDate);
                return `<option value="${w.id}">${escapeHTML(getWorkerName(w))} · ${escapeHTML(STORAGE.formatScheduleHours(sc))}</option>`;
            }).join("");
            const overlay = document.createElement("div");
            overlay.className = "schedule-modal-overlay show swap-modal-overlay";
            overlay.innerHTML = `<div class="schedule-modal schedule-modal-medium"><header class="schedule-modal-header"><div class="schedule-modal-title"><div class="schedule-modal-icon"><i class="fa-solid fa-right-left"></i></div><div><h2>Intercambiar horario</h2><p>Cambia los horarios de dos trabajadores en un solo paso.</p></div></div><button type="button" class="schedule-modal-close swap-close"><i class="fa-solid fa-xmark"></i></button></header><div class="schedule-modal-body"><div class="selected-worker-card"><div class="selected-worker-avatar">${escapeHTML(getInitials(currentWorker))}</div><div><strong>${escapeHTML(getWorkerName(currentWorker))}</strong><span>Actual: ${escapeHTML(STORAGE.formatScheduleHours(existingSchedule))}</span></div></div><div class="schedule-form-group"><label>Intercambiar con</label><select class="swap-worker-select"><option value="">Seleccionar trabajador</option>${options}</select></div><div class="replacement-help"><i class="fa-solid fa-circle-info"></i> Ambos conservarán su programación, pero intercambiarán sus horarios.</div></div><footer class="schedule-modal-footer"><button type="button" class="cancel-schedule-button swap-close">Cancelar</button><button type="button" class="save-schedule-button swap-save"><i class="fa-solid fa-right-left"></i> Confirmar intercambio</button></footer></div>`;
            document.body.appendChild(overlay); closeModal(scheduleActionsModal);
            overlay.querySelectorAll(".swap-close").forEach(b => b.addEventListener("click", () => overlay.remove()));
            overlay.addEventListener("click", e => { if (e.target === overlay) overlay.remove(); });
            overlay.querySelector(".swap-save").addEventListener("click", () => {
                const otherId = Number(overlay.querySelector(".swap-worker-select").value);
                if (!otherId) { showMessage("Selecciona al trabajador con quien intercambiar."); return; }
                if (!STORAGE.swapWorkerSchedules(workerId, otherId, selectedDate)) { showMessage("No se pudo realizar el intercambio."); return; }
                overlay.remove(); refreshDailySchedule(); showMessage("Horarios intercambiados correctamente.");
            });
            return;
        }

        /* =========================
           REEMPLAZO DE TURNO
        ========================= */
        if (action === "replacement") {
            const originalWorker = STORAGE.getWorkerById(workerId);
            const workers = STORAGE.getActiveWorkers().filter(worker => {
                if (Number(worker.id) === Number(workerId)) return false;
                return !STORAGE.getWorkerScheduleByDate(worker.id, selectedDate);
            });
            if (!workers.length) { showMessage("No hay trabajadores disponibles para cubrir este turno."); return; }
            const options = workers.map(w => `<option value="${w.id}">${escapeHTML(getWorkerName(w))} · ${escapeHTML(STORAGE.getWorkerPositionName(w))}</option>`).join("");
            const overlay = document.createElement("div");
            overlay.className = "schedule-modal-overlay show replacement-modal-overlay";
            overlay.innerHTML = `<div class="schedule-modal schedule-modal-medium"><header class="schedule-modal-header"><div class="schedule-modal-title"><div class="schedule-modal-icon"><i class="fa-solid fa-arrow-right-arrow-left"></i></div><div><h2>Asignar reemplazo</h2><p>El turno original se conservará en el historial.</p></div></div><button type="button" class="schedule-modal-close replacement-close"><i class="fa-solid fa-xmark"></i></button></header><div class="schedule-modal-body"><div class="selected-worker-card"><div class="selected-worker-avatar">${escapeHTML(getInitials(originalWorker))}</div><div><strong>${escapeHTML(getWorkerName(originalWorker))}</strong><span>${escapeHTML(STORAGE.formatScheduleHours(existingSchedule))}</span></div></div><div class="schedule-form-group"><label>Trabajador que cubrirá el turno</label><select class="replacement-worker-select"><option value="">Seleccionar trabajador</option>${options}</select></div><div class="schedule-form-group"><label>Horario que cubrirá</label><select class="replacement-shift"><option value="original">Mismo horario del trabajador original</option><option value="Mañana|09:00|14:00">Mañana · 9:00 a. m. - 2:00 p. m.</option><option value="Mañana|10:00|15:00">Mañana · 10:00 a. m. - 3:00 p. m.</option><option value="Tarde|15:00|20:00">Tarde · 3:00 p. m. - 8:00 p. m.</option><option value="Tarde|16:00|21:00">Tarde · 4:00 p. m. - 9:00 p. m.</option><option value="Completo|09:00|14:00|15:00|20:00">Completo · 9-2 / 3-8</option><option value="Completo|10:00|14:00|15:00|21:00">Completo · 10-2 / 3-9</option></select><small>El reemplazo puede cubrir un horario distinto al original si ambos lo acuerdan.</small></div><div class="schedule-form-group"><label>Motivo del reemplazo</label><textarea class="replacement-reason" rows="3" maxlength="180" placeholder="Ej. Permiso personal, cambio acordado..."></textarea></div><div class="replacement-help"><i class="fa-solid fa-circle-info"></i> Solo aparecen trabajadores activos sin programación para este día.</div></div><footer class="schedule-modal-footer"><button type="button" class="cancel-schedule-button replacement-close">Cancelar</button><button type="button" class="save-schedule-button replacement-save"><i class="fa-solid fa-check"></i> Confirmar reemplazo</button></footer></div>`;
            document.body.appendChild(overlay);
            closeModal(scheduleActionsModal);
            overlay.querySelectorAll(".replacement-close").forEach(b => b.addEventListener("click", () => overlay.remove()));
            overlay.addEventListener("click", e => { if (e.target === overlay) overlay.remove(); });
            overlay.querySelector(".replacement-save").addEventListener("click", () => {
                const replacementId = Number(overlay.querySelector(".replacement-worker-select").value);
                const reason = overlay.querySelector(".replacement-reason").value.trim();
                if (!replacementId) { showMessage("Selecciona al trabajador que realizará el reemplazo."); return; }
                if (!reason) { showMessage("Ingresa el motivo del reemplazo."); return; }
                const shiftValue=overlay.querySelector(".replacement-shift").value; let replacementSchedule=null;
                if(shiftValue!=="original"){const p=shiftValue.split("|"); replacementSchedule={journey:p[0],tolerance:Number(existingSchedule.tolerance||0),entry:"",exit:"",entry1:"",exit1:"",entry2:"",exit2:""}; if(p[0]==="Completo"){replacementSchedule.entry1=p[1];replacementSchedule.exit1=p[2];replacementSchedule.entry2=p[3];replacementSchedule.exit2=p[4];}else{replacementSchedule.entry=p[1];replacementSchedule.exit=p[2];} if(isScheduleStartAlreadyPast(replacementSchedule)) return;}
                if (!STORAGE.assignShiftReplacement(workerId, replacementId, selectedDate, reason, replacementSchedule)) { showMessage("No se pudo registrar el reemplazo."); return; }
                overlay.remove(); refreshDailySchedule(); showMessage("Reemplazo asignado correctamente.");
            });
            return;
        }

        if (action === "cancel-replacement") {
            if (confirm("¿Deseas cancelar este reemplazo y devolver el turno al trabajador original?")) {
                closeModal(scheduleActionsModal); STORAGE.cancelShiftReplacement(workerId, selectedDate); refreshDailySchedule(); showMessage("Reemplazo cancelado correctamente.");
            }
            return;
        }

        /* =========================
           DÍA LIBRE
        ========================= */

        if (action === "free") {

            closeModal(
                scheduleActionsModal
            );

            STORAGE.setWorkerFreeDay(
                workerId,
                selectedDate
            );

            refreshDailySchedule();

            showMessage(
                "Descanso asignado correctamente."
            );

            return;
        }


        /* =========================
           QUITAR PROGRAMACIÓN
        ========================= */

        if (action === "remove") {

            const confirmed =
                confirm(
                    "¿Deseas quitar la programación de este trabajador?"
                );

            if (!confirmed) {
                return;
            }

            closeModal(
                scheduleActionsModal
            );

            STORAGE.removeWorkerSchedule(
                workerId,
                selectedDate
            );

            refreshDailySchedule();

            showMessage(
                "Programación eliminada correctamente."
            );
        }
    }
);


    /* =====================================================
       CERRAR MENÚ AL HACER CLIC FUERA
    ===================================================== */

    document.addEventListener(
        "click",
        event => {
            if (
                frequentActionsMenu &&
                !frequentActionsMenu.contains(
                    event.target
                ) &&
                !event.target.closest(
                    ".frequent-action-button"
                )
            ) {

                frequentActionsMenu.classList.remove(
                    "show"
                );
            }
        }
    );


    /* =====================================================
       PESTAÑAS
    ===================================================== */

    scheduleTabs.forEach(tab => {

        tab.addEventListener(
            "click",
            () => {

                const target =
                    tab.dataset.tab;


                scheduleTabs.forEach(
                    currentTab => {

                        currentTab.classList.remove(
                            "active"
                        );
                    }
                );


                tab.classList.add(
                    "active"
                );


                if (
                    target === "frequent"
                ) {

                    if (dailyScheduleTab) {

                        dailyScheduleTab.style.display =
                            "none";
                    }

                    if (frequentSchedulesTab) {

                        frequentSchedulesTab.style.display =
                            "";
                    }

                    renderFrequentSchedules();

                } else {

                    if (dailyScheduleTab) {

                        dailyScheduleTab.style.display =
                            "";
                    }

                    if (frequentSchedulesTab) {

                        frequentSchedulesTab.style.display =
                            "none";
                    }

                    refreshDailySchedule();
                }
            }
        );
    });


    /* =====================================================
       MODALES - CERRAR AL TOCAR FONDO
    ===================================================== */

    [
    scheduleModal,
    multipleAssignModal,
    copyDayModal,
    frequentModal,
    scheduleActionsModal
].forEach(modal => {

        modal?.addEventListener(
            "click",
            event => {

                if (
                    event.target === modal
                ) {

                    closeModal(modal);
                }
            }
        );
    });


    /* =====================================================
       TECLA ESCAPE
    ===================================================== */

  /* =====================================================
   TECLA ESCAPE
===================================================== */

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key !== "Escape"
        ) {
            return;
        }

        frequentActionsMenu?.classList.remove(
            "show"
        );

        [
            scheduleModal,
            multipleAssignModal,
            copyDayModal,
            frequentModal,
            scheduleActionsModal
        ].forEach(modal => {

            if (
                modal?.classList.contains(
                    "show"
                )
            ) {
                closeModal(modal);
            }

        });
    }
);
        /* =====================================================
       HORARIOS FRECUENTES
    ===================================================== */

    function updateFrequentJourneyFields() {

        const isSplit =
            frequentJourney?.value === "split";

        if (frequentContinuousFields) {
            frequentContinuousFields.style.display =
                isSplit ? "none" : "";
        }

        if (frequentSplitFields) {
            frequentSplitFields.style.display =
                isSplit ? "" : "none";
        }
    }


    function resetFrequentForm() {

        frequentForm?.reset();

        editingFrequentScheduleId =
            null;

        if (frequentModalTitle) {
            frequentModalTitle.textContent =
                "Nuevo horario frecuente";
        }

        if (frequentSubmitText) {
            frequentSubmitText.textContent =
                "Guardar horario";
        }

        if (frequentJourney) {
            frequentJourney.value =
                "continuous";
        }

        if (frequentTolerance) {
            frequentTolerance.value =
                "10";
        }

        if (frequentStatus) {
            frequentStatus.value =
                "active";
        }

        updateFrequentJourneyFields();
    }


    function openFrequentScheduleModal(
        schedule = null
    ) {

        resetFrequentForm();

        if (schedule) {

            editingFrequentScheduleId =
                schedule.id;

            if (frequentModalTitle) {
                frequentModalTitle.textContent =
                    "Editar horario frecuente";
            }

            if (frequentSubmitText) {
                frequentSubmitText.textContent =
                    "Guardar cambios";
            }

            frequentName.value =
                schedule.name || "";

            frequentJourney.value =
                schedule.journey ||
                "continuous";

            frequentTolerance.value =
                schedule.tolerance ?? 10;

            frequentStatus.value =
                schedule.status ||
                "active";


            if (
                schedule.journey ===
                "split"
            ) {

                frequentEntry1.value =
                    schedule.entry1 || "";

                frequentExit1.value =
                    schedule.exit1 || "";

                frequentEntry2.value =
                    schedule.entry2 || "";

                frequentExit2.value =
                    schedule.exit2 || "";

            } else {

                frequentEntry.value =
                    schedule.entry || "";

                frequentExit.value =
                    schedule.exit || "";
            }

            updateFrequentJourneyFields();
        }

        openModal(frequentModal);
    }


    openFrequentModal?.addEventListener(
        "click",
        () => {

            openFrequentScheduleModal();
        }
    );


    closeFrequentModal?.addEventListener(
        "click",
        () => {

            closeModal(frequentModal);
        }
    );


    cancelFrequentModal?.addEventListener(
        "click",
        () => {

            closeModal(frequentModal);
        }
    );


    frequentJourney?.addEventListener(
        "change",
        () => {

            updateFrequentJourneyFields();
        }
    );


    frequentForm?.addEventListener(
        "submit",
        event => {

            event.preventDefault();

            const name =
                frequentName.value.trim();

            const journey =
                frequentJourney.value;


            if (!name) {

                showMessage(
                    "Ingresa un nombre para el horario."
                );

                return;
            }


            const data = {

                name,

                journey,

                tolerance:
                    Number(
                        frequentTolerance.value ||
                        0
                    ),

                status:
                    frequentStatus.value ||
                    "active"
            };


            if (journey === "split") {

                if (
                    !frequentEntry1.value ||
                    !frequentExit1.value ||
                    !frequentEntry2.value ||
                    !frequentExit2.value
                ) {

                    showMessage(
                        "Completa todos los horarios."
                    );

                    return;
                }


                data.entry1 =
                    frequentEntry1.value;

                data.exit1 =
                    frequentExit1.value;

                data.entry2 =
                    frequentEntry2.value;

                data.exit2 =
                    frequentExit2.value;

                data.entry =
                    "";

                data.exit =
                    "";

            } else {

                if (
                    !frequentEntry.value ||
                    !frequentExit.value
                ) {

                    showMessage(
                        "Completa la hora de entrada y salida."
                    );

                    return;
                }


                data.entry =
                    frequentEntry.value;

                data.exit =
                    frequentExit.value;

                data.entry1 =
                    "";

                data.exit1 =
                    "";

                data.entry2 =
                    "";

                data.exit2 =
                    "";
            }


            if (editingFrequentScheduleId) {

                STORAGE.updateFrequentSchedule(
                    editingFrequentScheduleId,
                    data
                );

            } else {

                STORAGE.addFrequentSchedule(
                    data
                );
            }


            closeModal(frequentModal);

            editingFrequentScheduleId =
                null;

            renderFrequentSchedules();

            loadFrequentScheduleSelects();

            showMessage(
                "Horario frecuente guardado correctamente."
            );
        }
    );


    /* =====================================================
       TABLA HORARIOS FRECUENTES
    ===================================================== */

    function renderFrequentSchedules() {

        if (!frequentTableBody) {
            return;
        }


        const searchValue =
            String(
                frequentSearch?.value || ""
            )
                .trim()
                .toLowerCase();


        const typeValue =
            String(
                frequentTypeFilter?.value || ""
            );


        let schedules =
            STORAGE.getFrequentSchedules();


        schedules =
            schedules.filter(schedule => {

                const name =
                    String(
                        schedule.name || ""
                    ).toLowerCase();


                const matchesSearch =
                    !searchValue ||
                    name.includes(
                        searchValue
                    );


                const matchesType =
                    !typeValue ||
                    schedule.journey ===
                    typeValue;


                return (
                    matchesSearch &&
                    matchesType
                );
            });


        frequentTableBody.innerHTML =
            "";


        if (schedules.length === 0) {

            frequentTableBody.innerHTML = `
                <tr>
                    <td
                        colspan="6"
                        class="schedule-empty"
                    >
                        No se encontraron horarios frecuentes.
                    </td>
                </tr>
            `;

            if (frequentResultText) {
                frequentResultText.textContent =
                    "0 horarios";
            }

            return;
        }


        schedules.forEach(schedule => {

            const row =
                document.createElement(
                    "tr"
                );


            const journeyText =
                schedule.journey === "split"
                    ? "Horario partido"
                    : "Horario continuo";


            const status =
                String(
                    schedule.status ||
                    "active"
                ).toLowerCase();


            const statusText =
                status === "active" ||
                status === "activo"
                    ? "Activo"
                    : "Inactivo";


            row.innerHTML = `
                <td>
                    <strong>
                        ${escapeHTML(schedule.name)}
                    </strong>
                </td>

                <td>
                    ${escapeHTML(journeyText)}
                </td>

                <td>
                    ${escapeHTML(
                        STORAGE.formatScheduleHours(
                            schedule
                        )
                    )}
                </td>

                <td>
                    ${Number(
                        schedule.tolerance || 0
                    )} min
                </td>

                <td>
                    <span
                        class="schedule-status ${
                            status === "active" ||
                            status === "activo"
                                ? "schedule-status-scheduled"
                                : "schedule-status-unassigned"
                        }"
                    >
                        ${escapeHTML(statusText)}
                    </span>
                </td>

                <td>
                    <button
                        type="button"
                        class="frequent-action-button"
                        data-schedule-id="${escapeHTML(schedule.id)}"
                        title="Acciones"
                    >
                        ⋮
                    </button>
                </td>
            `;


            frequentTableBody.appendChild(
                row
            );
        });


        if (frequentResultText) {

            frequentResultText.textContent =
                `${schedules.length} horario${
                    schedules.length === 1
                        ? ""
                        : "s"
                }`;
        }


        document
            .querySelectorAll(
                ".frequent-action-button"
            )
            .forEach(button => {

                button.addEventListener(
                    "click",
                    event => {

                        event.stopPropagation();

                        openFrequentActionsMenu(
                            button.dataset.scheduleId,
                            button
                        );
                    }
                );
            });
    }


    frequentSearch?.addEventListener(
        "input",
        () => {

            renderFrequentSchedules();
        }
    );


    frequentTypeFilter?.addEventListener(
        "change",
        () => {

            renderFrequentSchedules();
        }
    );


    /* =====================================================
       MENÚ HORARIOS FRECUENTES
    ===================================================== */

    function openFrequentActionsMenu(
        scheduleId,
        button
    ) {

        if (!frequentActionsMenu) {
            return;
        }


        activeFrequentMenuId =
            scheduleId;


        const schedule =
            getFrequentScheduleById(
                scheduleId
            );


        if (!schedule) {
            return;
        }


        const status =
            String(
                schedule.status ||
                "active"
            ).toLowerCase();


        const isActive =
            status === "active" ||
            status === "activo";


        frequentActionsMenu.innerHTML = `
            <button
                type="button"
                data-action="edit"
            >
                Editar
            </button>

            <button
                type="button"
                data-action="toggle"
            >
                ${
                    isActive
                        ? "Desactivar"
                        : "Activar"
                }
            </button>

            <button
                type="button"
                data-action="delete"
            >
                Eliminar
            </button>
        `;


        const rect =
            button.getBoundingClientRect();


        frequentActionsMenu.style.top =
            `${rect.bottom + window.scrollY + 4}px`;


        frequentActionsMenu.style.left =
            `${Math.max(
                10,
                rect.right +
                window.scrollX -
                frequentActionsMenu.offsetWidth
            )}px`;


        frequentActionsMenu.classList.add(
            "show"
        );
    }


    frequentActionsMenu?.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    "[data-action]"
                );


            if (!button) {
                return;
            }


            const action =
                button.dataset.action;


            const schedule =
                getFrequentScheduleById(
                    activeFrequentMenuId
                );


            frequentActionsMenu.classList.remove(
                "show"
            );


            if (!schedule) {
                return;
            }


            if (action === "edit") {

                openFrequentScheduleModal(
                    schedule
                );

                return;
            }


            if (action === "toggle") {

                const currentStatus =
                    String(
                        schedule.status ||
                        "active"
                    ).toLowerCase();


                const isActive =
                    currentStatus === "active" ||
                    currentStatus === "activo";


                STORAGE.updateFrequentSchedule(
                    schedule.id,
                    {
                        status:
                            isActive
                                ? "inactive"
                                : "active"
                    }
                );


                renderFrequentSchedules();

                loadFrequentScheduleSelects();

                return;
            }


            if (action === "delete") {

                const confirmed =
                    confirm(
                        `¿Deseas eliminar el horario "${schedule.name}"?`
                    );


                if (!confirmed) {
                    return;
                }


                STORAGE.deleteFrequentSchedule(
                    schedule.id
                );


                renderFrequentSchedules();

                loadFrequentScheduleSelects();

                showMessage(
                    "Horario frecuente eliminado correctamente."
                );
            }
        }
    );


    /* =====================================================
       SIDEBAR MÓVIL
    ===================================================== */

    mobileMenu?.addEventListener(
        "click",
        event => {

            event.stopPropagation();

            sidebar?.classList.toggle(
                "show"
            );
        }
    );


    document.addEventListener(
        "click",
        event => {

            if (!sidebar) {
                return;
            }


            if (
                window.innerWidth <= 900 &&
                sidebar.classList.contains(
                    "show"
                ) &&
                !sidebar.contains(
                    event.target
                ) &&
                !mobileMenu?.contains(
                    event.target
                )
            ) {

                sidebar.classList.remove(
                    "show"
                );
            }
        }
    );


    /* =====================================================
       CERRAR SIDEBAR AL CAMBIAR TAMAÑO
    ===================================================== */

    window.addEventListener(
        "resize",
        () => {

            if (
                window.innerWidth > 900
            ) {

                sidebar?.classList.remove(
                    "show"
                );
            }
        }
    );


    /* =====================================================
       CERRAR SESIÓN
    ===================================================== */

    logoutButton?.addEventListener(
        "click",
        event => {

            event.preventDefault();

            const confirmed =
                confirm(
                    "¿Deseas cerrar sesión?"
                );


            if (!confirmed) {
                return;
            }


            localStorage.removeItem(
                "sigep_session"
            );


            /*
             * Si tu login utiliza otra ruta,
             * cambia "login.html" por la ruta
             * correspondiente.
             */

            window.location.href =
                "login.html";
        }
    );


    /* =====================================================
       REFRESCAR PROGRAMACIÓN DIARIA
    ===================================================== */

    function refreshDailySchedule() {

        selectedWorkerIds =
            [];

        renderSelectedDate();

        renderStats();

        renderScheduleTable();

        loadFrequentScheduleSelects();

        /*
         * Se ejecuta después de crear la tabla
         * para poder bloquear checkboxes y
         * acciones cuando sea una fecha pasada.
         */

        updatePastDateMode();
        updateFinalizeButton();
    }


    /* =====================================================
       FLUJO RÁPIDO: FILTROS, FINALIZAR Y COMPARTIR
    ===================================================== */
    document.querySelectorAll(".schedule-stat[data-stat-filter]").forEach(card => {
        card.setAttribute("role", "button");
        card.setAttribute("tabindex", "0");
        const apply = () => {
            if (!scheduleStatusFilter) return;
            scheduleStatusFilter.value = card.dataset.statFilter || "";
            renderScheduleTable();
            document.querySelectorAll(".schedule-stat").forEach(c => c.classList.remove("stat-active"));
            card.classList.add("stat-active");
        };
        card.addEventListener("click", apply);
        card.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") apply(); });
    });

    function updateFinalizeButton() {
        // La programación se guarda automáticamente; no requiere cierre manual.
    }

    function getScheduleStartMinutes(schedule) {
        const raw = schedule?.journey === "Completo" ? schedule.entry1 : schedule?.entry;
        if (!raw || !/^\d{2}:\d{2}$/.test(raw)) return 24 * 60;
        const [h, m] = raw.split(":").map(Number);
        return h * 60 + m;
    }

    function formatShareTime(value) {
        if (!value || !/^\d{2}:\d{2}$/.test(value)) return "—";
        let [hour, minute] = value.split(":").map(Number);
        const suffix = hour < 12 ? "am" : "pm";
        hour = hour % 12 || 12;
        return minute ? `${hour}:${String(minute).padStart(2, "0")}${suffix}` : `${hour}${suffix}`;
    }

    function formatShareHours(schedule) {
        if (!schedule) return "—";
        if (schedule.journey === "Completo") {
            const first = schedule.entry1 && schedule.exit1 ? `${formatShareTime(schedule.entry1)} a ${formatShareTime(schedule.exit1)}` : "";
            const second = schedule.entry2 && schedule.exit2 ? `${formatShareTime(schedule.entry2)} a ${formatShareTime(schedule.exit2)}` : "";
            return [first, second].filter(Boolean).join(" / ") || "—";
        }
        return schedule.entry && schedule.exit
            ? `${formatShareTime(schedule.entry)} a ${formatShareTime(schedule.exit)}`
            : "—";
    }

    function getShareRows() {
        return STORAGE.getActiveWorkers().map(worker => ({
            worker,
            schedule: STORAGE.getWorkerScheduleByDate(worker.id, selectedDate)
        })).filter(x => x.schedule && x.schedule.journey !== "Libre" && !x.schedule.replacementWorkerId)
          .sort((a, b) => getScheduleStartMinutes(a.schedule) - getScheduleStartMinutes(b.schedule) || getWorkerName(a.worker).localeCompare(getWorkerName(b.worker), "es"));
    }

    function buildShareText(rows) {
        const title = `HORARIOS · ${formatLongDate(selectedDate).toUpperCase()}`;
        const lines = rows.map(({worker, schedule}) => `• ${getWorkerName(worker)} — ${formatShareHours(schedule)}${schedule.isReplacement ? " (reemplazo)" : ""}`);
        return [title, "", ...lines, "", "SIGEP · Programación de personal"].join("\n");
    }

    function makeScheduleImage(rows) {
        const width = 1080, pad = 70, rowH = 74;
        const height = 250 + rows.length * rowH;
        const canvas = document.createElement("canvas"); canvas.width = width; canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.fillStyle = "#ffffff"; ctx.fillRect(0,0,width,height);
        ctx.fillStyle = "#111827"; ctx.font = "700 42px Inter, Arial"; ctx.fillText("Programación de personal", pad, 78);
        ctx.fillStyle = "#6b7280"; ctx.font = "500 25px Inter, Arial"; ctx.fillText(capitalize(formatLongDate(selectedDate)), pad, 120);
        ctx.strokeStyle = "#e5e7eb"; ctx.beginPath(); ctx.moveTo(pad,150); ctx.lineTo(width-pad,150); ctx.stroke();
        rows.forEach(({worker, schedule}, i) => {
            const y = 205 + i*rowH;
            ctx.fillStyle = "#111827"; ctx.font = "600 26px Inter, Arial"; ctx.fillText(getWorkerName(worker), pad, y);
            ctx.fillStyle = "#374151"; ctx.font = "500 24px Inter, Arial"; ctx.textAlign = "right"; ctx.fillText(formatShareHours(schedule), width-pad, y); ctx.textAlign = "left";
        });
        ctx.fillStyle = "#9ca3af"; ctx.font = "500 20px Inter, Arial"; ctx.fillText("SIGEP · Gestión de Personal", pad, height-45);
        return canvas;
    }

    shareScheduleButton?.addEventListener("click", async () => {
        const rows = getShareRows();
        if (!rows.length) { showMessage("Primero programa al menos a un trabajador."); return; }
        const text = buildShareText(rows);
        const canvas = makeScheduleImage(rows);
        const blob = await new Promise(resolve => canvas.toBlob(resolve, "image/png"));
        const file = blob ? new File([blob], `horarios-${selectedDate}.png`, {type:"image/png"}) : null;
        try {
            if (file && navigator.share && navigator.canShare?.({files:[file]})) {
                await navigator.share({title:"Programación SIGEP", text, files:[file]});
                return;
            }
            if (navigator.share) { await navigator.share({title:"Programación SIGEP", text}); return; }
        } catch (e) { if (e?.name === "AbortError") return; }
        try { await navigator.clipboard.writeText(text); } catch {}
        const a = document.createElement("a"); a.download = `horarios-${selectedDate}.png`; a.href = canvas.toDataURL("image/png"); a.click();
        showMessage("Se descargó la programación como imagen y se copió el texto para compartirlo.");
    });

    /* =====================================================
       INICIALIZACIÓN
    ===================================================== */

    function initialize() {
        // Inicializa primero la vista esencial. Así Turnos siempre muestra
        // fecha y trabajadores aunque una función secundaria falle.
        selectedDate = getTodayISO();
        renderTopDate();
        renderSelectedDate();

        try { loadPositionFilter(); } catch (error) { console.error("Filtro de cargos:", error); }
        try { refreshSplit12h(); } catch (error) { console.error("Selector 12h:", error); }
        try { updateSingleJourneyFields(); } catch (error) { console.error("Formulario individual:", error); }
        try { updateMultipleJourneyFields(); } catch (error) { console.error("Formulario múltiple:", error); }
        try { loadFrequentScheduleSelects(); } catch (error) { console.error("Horarios rápidos:", error); }

        // Núcleo del módulo: contadores + tabla + fecha.
        try {
            refreshDailySchedule();
        } catch (error) {
            console.error("No se pudo refrescar Turnos:", error);
            // Fallback para no dejar la pantalla vacía.
            renderSelectedDate();
            try { renderStats(); } catch (e) { console.error(e); }
            try { renderScheduleTable(); } catch (e) { console.error(e); }
        }

        // Funciones heredadas/auxiliares nunca deben bloquear Turnos.
        try { updateFrequentJourneyFields(); } catch (error) { console.error(error); }
        try { renderFrequentSchedules(); } catch (error) { console.error(error); }
    }


    initialize();

    /* Vista amigable de horas: mantiene input time internamente y muestra a. m./p. m. */
    document.querySelectorAll('input[type="time"]').forEach(input => {
        const preview = document.createElement("small");
        preview.className = "time-ampm-preview";
        input.insertAdjacentElement("afterend", preview);
        const updatePreview = () => {
            preview.textContent = input.value ? `Hora seleccionada: ${formatTime12h(input.value)}` : "";
        };
        input.addEventListener("input", updatePreview);
        input.addEventListener("change", updatePreview);
        updatePreview();
    });

});