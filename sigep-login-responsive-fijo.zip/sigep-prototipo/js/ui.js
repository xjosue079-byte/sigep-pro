
window.SIGEP_CONFIRM = function({title="Confirmar acción", message="¿Deseas continuar?", name="", confirmText="Confirmar", danger=true}={}){
 return new Promise(resolve=>{
  const overlay=document.createElement("div"); overlay.className="sigep-confirm-overlay";
  overlay.innerHTML=`<div class="sigep-confirm-card" role="dialog" aria-modal="true"><div class="sigep-confirm-icon ${danger?'':'safe'}"><i class="fa-solid ${danger?'fa-triangle-exclamation':'fa-circle-question'}"></i></div><h3>${title}</h3><p>${message}</p>${name?`<span class="sigep-confirm-name">${name}</span>`:''}<div class="sigep-confirm-actions"><button class="sigep-confirm-cancel" type="button">Cancelar</button><button class="sigep-confirm-ok ${danger?'':'safe'}" type="button">${confirmText}</button></div></div>`;
  document.body.appendChild(overlay);
  const done=v=>{overlay.remove();resolve(v)}; overlay.querySelector('.sigep-confirm-cancel').onclick=()=>done(false); overlay.querySelector('.sigep-confirm-ok').onclick=()=>done(true); overlay.onclick=e=>{if(e.target===overlay)done(false)};
 });
};
document.addEventListener("DOMContentLoaded", () => {
    const STORAGE = window.SIGEP_STORAGE;
    const settings = (() => { try { return JSON.parse(localStorage.getItem("sigep_system_settings") || "{}"); } catch { return {}; } })();
    const adminName = String(settings.adminName || "Henry").trim() || "Henry";
    const initials = adminName.split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]?.toUpperCase()).join("") || "AD";
    const systemName = String(settings.systemName || "SIGEP").trim() || "SIGEP";
    document.querySelectorAll(".sidebar-logo-text h1").forEach(el => el.textContent = systemName);

    document.querySelectorAll(".admin-info strong").forEach(el => el.textContent = adminName);
    document.querySelectorAll(".admin-avatar,.top-user-avatar").forEach(el => el.textContent = initials);
    document.querySelectorAll(".top-user strong").forEach(el => el.textContent = adminName);
    document.querySelectorAll(".top-user span").forEach(el => el.textContent = "Administrador");

    const buttons = [...document.querySelectorAll(".notification-button")];
    if (!buttons.length) return;

    const todayISO = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; };
    const mins = t => { if(!t || !String(t).includes(":")) return null; const [h,m]=String(t).split(":").map(Number); return h*60+m; };
    const scheduleEntry = s => s?.journey === "Completo" ? s.entry1 : s?.entry;
    const scheduleExit = s => s?.journey === "Completo" ? (s.exit2 || s.exit1) : s?.exit;

    function getNotifications(){
        if(!STORAGE) return [];
        const today=todayISO(), now=new Date(), current=now.getHours()*60+now.getMinutes();
        const schedules=(STORAGE.getSchedulesByDate?.(today)||[]).filter(s=>s.journey!=="Libre" && !s.replacementWorkerId);
        let late=0, absent=0, pending=0;
        schedules.forEach(s=>{
            const wid=Number(s.workerId), marks=STORAGE.getWorkerBiometricMarks?.(wid,today)||[];
            const entry=marks.find(m=>m.type==="Entrada")?.time;
            let status="Pendiente";
            if(entry && scheduleEntry(s)) status=mins(entry)<=mins(scheduleEntry(s))+(Number(s.tolerance)||0)?"Presente":"Tardanza";
            else if(!entry && scheduleExit(s) && current>mins(scheduleExit(s))) status="Falta";
            const reg=STORAGE.getAttendanceRegularization?.(wid,today); if(reg?.status) status=reg.status;
            if(status==="Tardanza") late++; else if(status==="Falta") absent++; else if(status==="Pendiente") pending++;
        });
        const out=[];
        if(late) out.push({icon:"fa-regular fa-clock",kind:"warning",title:`${late} ${late===1?"tardanza":"tardanzas"} hoy`,text:"Revisa los ingresos fuera de tolerancia.",href:"asistencia.html"});
        if(absent) out.push({icon:"fa-solid fa-user-xmark",kind:"danger",title:`${absent} ${absent===1?"falta":"faltas"} registrada${absent===1?"":"s"}`,text:"Hay personal sin marcación de entrada.",href:"asistencia.html"});
        if(pending) out.push({icon:"fa-regular fa-hourglass-half",kind:"info",title:`${pending} ${pending===1?"marcación pendiente":"marcaciones pendientes"}`,text:"Jornadas en curso pendientes de entrada.",href:"asistencia.html"});

        return out;
    }

    const panel=document.createElement("div"); panel.className="notification-panel"; panel.setAttribute("aria-hidden","true"); document.body.appendChild(panel);
    function render(){
        const notes=getNotifications();
        document.querySelectorAll(".notification-dot").forEach(dot=>{ dot.style.display=notes.length?"block":"none"; dot.textContent=""; });
        panel.innerHTML=`<div class="notification-panel-head"><div><strong>Notificaciones</strong><span>${notes.length?`${notes.length} pendiente${notes.length===1?"":"s"}`:"Todo al día"}</span></div><button type="button" class="notification-close" aria-label="Cerrar"><i class="fa-solid fa-xmark"></i></button></div><div class="notification-panel-body">${notes.length?notes.map(n=>`<button class="notification-item ${n.kind}" type="button" data-notification-go data-href="${n.href||"asistencia.html"}"><span class="notification-item-icon"><i class="${n.icon}"></i></span><span><strong>${n.title}</strong><small>${n.text}</small></span><i class="fa-solid fa-chevron-right"></i></button>`).join(""):`<div class="notification-empty"><i class="fa-regular fa-circle-check"></i><strong>Sin novedades</strong><span>No tienes alertas de asistencia por ahora.</span></div>`}</div><a class="notification-footer" href="asistencia.html">Ver control de asistencia <i class="fa-solid fa-arrow-right"></i></a>`;
        panel.querySelector(".notification-close")?.addEventListener("click",close);
        panel.querySelectorAll("[data-notification-go]").forEach(b=>b.addEventListener("click",()=>location.href=b.dataset.href||"asistencia.html"));
    }
    function open(btn){ render(); const r=btn.getBoundingClientRect(); panel.style.top=`${Math.min(r.bottom+10,innerHeight-420)}px`; panel.style.right=`${Math.max(16,innerWidth-r.right)}px`; panel.classList.add("show"); panel.setAttribute("aria-hidden","false"); }
    function close(){ panel.classList.remove("show"); panel.setAttribute("aria-hidden","true"); }
    buttons.forEach(btn=>btn.addEventListener("click",e=>{e.stopPropagation(); panel.classList.contains("show")?close():open(btn);}));
    document.addEventListener("click",e=>{if(!panel.contains(e.target)) close();});
    document.addEventListener("keydown",e=>{if(e.key==="Escape") close();});
    render();
});
