document.addEventListener("DOMContentLoaded", () => {
  const KEY = "sigep_system_settings";
  const PASSWORD_KEY = "sigep_admin_password";
  const defaults = {adminName:"Henry",companyName:"",companyRuc:"",companyPhone:"",companyAddress:"",defaultTolerance:15,systemName:"SIGEP"};
  const $ = id => document.getElementById(id);
  const fields = ["adminName","companyName","companyRuc","companyPhone","companyAddress","defaultTolerance","systemName"];
  const message = $("settingsMessage");

  function getSettings(){try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||"{}")};}catch{return {...defaults};}}
  function fill(){const data=getSettings();fields.forEach(id=>{if($(id)) $(id).value=data[id] ?? "";});}
  function notify(text,type="success"){message.textContent=text;message.className=`settings-message show ${type}`;clearTimeout(notify.timer);notify.timer=setTimeout(()=>message.className="settings-message",3500);}
  function validRuc(value){return !value || /^\d{11}$/.test(value);}
  function validPhone(value){return !value || /^[0-9+()\s-]{7,20}$/.test(value);}
  function initials(name){return name.split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]?.toUpperCase()).join("")||"AD";}
  function applyIdentity(data){
    const admin=String(data.adminName||"Henry").trim()||"Henry";
    const system=String(data.systemName||"SIGEP").trim()||"SIGEP";
    document.querySelectorAll(".admin-info strong,.top-user strong").forEach(el=>el.textContent=admin);
    document.querySelectorAll(".admin-avatar,.top-user-avatar").forEach(el=>el.textContent=initials(admin));
    document.querySelectorAll(".sidebar-logo-text h1").forEach(el=>el.textContent=system);
    document.title=`${system} | Configuración`;
  }

  $("saveSettings")?.addEventListener("click",()=>{
    const ruc=$("companyRuc").value.trim(), phone=$("companyPhone").value.trim();
    const tolerance=Number($("defaultTolerance").value);
    if(!$("adminName").value.trim()){notify("Ingresa el nombre del administrador.","error");$("adminName").focus();return;}
    if(!$("systemName").value.trim()){notify("Ingresa el nombre del sistema.","error");$("systemName").focus();return;}
    if(!validRuc(ruc)){notify("El RUC debe contener exactamente 11 dígitos.","error");$("companyRuc").focus();return;}
    if(!validPhone(phone)){notify("Ingresa un teléfono válido.","error");$("companyPhone").focus();return;}
    if(!Number.isFinite(tolerance)||tolerance<0||tolerance>120){notify("La tolerancia debe estar entre 0 y 120 minutos.","error");$("defaultTolerance").focus();return;}
    const data={}; fields.forEach(id=>data[id]=$(id).value.trim()); data.defaultTolerance=tolerance;
    localStorage.setItem(KEY,JSON.stringify(data)); applyIdentity(data); notify("Configuración guardada correctamente.");
  });

  $("changePassword")?.addEventListener("click",()=>{
    const current=$("currentPassword").value, next=$("newPassword").value, confirm=$("confirmPassword").value;
    const stored=localStorage.getItem(PASSWORD_KEY)||"admin123";
    if(!current||!next||!confirm){notify("Completa los tres campos de contraseña.","error");return;}
    if(current!==stored){notify("La contraseña actual es incorrecta.","error");$("currentPassword").focus();return;}
    if(next.length<8){notify("La nueva contraseña debe tener al menos 8 caracteres.","error");$("newPassword").focus();return;}
    if(next!==confirm){notify("Las nuevas contraseñas no coinciden.","error");$("confirmPassword").focus();return;}
    if(next===current){notify("La nueva contraseña debe ser diferente a la actual.","error");return;}
    localStorage.setItem(PASSWORD_KEY,next);
    ["currentPassword","newPassword","confirmPassword"].forEach(id=>$(id).value="");
    notify("Contraseña actualizada correctamente.");
  });

  const modal=$("resetConfirmModal");
  function closeReset(){modal?.classList.remove("show");modal?.setAttribute("aria-hidden","true");}
  $("resetSettings")?.addEventListener("click",()=>{modal?.classList.add("show");modal?.setAttribute("aria-hidden","false");});
  $("cancelReset")?.addEventListener("click",closeReset);
  $("closeReset")?.addEventListener("click",closeReset);
  $("confirmReset")?.addEventListener("click",()=>{localStorage.setItem(KEY,JSON.stringify(defaults));fill();applyIdentity(defaults);closeReset();notify("Configuración restaurada.");});
  modal?.addEventListener("click",e=>{if(e.target===modal)closeReset();});
  document.addEventListener("keydown",e=>{if(e.key==="Escape")closeReset();});

  document.querySelectorAll("[data-toggle-password]").forEach(btn=>btn.addEventListener("click",()=>{
    const input=$(btn.dataset.togglePassword); if(!input)return;
    const show=input.type==="password"; input.type=show?"text":"password";
    const icon=btn.querySelector("i"); icon?.classList.toggle("fa-eye",!show); icon?.classList.toggle("fa-eye-slash",show);
  }));
  $("mobileMenu")?.addEventListener("click",()=>$("sidebar")?.classList.toggle("active"));
  $("logoutButton")?.addEventListener("click",()=>{window.location.href="../index.html";});
  const dateEl=$("dashboardDate"); if(dateEl)dateEl.textContent=new Intl.DateTimeFormat("es-PE",{weekday:"long",day:"2-digit",month:"long",year:"numeric"}).format(new Date());
  fill(); applyIdentity(getSettings());
});
