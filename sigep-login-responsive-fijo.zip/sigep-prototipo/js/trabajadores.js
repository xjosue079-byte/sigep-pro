/* =========================================================
   SIGEP - MÓDULO TRABAJADORES
   Conectado con Cargos mediante positionId
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       SESIÓN
    ===================================================== */

    const session =
        localStorage.getItem("sigep_session") ||
        sessionStorage.getItem("sigep_session");

    if (!session) {
        window.location.href = "../index.html";
        return;
    }


    /* =====================================================
       ELEMENTOS GENERALES
    ===================================================== */

    const sidebar =
        document.getElementById("sidebar");

    const mobileMenu =
        document.getElementById("mobileMenu");

    const logoutButton =
        document.getElementById("logoutButton");

    const dashboardDate =
        document.getElementById("dashboardDate");


    /* =====================================================
       TABLA / FILTROS
    ===================================================== */

    const tableBody =
        document.getElementById("workersTableBody");

    const searchInput =
        document.getElementById("workerSearch");

    const positionFilter =
        document.getElementById("positionFilter");

    const statusFilter =
        document.getElementById("statusFilter");

    const resultText =
        document.getElementById("workersResultText");


    /* =====================================================
       INDICADORES
    ===================================================== */

    const totalWorkers =
        document.getElementById("totalWorkers");

    const activeWorkers =
        document.getElementById("activeWorkers");

    const inactiveWorkers =
        document.getElementById("inactiveWorkers");

    const biometricWorkers =
        document.getElementById("biometricWorkers");


    /* =====================================================
       MODAL
    ===================================================== */

    const modal =
        document.getElementById("workerModal");

    const openModalButton =
        document.getElementById("openWorkerModal");

    const closeModalButton =
        document.getElementById("closeWorkerModal");

    const cancelModalButton =
        document.getElementById("cancelWorkerModal");

    const workerForm =
        document.getElementById("workerForm");

    const modalTitle =
        document.getElementById("workerModalTitle");

    const submitText =
        document.getElementById("workerSubmitText");


    /* =====================================================
       CAMPOS
    ===================================================== */

    const namesInput =
        document.getElementById("workerNames");

    const lastNamesInput =
        document.getElementById("workerLastNames");

    const dniInput =
        document.getElementById("workerDni");

    const positionInput =
        document.getElementById("workerPosition");

    const startDateInput =
        document.getElementById("workerStartDate");

    const statusInput =
        document.getElementById("workerStatus");

    const biometricInput =
        document.getElementById("workerBiometric");


    /* =====================================================
       MENÚ DE ACCIONES
    ===================================================== */

    const actionsMenu =
        document.getElementById("workerActionsMenu");

    const actionsOverlay = document.getElementById("workerActionsOverlay");
    const closeWorkerActions = document.getElementById("closeWorkerActions");
    const workerActionsName = document.getElementById("workerActionsName");
    const workerActionsMeta = document.getElementById("workerActionsMeta");
    const workerActionsAvatar = document.getElementById("workerActionsAvatar");
    const workerActionsStatus = document.getElementById("workerActionsStatus");

    const workerDetailModal = document.getElementById("workerDetailModal");
    const closeWorkerDetail = document.getElementById("closeWorkerDetail");
    const detailCloseButton = document.getElementById("detailCloseButton");
    const detailEditButton = document.getElementById("detailEditButton");

    const workerDeleteModal = document.getElementById("workerDeleteModal");
    const workerDeleteMessage = document.getElementById("workerDeleteMessage");
    const cancelWorkerDelete = document.getElementById("cancelWorkerDelete");
    const confirmWorkerDelete = document.getElementById("confirmWorkerDelete");


    /* =====================================================
       DATOS
    ===================================================== */

    let workers =
        SIGEP_STORAGE.getWorkers();

    let positions =
        SIGEP_STORAGE.getPositions();

    {
        const seenPositionNames = new Set();
        positions = positions.filter(position => {
            const normalizedName = SIGEP_STORAGE.normalizeText(position?.name || "");
            if (!normalizedName || seenPositionNames.has(normalizedName)) return false;
            seenPositionNames.add(normalizedName);
            return true;
        });
    }

    let editingWorkerId = null;

    let selectedWorkerId = null;


    /* =====================================================
       FECHA SUPERIOR
    ===================================================== */

    if (dashboardDate) {

        const formatted =
            new Intl.DateTimeFormat(
                "es-PE",
                {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                    year: "numeric"
                }
            ).format(new Date());


        dashboardDate.textContent =
            formatted.charAt(0).toUpperCase() +
            formatted.slice(1);
    }


    /* =====================================================
       ACTUALIZAR DATOS
    ===================================================== */

    function refreshData() {

        workers =
            SIGEP_STORAGE.getWorkers();

        positions =
            SIGEP_STORAGE.getPositions();

        /* Evita cargos duplicados por nombre en selects y filtros.
           Conserva el primer registro para no romper IDs existentes. */
        const seenPositionNames = new Set();
        positions = positions.filter(position => {
            const normalizedName = SIGEP_STORAGE.normalizeText(position?.name || "");
            if (!normalizedName || seenPositionNames.has(normalizedName)) {
                return false;
            }
            seenPositionNames.add(normalizedName);
            return true;
        });

    }


    /* =====================================================
       CARGAR FILTRO DE CARGOS
    ===================================================== */

    function loadPositionFilter() {

        const currentValue =
            positionFilter.value;


        positionFilter.innerHTML = `
            <option value="">
                Todos los cargos
            </option>
        `;


        positions.forEach(position => {

            const option =
                document.createElement("option");


            option.value =
                String(position.id);


            option.textContent =
                position.name;


            positionFilter.appendChild(
                option
            );

        });


        const exists =
            [...positionFilter.options]
                .some(
                    option =>
                        option.value ===
                        currentValue
                );


        if (exists) {

            positionFilter.value =
                currentValue;

        }

    }


    /* =====================================================
       CARGAR CARGOS EN FORMULARIO
    ===================================================== */

    function loadPositionSelect(
        currentPositionId = null
    ) {

        positionInput.innerHTML = `
            <option value="">
                Seleccionar cargo
            </option>
        `;


        positions
            .filter(position => {

                /*
                 * Para nuevo trabajador:
                 * solo cargos activos.
                 *
                 * Para editar:
                 * mostramos también su cargo actual,
                 * aunque esté inactivo.
                 */

                return (
                    position.status === "Activo" ||

                    Number(position.id) ===
                    Number(currentPositionId)
                );

            })
            .forEach(position => {

                const option =
                    document.createElement("option");


                option.value =
                    String(position.id);


                if (
                    position.status ===
                    "Activo"
                ) {

                    option.textContent =
                        position.name;

                } else {

                    option.textContent =
                        `${position.name} (Inactivo)`;

                }


                positionInput.appendChild(
                    option
                );

            });


        if (
            currentPositionId !== null
        ) {

            positionInput.value =
                String(currentPositionId);

        }

    }


    /* =====================================================
       OBTENER NOMBRE DEL CARGO
    ===================================================== */

    function getPositionName(positionId) {

        const position =
            positions.find(
                item =>
                    Number(item.id) ===
                    Number(positionId)
            );


        return position
            ? position.name
            : "Sin cargo";

    }


    /* =====================================================
       RENDER PRINCIPAL
    ===================================================== */

    function renderWorkers() {

        refreshData();

        loadPositionFilter();


        const search =
            SIGEP_STORAGE.normalizeText(
                searchInput.value
            );


        const selectedPosition =
            positionFilter.value;


        const selectedStatus =
            statusFilter.value;


        const filteredWorkers =
            workers.filter(worker => {

                const fullName =
                    SIGEP_STORAGE.normalizeText(
                        `${worker.names} ${worker.lastNames}`
                    );


                const positionName =
                    SIGEP_STORAGE.normalizeText(
                        getPositionName(
                            worker.positionId
                        )
                    );


                const matchesSearch =

                    fullName.includes(search)

                    ||

                    String(
                        worker.dni || ""
                    ).includes(search)

                    ||

                    SIGEP_STORAGE
                        .normalizeText(
                            worker.code
                        )
                        .includes(search)

                    ||

                    positionName.includes(
                        search
                    );


                const matchesPosition =

                    !selectedPosition

                    ||

                    Number(
                        worker.positionId
                    ) ===
                    Number(
                        selectedPosition
                    );


                const matchesStatus =

                    !selectedStatus

                    ||

                    worker.status ===
                    selectedStatus;


                return (
                    matchesSearch &&
                    matchesPosition &&
                    matchesStatus
                );

            });


        tableBody.innerHTML = "";


        /* =================================================
           SIN RESULTADOS
        ================================================= */

        if (
            filteredWorkers.length === 0
        ) {

            tableBody.innerHTML = `

                <tr>

                    <td
                        colspan="7"
                        style="
                            text-align:center;
                            padding:45px;
                            color:#98a2b3;
                        "
                    >

                        <i
                            class="fa-solid fa-users"
                            style="
                                display:block;
                                margin-bottom:10px;
                                font-size:22px;
                            "
                        ></i>

                        No se encontraron trabajadores.

                    </td>

                </tr>

            `;

        }


        /* =================================================
           MOSTRAR TRABAJADORES
        ================================================= */

        else {

            filteredWorkers.forEach(worker => {

                const row =
                    document.createElement("tr");


                const initials =
                    getInitials(
                        worker.names,
                        worker.lastNames
                    );


                const biometricId =
                    worker.biometricId || "";


                const biometricHTML =
                    biometricId

                        ? `

                            <span class="biometric-badge">

                                <i class="fa-solid fa-fingerprint"></i>

                                ${escapeHTML(
                                    biometricId
                                )}

                            </span>

                        `

                        : `

                            <span class="biometric-empty">
                                Sin asignar
                            </span>

                        `;


                const statusClass =
                    worker.status === "Activo"
                        ? "active"
                        : "inactive";


                row.innerHTML = `

                    <td>

                        <div class="worker-person">

                            <div class="worker-avatar">
                                ${initials}
                            </div>


                            <div>

                                <strong>

                                    ${escapeHTML(worker.names)}
                                    ${escapeHTML(worker.lastNames)}

                                </strong>



                            </div>

                        </div>

                    </td>


                    <td>

                        <span class="worker-code">

                            ${escapeHTML(worker.code)}

                        </span>

                    </td>


                    <td>

                        ${escapeHTML(worker.dni || "Sin registrar")}

                    </td>


                    <td>

                        ${escapeHTML(
                            getPositionName(
                                worker.positionId
                            )
                        )}

                    </td>


                    <td>

                        ${biometricHTML}

                    </td>


                    <td>

                        <span
                            class="
                                worker-status
                                ${statusClass}
                            "
                        >

                            ${escapeHTML(
                                worker.status === "Activo" ? "Activo" : "Dado de baja"
                            )}

                        </span>

                    </td>


                    <td>

                        <button
                            type="button"
                            class="worker-actions-button"
                            data-worker-id="${worker.id}"
                            title="Acciones"
                        >

                            <i class="fa-solid fa-ellipsis-vertical"></i>

                        </button>

                    </td>

                `;


                tableBody.appendChild(
                    row
                );

            });

        }


        /* =================================================
           TEXTO INFERIOR
        ================================================= */

        resultText.textContent =
            `Mostrando ${filteredWorkers.length} de ${workers.length} trabajadores`;


        updateStats();

    }


    /* =====================================================
       INDICADORES
    ===================================================== */

    function updateStats() {

        totalWorkers.textContent =
            workers.length;


        activeWorkers.textContent =
            workers.filter(
                worker =>
                    worker.status ===
                    "Activo"
            ).length;


        inactiveWorkers.textContent =
            workers.filter(
                worker =>
                    worker.status ===
                    "Inactivo"
            ).length;


        biometricWorkers.textContent =
            workers.filter(
                worker =>
                    String(
                        worker.biometricId || ""
                    ).trim() !== ""
            ).length;

    }


    /* =====================================================
       FILTROS
    ===================================================== */

    searchInput.addEventListener(
        "input",
        renderWorkers
    );


    positionFilter.addEventListener(
        "change",
        renderWorkers
    );


    statusFilter.addEventListener(
        "change",
        renderWorkers
    );


    /* =====================================================
       NUEVO TRABAJADOR
    ===================================================== */

    openModalButton.addEventListener(
        "click",
        () => {

            refreshData();


            editingWorkerId =
                null;


            workerForm.reset();


            clearFormErrors();


            loadPositionSelect();


            statusInput.value =
                "Activo";


            startDateInput.value =
                getTodayISO();


            modalTitle.textContent =
                "Nuevo trabajador";


            submitText.textContent =
                "Guardar trabajador";


            openModal();


            setTimeout(
                () => namesInput.focus(),
                100
            );

        }
    );


    /* =====================================================
       GUARDAR TRABAJADOR
    ===================================================== */

    workerForm.addEventListener(
        "submit",
        event => {

            event.preventDefault();


            refreshData();


            clearFormErrors();


            if (!validateWorkerForm()) {
                return;
            }


            const workerData = {

                names:
                    namesInput.value.trim(),

                lastNames:
                    lastNamesInput.value.trim(),

                dni:
                    dniInput.value.trim(),

                positionId:
                    Number(
                        positionInput.value
                    ),

                entryDate:
                    startDateInput.value,

                status:
                    statusInput.value,

                biometricId:
                    biometricInput
                        .value
                        .trim()
                        .toUpperCase()

            };


            /* =================================================
               NUEVO
            ================================================= */

            if (
                editingWorkerId === null
            ) {

                const newWorker = {

                    id:
                        SIGEP_STORAGE
                            .generateWorkerId(
                                workers
                            ),

                    code:
                        SIGEP_STORAGE
                            .generateWorkerCode(
                                workers
                            ),

                    ...workerData

                };


                workers.push(
                    newWorker
                );

            }


            /* =================================================
               EDITAR
            ================================================= */

            else {

                const worker =
                    workers.find(
                        worker =>
                            Number(worker.id) ===
                            Number(editingWorkerId)
                    );


                if (!worker) {

                    alert(
                        "No se pudo encontrar el trabajador."
                    );

                    return;

                }


                worker.names =
                    workerData.names;


                worker.lastNames =
                    workerData.lastNames;


                worker.dni =
                    workerData.dni;


                worker.positionId =
                    workerData.positionId;


                worker.entryDate =
                    workerData.entryDate;


                worker.status =
                    workerData.status;


                worker.biometricId =
                    workerData.biometricId;

            }


            /* =================================================
               GUARDAR
            ================================================= */

            SIGEP_STORAGE.saveWorkers(
                workers
            );


            closeModal();


            renderWorkers();

        }
    );


    /* =====================================================
       VALIDACIONES
    ===================================================== */

    function validateWorkerForm() {

        let valid = true;


        /* =================================================
           NOMBRES
        ================================================= */

        const names =
            namesInput.value.trim();


        if (!names) {

            setError(
                namesInput,
                "Ingresa los nombres."
            );

            valid = false;

        } else if (
            names.length < 2
        ) {

            setError(
                namesInput,
                "Ingresa un nombre válido."
            );

            valid = false;

        }


        /* =================================================
           APELLIDOS
        ================================================= */

        const lastNames =
            lastNamesInput.value.trim();


        if (!lastNames) {

            setError(
                lastNamesInput,
                "Ingresa los apellidos."
            );

            valid = false;

        } else if (
            lastNames.length < 2
        ) {

            setError(
                lastNamesInput,
                "Ingresa apellidos válidos."
            );

            valid = false;

        }


        /* =================================================
           DNI
        ================================================= */

        const dni =
            dniInput.value.trim();


        if (!dni) {

            setError(
                dniInput,
                "Ingresa el DNI."
            );

            valid = false;

        }

        else if (
            !/^\d{8}$/.test(dni)
        ) {

            setError(
                dniInput,
                "El DNI debe contener 8 dígitos."
            );

            valid = false;

        }

        else {

            const duplicateDni =
                workers.some(worker =>

                    worker.dni === dni

                    &&

                    Number(worker.id) !==
                    Number(editingWorkerId)

                );


            if (duplicateDni) {

                setError(
                    dniInput,
                    "Ya existe un trabajador con este DNI."
                );

                valid = false;

            }

        }


        /* =================================================
           CARGO
        ================================================= */

        if (!positionInput.value) {

            setError(
                positionInput,
                "Selecciona un cargo."
            );

            valid = false;

        }

        else {

            const selectedPosition =
                positions.find(
                    position =>
                        Number(position.id) ===
                        Number(
                            positionInput.value
                        )
                );


            if (!selectedPosition) {

                setError(
                    positionInput,
                    "El cargo seleccionado no existe."
                );

                valid = false;

            }

            else if (
                selectedPosition.status !==
                "Activo"
            ) {

                /*
                 * Si estamos editando,
                 * permitimos conservar su
                 * cargo inactivo actual.
                 */

                const editingWorker =
                    workers.find(
                        worker =>
                            Number(worker.id) ===
                            Number(editingWorkerId)
                    );


                const isCurrentPosition =

                    editingWorker

                    &&

                    Number(
                        editingWorker.positionId
                    ) ===
                    Number(
                        selectedPosition.id
                    );


                if (!isCurrentPosition) {

                    setError(
                        positionInput,
                        "Este cargo está inactivo."
                    );

                    valid = false;

                }

            }

        }


        /* =================================================
           FECHA
        ================================================= */

        if (!startDateInput.value) {

            setError(
                startDateInput,
                "Selecciona la fecha de ingreso."
            );

            valid = false;

        }


        /* =================================================
           BIOMÉTRICO
        ================================================= */

        const biometricId =
            biometricInput
                .value
                .trim()
                .toUpperCase();


        if (biometricId) {

            const duplicateBiometric =
                workers.some(worker =>

                    String(
                        worker.biometricId || ""
                    )
                        .trim()
                        .toUpperCase() ===
                    biometricId

                    &&

                    Number(worker.id) !==
                    Number(editingWorkerId)

                );


            if (duplicateBiometric) {

                setError(
                    biometricInput,
                    "Este ID biométrico ya está asignado."
                );

                valid = false;

            }

        }


        return valid;

    }


    /* =====================================================
       MOSTRAR ERROR
    ===================================================== */

    function setError(
        input,
        message
    ) {

        const group =
            input.closest(
                ".worker-form-group"
            );


        if (!group) {
            return;
        }


        group.classList.add(
            "has-error"
        );


        const error =
            group.querySelector(
                ".form-error"
            );


        if (error) {

            error.textContent =
                message;

        }

    }


    /* =====================================================
       LIMPIAR ERRORES
    ===================================================== */

    function clearFormErrors() {

        document
            .querySelectorAll(
                ".worker-form-group"
            )
            .forEach(group => {

                group.classList.remove(
                    "has-error"
                );


                const error =
                    group.querySelector(
                        ".form-error"
                    );


                if (error) {

                    error.textContent =
                        "";

                }

            });

    }


    /* =====================================================
       ABRIR MODAL
    ===================================================== */

    function openModal() {

        modal.classList.add(
            "show"
        );


        document.body.style.overflow =
            "hidden";

    }


    /* =====================================================
       CERRAR MODAL
    ===================================================== */

    function closeModal() {

        modal.classList.remove(
            "show"
        );


        document.body.style.overflow =
            "";


        workerForm.reset();


        clearFormErrors();


        editingWorkerId =
            null;

    }


    /* =====================================================
       BOTONES CERRAR MODAL
    ===================================================== */

    closeModalButton.addEventListener(
        "click",
        closeModal
    );


    cancelModalButton.addEventListener(
        "click",
        closeModal
    );


    modal.addEventListener(
        "click",
        event => {

            if (
                event.target === modal
            ) {

                closeModal();

            }

        }
    );


    /* =====================================================
       MENÚ ⋮
    ===================================================== */

    tableBody.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    ".worker-actions-button"
                );


            if (!button) {
                return;
            }


            event.stopPropagation();


            selectedWorkerId =
                Number(
                    button.dataset.workerId
                );


            updateActionMenu();


            showActionsMenu(
                button
            );

        }
    );


    /* =====================================================
       ACCIONES
    ===================================================== */

    actionsMenu.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    "button[data-action]"
                );


            if (!button) {
                return;
            }


            const action =
                button.dataset.action;


            hideActionsMenu();


            if (
                action === "view"
            ) {

                viewWorker();

            }


            if (
                action === "edit"
            ) {

                editWorker();

            }


            if (action === "attendance") {
                window.location.href = `asistencia.html?worker=${selectedWorkerId}`;
            }


            if (
                action === "toggle"
            ) {

                toggleWorkerStatus();

            }

            if (action === "delete") {
                openDeleteWorkerModal();
            }

        }
    );


    /* =====================================================
       OBTENER TRABAJADOR SELECCIONADO
    ===================================================== */

    function getSelectedWorker() {

        return workers.find(
            worker =>
                Number(worker.id) ===
                Number(selectedWorkerId)
        ) || null;

    }


    /* =====================================================
       VER TRABAJADOR
    ===================================================== */

    function viewWorker() {
        refreshData();
        const worker = getSelectedWorker();
        if (!worker || !workerDetailModal) return;

        const fullName = `${worker.names || ""} ${worker.lastNames || ""}`.trim();
        const initials = `${(worker.names || "T").charAt(0)}${(worker.lastNames || "R").charAt(0)}`.toUpperCase();
        const positionName = getPositionName(worker.positionId);

        document.getElementById("detailWorkerAvatar").textContent = initials;
        document.getElementById("detailWorkerName").textContent = fullName || "Trabajador";
        document.getElementById("detailWorkerMeta").textContent = `${worker.code || "Sin código"} · ${positionName}`;
        document.getElementById("detailWorkerDni").textContent = worker.dni || "No registrado";
        document.getElementById("detailWorkerEntry").textContent = formatDate(worker.entryDate);
        document.getElementById("detailWorkerPosition").textContent = positionName;
        document.getElementById("detailWorkerBiometric").textContent = worker.biometricId || "Sin asignar";
        const status = document.getElementById("detailWorkerStatus");
        status.textContent = worker.status === "Activo" ? "Activo" : "Dado de baja";
        status.classList.toggle("inactive", worker.status !== "Activo");
        workerDetailModal.classList.add("show");
        document.body.style.overflow = "hidden";
    }


    /* =====================================================
       EDITAR TRABAJADOR
    ===================================================== */

    function editWorker() {

        refreshData();


        const worker =
            getSelectedWorker();


        if (!worker) {
            return;
        }


        editingWorkerId =
            worker.id;


        loadPositionSelect(
            worker.positionId
        );


        namesInput.value =
            worker.names || "";


        lastNamesInput.value =
            worker.lastNames || "";


        dniInput.value =
            worker.dni || "";


        positionInput.value =
            String(
                worker.positionId || ""
            );


        startDateInput.value =
            worker.entryDate || "";


        statusInput.value =
            worker.status || "Activo";


        biometricInput.value =
            worker.biometricId || "";


        modalTitle.textContent =
            "Editar trabajador";


        submitText.textContent =
            "Guardar cambios";


        clearFormErrors();


        openModal();


        setTimeout(
            () => namesInput.focus(),
            100
        );

    }


    /* =====================================================
       ACTIVAR / DESACTIVAR TRABAJADOR
    ===================================================== */

    async function toggleWorkerStatus() {

        refreshData();


        const worker =
            getSelectedWorker();


        if (!worker) {
            return;
        }


        const newStatus =
            worker.status === "Activo"
                ? "Inactivo"
                : "Activo";


        const action =
            newStatus === "Activo"
                ? "reactivar"
                : "dar de baja";


        const fullName = `${worker.names || ""} ${worker.lastNames || ""}`.trim();
        const confirmation = await SIGEP_CONFIRM({
            title: newStatus === "Activo" ? "¿Deseas reactivar al trabajador?" : "¿Deseas dar de baja al trabajador?",
            message: newStatus === "Activo" ? "Volverá a estar disponible para nuevos turnos." : "Dejará de aparecer para nuevos turnos, pero su historial se conservará.",
            name: fullName, confirmText: newStatus === "Activo" ? "Reactivar" : "Dar de baja", danger: newStatus !== "Activo"
        });


        if (!confirmation) {
            return;
        }


        worker.status =
            newStatus;


        SIGEP_STORAGE.saveWorkers(
            workers
        );


        renderWorkers();

    }


    /* =====================================================
       ELIMINACIÓN PERMANENTE
       Conserva marcaciones y regularizaciones históricas.
    ===================================================== */

    async function openDeleteWorkerModal() {
        refreshData();
        const worker = getSelectedWorker();
        if (!worker) return;
        if (!workerDeleteModal) {
            const fullName = `${worker.names || ""} ${worker.lastNames || ""}`.trim();
            const ok = await SIGEP_CONFIRM({title:"¿Eliminar permanentemente al trabajador?",message:"Esta acción eliminará su registro de la gestión de personal. No podrás deshacerla.",name:fullName,confirmText:"Eliminar permanentemente",danger:true});
            if (!ok) return;
            SIGEP_STORAGE.deleteWorker(worker.id);
            selectedWorkerId = null;
            refreshData();
            renderWorkers();
            return;
        }
        const fullName = `${worker.names || ""} ${worker.lastNames || ""}`.trim();
        if (workerDeleteMessage) {
            workerDeleteMessage.textContent = `Vas a eliminar permanentemente a ${fullName} (${worker.code || "sin código"}) de la gestión activa de SIGEP.`;
        }
        workerDeleteModal.classList.add("show");
        document.body.style.overflow = "hidden";
    }

    function closeDeleteWorkerModal() {
        workerDeleteModal?.classList.remove("show");
        document.body.style.overflow = "";
    }

    cancelWorkerDelete?.addEventListener("click", closeDeleteWorkerModal);
    workerDeleteModal?.addEventListener("click", event => {
        if (event.target === workerDeleteModal) closeDeleteWorkerModal();
    });

    confirmWorkerDelete?.addEventListener("click", () => {
        refreshData();
        const worker = getSelectedWorker();
        if (!worker) { closeDeleteWorkerModal(); return; }
        SIGEP_STORAGE.deleteWorker(worker.id);
        closeDeleteWorkerModal();
        selectedWorkerId = null;
        refreshData();
        renderWorkers();
    });

    /* =====================================================
       ACTUALIZAR MENÚ DE ACCIONES
    ===================================================== */

    function updateActionMenu() {
        const worker = getSelectedWorker();
        if (!worker) return;
        const fullName = `${worker.names || ""} ${worker.lastNames || ""}`.trim();
        const initials = `${(worker.names || "T").charAt(0)}${(worker.lastNames || "R").charAt(0)}`.toUpperCase();
        if (workerActionsName) workerActionsName.textContent = fullName;
        if (workerActionsMeta) workerActionsMeta.textContent = `${worker.code || "Sin código"} · ${getPositionName(worker.positionId)}`;
        if (workerActionsAvatar) workerActionsAvatar.textContent = initials;
        if (workerActionsStatus) {
            workerActionsStatus.textContent = worker.status === "Activo" ? "Activo" : "Dado de baja";
            workerActionsStatus.classList.toggle("inactive", worker.status !== "Activo");
        }
        const toggle = actionsMenu.querySelector('[data-action="toggle"]');
        if (!toggle) return;
        const active = worker.status === "Activo";
        toggle.innerHTML = `
            <span class="action-icon ${active ? "red" : "green"}"><i class="fa-solid ${active ? "fa-user-slash" : "fa-user-check"}"></i></span>
            <span><strong>${active ? "Dar de baja" : "Reactivar trabajador"}</strong><small>${active ? "Lo retira de Turnos y de la operación diaria, conservando su historial." : "Lo habilita nuevamente para trabajar y recibir turnos."}</small></span>`;
    }

    function showActionsMenu() {
        if (!actionsOverlay) return;
        actionsOverlay.classList.add("show");
        document.body.style.overflow = "hidden";
    }

    function hideActionsMenu() {
        actionsOverlay?.classList.remove("show");
        if (!workerDetailModal?.classList.contains("show") && !modal?.classList.contains("show")) {
            document.body.style.overflow = "";
        }
    }

    closeWorkerActions?.addEventListener("click", hideActionsMenu);
    actionsOverlay?.addEventListener("click", event => {
        if (event.target === actionsOverlay) hideActionsMenu();
    });

    function closeDetailModal() {
        workerDetailModal?.classList.remove("show");
        document.body.style.overflow = "";
    }
    closeWorkerDetail?.addEventListener("click", closeDetailModal);
    detailCloseButton?.addEventListener("click", closeDetailModal);
    workerDetailModal?.addEventListener("click", event => {
        if (event.target === workerDetailModal) closeDetailModal();
    });
    detailEditButton?.addEventListener("click", () => {
        closeDetailModal();
        editWorker();
    });


    window.addEventListener(
        "scroll",
        hideActionsMenu,
        true
    );


    window.addEventListener(
        "resize",
        hideActionsMenu
    );


    /* =====================================================
       SOLO NÚMEROS - DNI
    ===================================================== */

    dniInput.addEventListener(
        "input",
        () => {

            dniInput.value =
                dniInput.value
                    .replace(
                        /\D/g,
                        ""
                    )
                    .slice(
                        0,
                        8
                    );

        }
    );


    /* =====================================================
       INICIALES
    ===================================================== */

    function getInitials(
        names,
        lastNames
    ) {

        const firstName =
            String(
                names || ""
            )
                .trim()
                .charAt(0);


        const firstLastName =
            String(
                lastNames || ""
            )
                .trim()
                .charAt(0);


        return (
            `${firstName}${firstLastName}`
        ).toUpperCase();

    }


    /* =====================================================
       ESCAPAR HTML
    ===================================================== */

    function escapeHTML(value) {

        const div =
            document.createElement(
                "div"
            );


        div.textContent =
            value ?? "";


        return div.innerHTML;

    }


    /* =====================================================
       FORMATEAR FECHA
    ===================================================== */

    function formatDate(date) {

        if (!date) {

            return "No registrada";

        }


        const parts =
            String(date).split("-");


        if (
            parts.length !== 3
        ) {

            return date;

        }


        return (
            `${parts[2]}/${parts[1]}/${parts[0]}`
        );

    }


    /* =====================================================
       FECHA ACTUAL YYYY-MM-DD
    ===================================================== */

    function getTodayISO() {

        const date =
            new Date();


        const year =
            date.getFullYear();


        const month =
            String(
                date.getMonth() + 1
            ).padStart(
                2,
                "0"
            );


        const day =
            String(
                date.getDate()
            ).padStart(
                2,
                "0"
            );


        return (
            `${year}-${month}-${day}`
        );

    }


    /* =====================================================
       SIDEBAR MÓVIL
    ===================================================== */

    if (
        mobileMenu &&
        sidebar
    ) {

        mobileMenu.addEventListener(
            "click",
            event => {

                event.stopPropagation();


                sidebar.classList.toggle(
                    "open"
                );

            }
        );

    }


    /* =====================================================
       CERRAR SESIÓN
    ===================================================== */

    if (logoutButton) {

        logoutButton.addEventListener(
            "click",
            () => {

                const confirmation =
                    confirm(
                        "¿Estás seguro de que deseas cerrar sesión?"
                    );


                if (!confirmation) {
                    return;
                }


                localStorage.removeItem(
                    "sigep_session"
                );


                sessionStorage.removeItem(
                    "sigep_session"
                );


                window.location.href =
                    "../index.html";

            }
        );

    }


    /* =====================================================
       TECLA ESC
    ===================================================== */

    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key !== "Escape"
            ) {

                return;

            }


            if (workerDetailModal?.classList.contains("show")) {
                closeDetailModal();
                return;
            }

            if (actionsOverlay?.classList.contains("show")) {
                hideActionsMenu();
                return;
            }


            if (
                modal
                    .classList
                    .contains("show")
            ) {

                closeModal();

            }

        }
    );


    /* =====================================================
       INICIAR MÓDULO
    ===================================================== */

    refreshData();

    loadPositionFilter();

    loadPositionSelect();

    renderWorkers();

});
/* Abrir automáticamente el registro cuando se llega desde el Dashboard */
document.addEventListener("DOMContentLoaded", () => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("nuevo") === "1") {
        setTimeout(() => {
            document.getElementById("openWorkerModal")?.click();
            history.replaceState({}, "", window.location.pathname);
        }, 0);
    }
});
